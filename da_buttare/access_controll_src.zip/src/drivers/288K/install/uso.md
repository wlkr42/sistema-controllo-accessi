📋 Opzioni Disponibili

./verifica_288x.sh --check      # Solo verifica
./verifica_288x.sh --install    # Solo installazione
./verifica_288x.sh --test       # Solo test
./verifica_288x.sh --compile    # Solo compilazione
./verifica_288x.sh --report     # Solo report
./verifica_288x.sh --auto       # Tutto automatico
./verifica_288x.sh              # Menù interattivo
