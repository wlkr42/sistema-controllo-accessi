import ctypes
import logging
import time
import re
import signal
from typing import Optional, Callable, NoReturn, Any

logger = logging.getLogger(__name__)

# Definizioni tipi C
class CRT288xLib:
    """Definizione funzioni libreria CRT288x"""
    def __init__(self, lib: ctypes.CDLL):
        self.lib = lib
        self._setup_prototypes()
        
        # Definizione attributi funzioni
        self.CRT288x_OpenConnection = self.lib.CRT288x_OpenConnection
        self.CRT288x_CloseConnection = self.lib.CRT288x_CloseConnection
        self.CRT288x_InitDev = self.lib.CRT288x_InitDev
        self.CRT288x_GetCardStatus = self.lib.CRT288x_GetCardStatus
        self.CRT288x_ReadAllTracks = self.lib.CRT288x_ReadAllTracks
    
    def _setup_prototypes(self) -> None:
        """Setup prototipi funzioni C"""
        # OpenConnection
        self.lib.CRT288x_OpenConnection.argtypes = [ctypes.c_int, ctypes.c_int, ctypes.c_long]
        self.lib.CRT288x_OpenConnection.restype = ctypes.c_int
        
        # CloseConnection
        self.lib.CRT288x_CloseConnection.argtypes = []
        self.lib.CRT288x_CloseConnection.restype = ctypes.c_int
        
        # InitDev
        self.lib.CRT288x_InitDev.argtypes = [ctypes.c_int]
        self.lib.CRT288x_InitDev.restype = ctypes.c_int
        
        # GetCardStatus
        self.lib.CRT288x_GetCardStatus.argtypes = []
        self.lib.CRT288x_GetCardStatus.restype = ctypes.c_int
        
        # ReadAllTracks
        self.lib.CRT288x_ReadAllTracks.argtypes = [
            ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p
        ]
        self.lib.CRT288x_ReadAllTracks.restype = ctypes.c_int

class CRT285Reader:
    """Lettore CRT-285 con gestione robusta errori e retry"""
    
    def __init__(self):
        self.lib: Optional[CRT288xLib] = None
        self.running = False
        self.last_cf = None
        self.debug = False
        
        # Configurazione retry
        self.max_retries = 3
        self.retry_delay = 0.5
        self.read_timeout = 3
        
        # Cache per evitare letture duplicate
        self.last_read_time = 0
        self.duplicate_threshold = 1.0  # Secondi
        
        self._load_library()
        self._init_device()
        logger.info("💳 CRT285Reader inizializzato")
    
    def _load_library(self) -> None:
        """Carica libreria CRT-285"""
        try:
            lib = ctypes.CDLL('/usr/local/lib/crt_288x_ur.so')
            self.lib = CRT288xLib(lib)
        except Exception as e:
            logger.error(f"❌ Errore caricamento libreria: {e}")
            raise
    
    
    def _init_device(self) -> None:
        """Inizializza dispositivo con retry"""
        if not self.lib:
            raise Exception("Libreria non inizializzata")
            
        for attempt in range(self.max_retries):
            try:
                # Apri connessione USB
                result = self.lib.CRT288x_OpenConnection(0, 0, 9600)
                if result != 0:
                    raise Exception(f"Errore apertura connessione: {result}")
                
                # Inizializza dispositivo
                result = self.lib.CRT288x_InitDev(1)  # 1 = unlock
                if result != 0:
                    raise Exception(f"Errore inizializzazione: {result}")
                
                logger.info("✅ Dispositivo CRT-285 inizializzato")
                return
                
            except Exception as e:
                if attempt < self.max_retries - 1:
                    logger.warning(f"⚠️ Tentativo {attempt + 1} fallito: {e}")
                    time.sleep(self.retry_delay)
                    continue
                else:
                    raise Exception(f"Inizializzazione fallita dopo {self.max_retries} tentativi: {e}")
    
    def start_continuous_reading(self, callback: Optional[Callable[[str], None]] = None) -> None:
        """Avvia lettura continua con gestione errori"""
        if not self.lib:
            raise Exception("Libreria non inizializzata")
            
        self.running = True
        logger.info("🚀 AVVIO LETTURA CONTINUA CRT-285")
        logger.info("💳 Inserire tessere...")
        
        consecutive_errors = 0
        max_consecutive_errors = 5
        
        while self.running:
            try:
                # Verifica presenza carta
                status = self.lib.CRT288x_GetCardStatus()
                
                if status == 3:  # Carta presente
                    # Leggi dati carta
                    cf = self._read_card_robust()
                    
                    if cf:
                        current_time = time.time()
                        
                        # Evita duplicati ravvicinati
                        if (current_time - self.last_read_time) < self.duplicate_threshold and cf == self.last_cf:
                            if self.debug:
                                logger.debug(f"🔄 CF duplicato ignorato: {cf}")
                            continue
                        
                        # Nuovo CF valido
                        logger.info(f"🎯 CODICE FISCALE: {cf}")
                        self.last_cf = cf
                        self.last_read_time = current_time
                        consecutive_errors = 0
                        
                        # Callback
                        if callback:
                            try:
                                callback(cf)
                            except Exception as e:
                                logger.error(f"❌ Errore callback: {e}")
                        
                        # Attendi rimozione carta
                        self._wait_card_removal()
                    
                elif status == 1:  # No card
                    consecutive_errors = 0
                    time.sleep(0.2)
                    
                else:
                    logger.warning(f"⚠️ Stato carta non gestito: {status}")
                    time.sleep(0.5)
                
            except KeyboardInterrupt:
                logger.info("⏹️ Interruzione richiesta")
                break
            except Exception as e:
                consecutive_errors += 1
                
                if consecutive_errors <= max_consecutive_errors:
                    if self.debug:
                        logger.debug(f"⚠️ Errore {consecutive_errors}/{max_consecutive_errors}: {e}")
                    time.sleep(1)
                else:
                    logger.error(f"❌ Troppi errori consecutivi: {e}")
                    self._reinit_device()
                    consecutive_errors = 0
        
        self.running = False
        logger.info("🛑 Lettura continua FERMATA")
    
    def _read_card_robust(self) -> Optional[str]:
        """Lettura carta con retry"""
        if not self.lib:
            raise Exception("Libreria non inizializzata")
            
        track1 = ctypes.create_string_buffer(512)
        track2 = ctypes.create_string_buffer(512)
        track3 = ctypes.create_string_buffer(512)
        
        for attempt in range(self.max_retries):
            try:
                result = self.lib.CRT288x_ReadAllTracks(track1, track2, track3)
                
                if result == 0:
                    # Estrai CF da track2 (contiene i dati principali)
                    track2_data = track2.value.decode('ascii', errors='ignore')
                    cf = self._extract_cf(track2_data)
                    
                    if cf:
                        return cf
                
                if attempt < self.max_retries - 1:
                    time.sleep(self.retry_delay)
                    continue
                
            except Exception as e:
                if attempt < self.max_retries - 1:
                    if self.debug:
                        logger.debug(f"⚠️ Errore lettura tentativo {attempt + 1}: {e}")
                    time.sleep(self.retry_delay)
                    continue
                else:
                    raise
        
        return None
    
    def _extract_cf(self, data: str) -> Optional[str]:
        """Estrai CF dai dati della carta"""
        try:
            # Pattern CF standard
            cf_pattern = r'[A-Z]{6}[0-9]{2}[A-Z][0-9]{2}[A-Z][0-9]{3}[A-Z]'
            match = re.search(cf_pattern, data.upper())
            
            if match:
                cf = match.group(0)
                if self._validate_cf(cf):
                    return cf
            
            return None
            
        except Exception as e:
            if self.debug:
                logger.debug(f"❌ Errore estrazione CF: {e}")
            return None
    
    def _validate_cf(self, cf: str) -> bool:
        """Validazione base CF"""
        if not cf or len(cf) != 16:
            return False
        
        pattern = r'^[A-Z]{6}[0-9]{2}[A-Z][0-9]{2}[A-Z][0-9]{3}[A-Z]$'
        if not re.match(pattern, cf):
            return False
        
        if len(set(cf)) < 4:  # Evita pattern troppo uniformi
            return False
        
        return True
    
    def _wait_card_removal(self) -> None:
        """Attendi rimozione carta con timeout"""
        if not self.lib:
            return
            
        removal_timeout = 30
        start_time = time.time()
        
        while (time.time() - start_time) < removal_timeout:
            status = self.lib.CRT288x_GetCardStatus()
            if status == 1:  # No card
                break
            time.sleep(0.3)
        
        time.sleep(0.2)  # Pausa stabilizzazione
    
    def _reinit_device(self) -> None:
        """Reinizializza dispositivo dopo errori"""
        if not self.lib:
            return
            
        logger.info("🔄 Reinizializzazione dispositivo...")
        try:
            self.lib.CRT288x_CloseConnection()
            time.sleep(1)
            self._init_device()
        except Exception as e:
            logger.error(f"❌ Errore reinizializzazione: {e}")
    
    def stop(self) -> None:
        """Ferma lettura continua"""
        self.running = False
        if not self.lib:
            return
            
        try:
            self.lib.CRT288x_CloseConnection()
        except:
            pass
    
    def get_last_cf(self) -> Optional[str]:
        """Ultimo CF letto"""
        return self.last_cf
    
    def test_connection(self) -> bool:
        """Test connessione dispositivo"""
        if not self.lib:
            return False
            
        try:
            status = self.lib.CRT288x_GetCardStatus()
            return status in [1, 3]  # 1=no card, 3=card present
        except:
            return False
    
    def set_debug(self, debug: bool) -> None:
        """Abilita/disabilita debug logging"""
        self.debug = debug
        if debug:
            logger.setLevel(logging.DEBUG)
        else:
            logger.setLevel(logging.INFO)

# Test standalone
if __name__ == "__main__":
    import signal
    import sys
    
    def handle_cf(cf: str):
        """Callback per CF letti"""
        print(f"\n🎯 ACCESSO RILEVATO!")
        print(f"📋 Codice Fiscale: {cf}")
        print(f"⏰ {time.strftime('%H:%M:%S')}")
        print("💳 Pronto per prossima tessera...\n")
    
    def signal_handler(signum: int, frame: Any) -> NoReturn:
        print(f"\n🛑 Arresto...")
        if 'reader' in globals():
            reader.stop()
        sys.exit(0)
    
    signal.signal(signal.SIGINT, signal_handler)
    
    print("🏥 TEST LETTORE CRT-285")
    print("=" * 50)
    
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(levelname)s - %(message)s'
    )
    
    try:
        reader = CRT285Reader()
        # reader.set_debug(True)  # Abilita per debug
        
        print("✅ Lettore CRT-285 inizializzato")
        print("💳 Inserire tessere...")
        print("🔄 Retry automatici attivi")
        print("⚠️ Gestione errori robusta")
        print("⏹️ Ctrl+C per fermare")
        
        reader.start_continuous_reading(callback=handle_cf)
        
    except Exception as e:
        print(f"❌ Errore: {e}")
    finally:
        print("✅ Sistema fermato")
