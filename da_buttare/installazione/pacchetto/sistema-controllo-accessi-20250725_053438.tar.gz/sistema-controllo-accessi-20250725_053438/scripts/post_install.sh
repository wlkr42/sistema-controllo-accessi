#!/bin/bash

# Script di post-installazione
echo "=== Post-installazione Sistema Controllo Accessi ==="

# Le tabelle saranno create automaticamente da web_api.py
echo "✅ Il database e le tabelle saranno creati automaticamente al primo avvio"

# Installazione cron jobs
echo "Installazione cron jobs..."
if [ -f "/opt/access_control/cron/access-control-cron" ]; then
    sudo -u wlkr42 crontab /opt/access_control/cron/access-control-cron
    echo "✅ Cron jobs installati"
else
    echo "⚠️  File cron non trovato"
fi

# Avvio e abilitazione servizio
echo "Avvio servizio..."
systemctl enable access-control.service
systemctl start access-control.service

# Verifica stato servizio
sleep 3
if systemctl is-active --quiet access-control.service; then
    echo "✅ Servizio avviato correttamente"
else
    echo "⚠️  Servizio non attivo, controllare log:"
    echo "   journalctl -u access-control.service -n 20"
fi

echo "Post-installazione completata!"
