class ScheduleManager {
    constructor() {
        this.daysOfWeek = [
            { id: 0, name: 'Domenica' },
            { id: 1, name: 'Lunedì' },
            { id: 2, name: 'Martedì' },
            { id: 3, name: 'Mercoledì' },
            { id: 4, name: 'Giovedì' },
            { id: 5, name: 'Venerdì' },
            { id: 6, name: 'Sabato' }
        ];
        
        this.timeSlots = {
            morning: {
                open: ['07:00', '07:30', '08:00', '08:30', '09:00', '09:30', '10:00', '10:30', '11:00'],
                close: ['11:00', '11:30', '12:00', '12:30', '13:00', '13:30', '14:00']
            },
            afternoon: {
                open: ['14:00', '14:30', '15:00', '15:30', '16:00', '16:30', '17:00'],
                close: ['16:00', '16:30', '17:00', '17:30', '18:00', '18:30', '19:00']
            }
        };
        
        this.init();
    }
    
    init() {
        this.generateDays();
        this.setupEventListeners();
        this.loadCurrentSchedule();
    }
    
    generateDays() {
        const container = document.getElementById('days-container');
        container.innerHTML = ''; // Pulisci il contenitore
        
        this.daysOfWeek.forEach(day => {
            const dayHtml = this.generateDayRow(day);
            container.insertAdjacentHTML('beforeend', dayHtml);
            
            // Setup switch event
            const switchEl = document.getElementById(`${day.id}-switch`);
            if (switchEl) {
                switchEl.addEventListener('change', (e) => {
                    this.toggleDaySchedule(day.id, e.target.checked);
                });
            }
        });
    }
    
    generateDayRow(day) {
        return `
            <div class="day-row d-flex align-items-center">
                <div class="day-name">${day.name}</div>
                <div class="form-check form-switch me-3">
                    <input class="form-check-input" type="checkbox" id="${day.id}-switch" checked>
                    <label class="form-check-label" for="${day.id}-switch">Aperto</label>
                </div>
                <div class="time-slots flex-grow-1" id="${day.id}-slots">
                    <div class="time-slot morning">
                        <span class="time-label">Mattina</span>
                        <select class="form-select time-select" name="${day.id}-morning-open">
                            <option value="closed">Chiuso</option>
                            ${this.generateTimeOptions(this.timeSlots.morning.open, '09:00')}
                        </select>
                        <span class="time-separator">-</span>
                        <select class="form-select time-select" name="${day.id}-morning-close">
                            ${this.generateTimeOptions(this.timeSlots.morning.close, '12:00')}
                        </select>
                    </div>
                    <div class="time-slot afternoon">
                        <span class="time-label">Pomeriggio</span>
                        <select class="form-select time-select" name="${day.id}-afternoon-open">
                            <option value="closed">Chiuso</option>
                            ${this.generateTimeOptions(this.timeSlots.afternoon.open, '15:00')}
                        </select>
                        <span class="time-separator">-</span>
                        <select class="form-select time-select" name="${day.id}-afternoon-close">
                            ${this.generateTimeOptions(this.timeSlots.afternoon.close, '17:00')}
                        </select>
                    </div>
                </div>
            </div>
        `;
    }
    
    generateTimeOptions(times, selected) {
        return times.map(time => 
            `<option value="${time}" ${time === selected ? 'selected' : ''}>${time}</option>`
        ).join('');
    }
    
    toggleDaySchedule(dayId, isOpen) {
        const slots = document.getElementById(`${dayId}-slots`);
        const selects = slots.querySelectorAll('select');
        
        if (isOpen) {
            slots.classList.remove('disabled');
            selects.forEach(select => select.disabled = false);
        } else {
            slots.classList.add('disabled');
            selects.forEach(select => select.disabled = true);
        }
    }
    
    setupEventListeners() {
        // Salva configurazione
        document.getElementById('save-schedule').addEventListener('click', () => {
            this.saveSchedule();
        });
        
        // Copia su tutti i giorni
        document.getElementById('copy-to-all').addEventListener('click', () => {
            this.copyToAllDays();
        });
        
        // Salva limite ingressi
        document.getElementById('save-limits').addEventListener('click', () => {
            this.saveLimits();
        });
    }
    
    async loadCurrentSchedule() {
        try {
            const response = await fetch('/api/configurazione/orari');
            const data = await response.json();
            
            if (data.success) {
                this.daysOfWeek.forEach(day => {
                    const dayConfig = data.schedule[day.id];
                    if (dayConfig) {
                        // Imposta switch
                        const switchEl = document.getElementById(`${day.id}-switch`);
                        if (switchEl) {
                            switchEl.checked = dayConfig.isola_aperta;
                            this.toggleDaySchedule(day.id, dayConfig.isola_aperta);
                        }
                        
                        // Imposta orari mattina
                        if (dayConfig.mattina_apertura) {
                            document.querySelector(`select[name="${day.id}-morning-open"]`).value = dayConfig.mattina_apertura;
                            document.querySelector(`select[name="${day.id}-morning-close"]`).value = dayConfig.mattina_chiusura;
                        }
                        
                        // Imposta orari pomeriggio
                        if (dayConfig.pomeriggio_apertura) {
                            document.querySelector(`select[name="${day.id}-afternoon-open"]`).value = dayConfig.pomeriggio_apertura;
                            document.querySelector(`select[name="${day.id}-afternoon-close"]`).value = dayConfig.pomeriggio_chiusura;
                        }
                    }
                });
            }
            
            // Carica limite ingressi
            const limitsResponse = await fetch('/api/configurazione/limiti');
            const limitsData = await limitsResponse.json();
            
            if (limitsData.success) {
                document.getElementById('max-entries').value = limitsData.max_ingressi_mensili;
            }
            
        } catch (error) {
            console.error('Errore caricamento configurazione:', error);
            showAlert('Errore caricamento configurazione', 'danger');
        }
    }
    
    async saveSchedule() {
        const schedule = {};
        
        this.daysOfWeek.forEach(day => {
            const isOpen = document.getElementById(`${day.id}-switch`).checked;
            
            schedule[day.id] = {
                isola_aperta: isOpen,
                mattina_apertura: isOpen ? document.querySelector(`select[name="${day.id}-morning-open"]`).value : null,
                mattina_chiusura: isOpen ? document.querySelector(`select[name="${day.id}-morning-close"]`).value : null,
                pomeriggio_apertura: isOpen ? document.querySelector(`select[name="${day.id}-afternoon-open"]`).value : null,
                pomeriggio_chiusura: isOpen ? document.querySelector(`select[name="${day.id}-afternoon-close"]`).value : null
            };
        });
        
        try {
            const response = await fetch('/api/configurazione/orari', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ schedule })
            });
            
            const data = await response.json();
            
            if (data.success) {
                showAlert('Configurazione orari salvata con successo', 'success');
            } else {
                showAlert(data.error || 'Errore salvataggio configurazione', 'danger');
            }
            
        } catch (error) {
            console.error('Errore salvataggio:', error);
            showAlert('Errore di connessione al server', 'danger');
        }
    }
    
    copyToAllDays() {
        // Prendi i valori dal lunedì
        const mondaySwitch = document.getElementById('1-switch');
        const mondayMorningOpen = document.querySelector('select[name="1-morning-open"]');
        const mondayMorningClose = document.querySelector('select[name="1-morning-close"]');
        const mondayAfternoonOpen = document.querySelector('select[name="1-afternoon-open"]');
        const mondayAfternoonClose = document.querySelector('select[name="1-afternoon-close"]');
        
        // Applica a tutti gli altri giorni
        this.daysOfWeek.forEach(day => {
            if (day.id !== 1) { // Salta lunedì
                const daySwitch = document.getElementById(`${day.id}-switch`);
                daySwitch.checked = mondaySwitch.checked;
                this.toggleDaySchedule(day.id, mondaySwitch.checked);
                
                document.querySelector(`select[name="${day.id}-morning-open"]`).value = mondayMorningOpen.value;
                document.querySelector(`select[name="${day.id}-morning-close"]`).value = mondayMorningClose.value;
                document.querySelector(`select[name="${day.id}-afternoon-open"]`).value = mondayAfternoonOpen.value;
                document.querySelector(`select[name="${day.id}-afternoon-close"]`).value = mondayAfternoonClose.value;
            }
        });
        
        showAlert('Orari copiati su tutti i giorni', 'success');
    }
    
    async saveLimits() {
        const maxEntries = document.getElementById('max-entries').value;
        
        if (!maxEntries || maxEntries < 1) {
            showAlert('Inserire un numero valido di ingressi mensili', 'danger');
            return;
        }
        
        try {
            const response = await fetch('/api/configurazione/limiti', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ max_ingressi_mensili: parseInt(maxEntries) })
            });
            
            const data = await response.json();
            
            if (data.success) {
                showAlert('Limite ingressi mensili salvato con successo', 'success');
            } else {
                showAlert(data.error || 'Errore salvataggio limite', 'danger');
            }
            
        } catch (error) {
            console.error('Errore salvataggio:', error);
            showAlert('Errore di connessione al server', 'danger');
        }
    }
}

// Funzione per mostrare alert
function showAlert(message, type) {
    const alertHtml = `
        <div class="alert alert-${type} alert-dismissible fade show" role="alert">
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    `;
    
    // Rimuovi alert esistenti
    document.querySelectorAll('.alert').forEach(alert => alert.remove());
    
    // Inserisci nuovo alert all'inizio del container
    document.querySelector('.container').insertAdjacentHTML('afterbegin', alertHtml);
    
    // Auto-chiudi dopo 5 secondi
    setTimeout(() => {
        const alert = document.querySelector('.alert');
        if (alert) {
            const bsAlert = new bootstrap.Alert(alert);
            bsAlert.close();
        }
    }, 5000);
}

// Inizializza quando il DOM è pronto
document.addEventListener('DOMContentLoaded', () => {
    new ScheduleManager();
});
