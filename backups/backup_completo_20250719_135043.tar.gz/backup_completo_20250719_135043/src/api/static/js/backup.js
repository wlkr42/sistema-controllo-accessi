// File: /opt/access_control/src/api/static/backup.js
// JavaScript per gestione backup

// Variabili globali
let backupConfig = null;
let backupOperationsInterval = null;

// ===== FUNZIONI PRINCIPALI =====

function openBackupManager() {
    const modal = new bootstrap.Modal(document.getElementById('backupModal'));
    modal.show();
    
    // Carica stato iniziale
    loadBackupStatus();
    loadBackupConfig();
    loadBackupSchedule();
    
    // Avvia polling operazioni
    backupOperationsInterval = setInterval(checkBackupOperations, 2000);
    
    // Ferma polling quando il modal si chiude
    document.getElementById('backupModal').addEventListener('hidden.bs.modal', function () {
        if (backupOperationsInterval) {
            clearInterval(backupOperationsInterval);
            backupOperationsInterval = null;
        }
    });
}

// Carica stato backup
function loadBackupStatus() {
    fetch('/api/backup/status')
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                // Aggiorna statistiche
                document.getElementById('backup-total-size').textContent = data.total_size || '-';
                document.getElementById('backup-total-count').textContent = data.total_backups || '0';
                document.getElementById('backup-disk-usage').textContent = data.disk_used_percent + '%' || '-';
                
                // Ultimo backup
                if (data.backups && data.backups.length > 0) {
                    const lastBackup = new Date(data.backups[0].date);
                    const ageHours = (new Date() - lastBackup) / (1000 * 60 * 60);
                    
                    if (ageHours < 24) {
                        document.getElementById('backup-last-date').textContent = 
                            ageHours < 1 ? 'Meno di 1 ora fa' : Math.floor(ageHours) + ' ore fa';
                    } else {
                        document.getElementById('backup-last-date').textContent = 
                            Math.floor(ageHours / 24) + ' giorni fa';
                    }
                }
                
                // Lista backup
                updateBackupList(data.backups);
                
                // Config
                if (data.config) {
                    backupConfig = data.config;
                    updateConfigForm(data.config);
                }
                
                // Operazioni
                if (data.operations && Object.keys(data.operations).length > 0) {
                    updateOperations(data.operations);
                }
            }
        })
        .catch(error => console.error('Errore caricamento stato:', error));
}

// Aggiorna lista backup
function updateBackupList(backups) {
    const tbody = document.getElementById('backup-list-tbody');
    
    if (!backups || backups.length === 0) {
        tbody.innerHTML = '<tr><td colspan="6" class="text-center text-muted">Nessun backup trovato</td></tr>';
        return;
    }
    
    let html = '';
    backups.forEach(backup => {
        const date = new Date(backup.date);
        const ageClass = backup.age_days > 30 ? 'text-danger' : 
                        backup.age_days > 7 ? 'text-warning' : 'text-success';
        
        html += `
            <tr>
                <td>
                    <i class="fas fa-${backup.type === 'complete' ? 'archive' : 'database'} me-2"></i>
                    ${backup.name}
                    ${backup.has_checksum ? '<i class="fas fa-check-circle text-success ms-1" title="Checksum verificato"></i>' : ''}
                </td>
                <td>
                    <span class="badge bg-${backup.type === 'complete' ? 'primary' : 'success'}">
                        ${backup.type === 'complete' ? 'Completo' : 'Database'}
                    </span>
                </td>
                <td>${backup.size}</td>
                <td>${date.toLocaleString('it-IT')}</td>
                <td class="${ageClass}">${backup.age_days} giorni</td>
                <td class="backup-file-actions">
                    ${backup.can_download ? 
                        `<button class="btn btn-sm btn-primary" onclick="downloadBackup('${backup.name}')" title="Download">
                            <i class="fas fa-download"></i>
                        </button>` : ''}
                    ${backup.can_restore ? 
                        `<button class="btn btn-sm btn-success" onclick="restoreBackup('${backup.name}')" title="Ripristina">
                            <i class="fas fa-undo"></i>
                        </button>` : ''}
                    <button class="btn btn-sm btn-danger" onclick="deleteBackup('${backup.name}')" title="Elimina">
                        <i class="fas fa-trash"></i>
                    </button>
                </td>
            </tr>
        `;
    });
    
    tbody.innerHTML = html;
}

// ===== OPERAZIONI BACKUP =====

// Crea nuovo backup
function createBackup(type) {
    if (!confirm(`Vuoi creare un backup ${type === 'complete' ? 'completo' : 'del database'}?`)) {
        return;
    }
    
    fetch('/api/backup/create', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({type: type})
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            showAlert('success', `Backup ${type} avviato`);
            // Il polling aggiornerà automaticamente lo stato
        } else {
            showAlert('danger', `Errore: ${data.error}`);
        }
    })
    .catch(error => showAlert('danger', `Errore: ${error}`));
}

// Download backup
function downloadBackup(filename) {
    window.location.href = `/api/backup/download/${encodeURIComponent(filename)}`;
}

function deleteBackup(filename) {
    if (confirm('Vuoi eliminare questo backup?')) {
        fetch(`/api/backup/delete/${encodeURIComponent(filename)}`, { method: 'DELETE' })
            .then(r => r.json())
            .then(data => {
                if (data.success) {
                    loadBackupList();
                } else {
                    alert('Errore eliminazione: ' + (data.error || ''));
                }
            });
    }
}

function restoreBackup(filename) {
    if (confirm('Vuoi ripristinare questo backup?')) {
        fetch(`/api/backup/restore/${encodeURIComponent(filename)}`, { method: 'POST' })
            .then(r => r.json())
            .then(data => {
                if (data.success) {
                    alert('Backup ripristinato con successo!');
                } else {
                    alert('Errore ripristino: ' + (data.error || ''));
                }
            });
    }
}

// Pulizia backup vecchi
function cleanupBackups() {
    if (!confirm('Eliminare i backup vecchi secondo la policy di retention?')) {
        return;
    }
    
    fetch('/api/backup/cleanup', {
        method: 'POST'
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            showAlert('success', 
                `Pulizia completata: ${data.cleaned_files} file eliminati, ${data.freed_space} liberati`);
            loadBackupStatus();
        } else {
            showAlert('danger', `Errore: ${data.error}`);
        }
    })
    .catch(error => showAlert('danger', `Errore: ${error}`));
}

// ===== GESTIONE OPERAZIONI =====

// Controlla operazioni in corso
function checkBackupOperations() {
    const container = document.getElementById('backup-operations');
    const list = document.getElementById('backup-operations-list');
    
    // Recupera solo le operazioni dal server
    fetch('/api/backup/operations')
        .then(response => response.json())
        .then(data => {
            if (data.operations && Object.keys(data.operations).length > 0) {
                container.style.display = 'block';
                updateOperations(data.operations);
            } else {
                container.style.display = 'none';
            }
        })
        .catch(error => console.error('Errore check operazioni:', error));
}

// Aggiorna visualizzazione operazioni
function updateOperations(operations) {
    const list = document.getElementById('backup-operations-list');
    let html = '';
    
    for (const [id, op] of Object.entries(operations)) {
        const statusClass = op.status === 'running' ? 'running' : 
                          op.status === 'completed' ? 'completed' : 'error';
        
        html += `
            <div class="backup-operation ${statusClass}">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <strong>${op.type === 'complete' ? 'Backup Completo' : 'Backup Database'}</strong>
                        <br>
                        <small class="text-muted">${op.message || 'In corso...'}</small>
                    </div>
                    <div class="text-end">
                        ${op.status === 'running' ? 
                            `<div class="spinner-border spinner-border-sm" role="status">
                                <span class="visually-hidden">In corso...</span>
                            </div>` : 
                            op.status === 'completed' ? 
                                '<i class="fas fa-check-circle text-success fa-2x"></i>' :
                                '<i class="fas fa-times-circle text-danger fa-2x"></i>'
                        }
                    </div>
                </div>
                ${op.status === 'running' && op.progress ? 
                    `<div class="progress mt-2">
                        <div class="progress-bar progress-bar-striped progress-bar-animated" 
                             style="width: ${op.progress}%">${op.progress}%</div>
                    </div>` : ''
                }
                ${op.result ? 
                    `<div class="mt-2 small">
                        <strong>Risultato:</strong> ${op.result.filename} (${op.result.size})
                    </div>` : ''
                }
                ${op.error ? 
                    `<div class="mt-2 small text-danger">
                        <strong>Errore:</strong> ${op.error}
                    </div>` : ''
                }
            </div>
        `;
    }
    
    list.innerHTML = html;
    
    // Se tutte completate, ricarica stato dopo 2 secondi
    const allCompleted = Object.values(operations).every(op => op.status !== 'running');
    if (allCompleted && Object.keys(operations).length > 0) {
        setTimeout(() => {
            loadBackupStatus();
        }, 2000);
    }
}

// ===== CONFIGURAZIONE =====

// Carica configurazione
function loadBackupConfig() {
    fetch('/api/backup/config')
        .then(response => response.json())
        .then(data => {
            if (data.config) {
                updateConfigForm(data.config);
            }
        })
        .catch(error => console.error('Errore caricamento config:', error));
}

// Aggiorna form configurazione
function updateConfigForm(config) {
    // Backup automatici
    document.getElementById('auto-backup-enabled').checked = config.auto_backup.enabled;
    document.getElementById('daily-backup-enabled').checked = config.auto_backup.daily.enabled;
    document.getElementById('daily-backup-time').value = config.auto_backup.daily.time;
    document.getElementById('weekly-backup-enabled').checked = config.auto_backup.weekly.enabled;
    document.getElementById('weekly-backup-day').value = config.auto_backup.weekly.day;
    document.getElementById('weekly-backup-time').value = config.auto_backup.weekly.time;
    
    // Retention
    document.getElementById('daily-retention').value = config.retention.daily_keep;
    document.getElementById('weekly-retention').value = config.retention.weekly_keep;
    document.getElementById('monthly-retention').value = config.retention.monthly_keep;
    document.getElementById('max-backup-size').value = config.retention.max_size_gb;
    
    // Abilita/disabilita opzioni
    document.getElementById('auto-backup-options').style.display = 
        config.auto_backup.enabled ? 'block' : 'none';
}

// Salva configurazione
document.getElementById('backup-settings-form').addEventListener('submit', function(e) {
    e.preventDefault();
    
    const config = {
        auto_backup: {
            enabled: document.getElementById('auto-backup-enabled').checked,
            daily: {
                enabled: document.getElementById('daily-backup-enabled').checked,
                time: document.getElementById('daily-backup-time').value
            },
            weekly: {
                enabled: document.getElementById('weekly-backup-enabled').checked,
                day: parseInt(document.getElementById('weekly-backup-day').value),
                time: document.getElementById('weekly-backup-time').value
            },
            monthly: {enabled: false, day: 1, time: "03:00"}
        },
        retention: {
            daily_keep: parseInt(document.getElementById('daily-retention').value),
            weekly_keep: parseInt(document.getElementById('weekly-retention').value),
            monthly_keep: parseInt(document.getElementById('monthly-retention').value),
            max_size_gb: parseInt(document.getElementById('max-backup-size').value)
        },
        notifications: {
            email_enabled: false,
            email_to: "",
            on_error: true,
            on_success: false
        }
    };
    
    fetch('/api/backup/config', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify(config)
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            showAlert('success', 'Configurazione salvata');
            backupConfig = config;
        } else {
            showAlert('danger', `Errore: ${data.error}`);
        }
    })
    .catch(error => showAlert('danger', `Errore: ${error}`));
});

// Toggle opzioni automatiche
document.getElementById('auto-backup-enabled').addEventListener('change', function() {
    document.getElementById('auto-backup-options').style.display = 
        this.checked ? 'block' : 'none';
});

// ===== SCHEDULAZIONE BACKUP =====

function saveBackupSchedule() {
    const scheduling = document.getElementById('backup-scheduling').value;
    const retention = document.getElementById('backup-retention').value;
    fetch('/api/backup/schedule', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ scheduling, retention })
    })
    .then(r => r.json())
    .then(data => {
        if (data.success) {
            alert('Schedulazione backup salvata!');
        } else {
            alert('Errore salvataggio: ' + (data.error || ''));
        }
    });
}

function loadBackupSchedule() {
    fetch('/api/backup/schedule')
        .then(r => r.json())
        .then(data => {
            if (data.success && data.schedule) {
                document.getElementById('backup-scheduling').value = data.schedule['backup.scheduling'] || 'daily';
                document.getElementById('backup-retention').value = data.schedule['backup.retention'] || '7';
            }
        });
}

// ===== UTILITY =====

function showAlert(type, message) {
    // Usa un sistema di notifiche o alert Bootstrap
    const alertHtml = `
        <div class="alert alert-${type} alert-dismissible fade show" role="alert">
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    `;
    
    // Aggiungi in cima al modal
    const modalBody = document.querySelector('#backupModal .modal-body');
    const alertDiv = document.createElement('div');
    alertDiv.innerHTML = alertHtml;
    modalBody.insertBefore(alertDiv.firstChild, modalBody.firstChild);
    
    // Rimuovi dopo 5 secondi
    setTimeout(() => {
        alertDiv.firstChild.remove();
    }, 5000);
}

document.addEventListener('DOMContentLoaded', function() {
    loadBackupList();
    loadBackupSchedule();
    document.getElementById('save-backup-schedule-btn').onclick = saveBackupSchedule;
});
