# File: /opt/access_control/src/api/web_api.py
# Dashboard web modulare - API principale - FIXED IMPORTS

import os
import sys
import json
import sqlite3
import logging
import shutil
from datetime import datetime
from typing import Dict, Any, Tuple, Optional, List, Union, Callable

from flask import Flask, render_template_string, request, jsonify, session, redirect, send_from_directory, Response, Blueprint, current_app
from flask_cors import CORS
from werkzeug.exceptions import BadRequest, InternalServerError
from werkzeug.wrappers import Response as WerkzeugResponse
from werkzeug.datastructures import ImmutableMultiDict
from werkzeug.local import LocalProxy

# Assicurati che il path sia corretto
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

# Importazioni locali
from api.auth import verify_user, USER_ROLES
from api.utils import get_db_connection, require_auth, require_permission
import api.hardware_tests as hardware_tests
import api.backup_module as backup_module
from core.config import get_config_manager
from api.dashboard_templates import LOGIN_TEMPLATE, get_dashboard_template, ADMIN_CONFIG_TEMPLATE, ADMIN_BACKUP_TEMPLATE

# Importazioni dei moduli
from api.modules.profilo import profilo_bp
from api.modules.user_management import user_management_bp
from api.modules.log_management import log_management_bp
from api.modules.utenti_autorizzati import utenti_autorizzati_bp
from api.modules.system_users import system_users_bp
from api.modules.activities import activities_bp
from api.modules.configurazione_accessi import configurazione_accessi_bp

# Definizione dei tipi personalizzati
FlaskResponse = Union[Response, str, Tuple[Union[Dict[str, Any], str], int]]
Request = Union[ImmutableMultiDict[str, str], Dict[str, Any]]

# Configurazione del logging
logging.basicConfig(level=logging.DEBUG, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Queste importazioni sono già state definite sopra e non sono necessarie qui

# Questi import sono già stati definiti sopra e non sono necessari qui

from typing import Optional

# Definizione dei tipi personalizzati
FlaskResponse = Union[Response, str, Tuple[Union[Dict[str, Any], str], int]]
Request = Union[ImmutableMultiDict[str, str], Dict[str, Any]]

# Gestione delle eccezioni
def handle_exception(e: Exception) -> Tuple[Dict[str, Any], int]:
    logger.error(f"Errore: {str(e)}", exc_info=True)
    if isinstance(e, BadRequest):
        return jsonify({"success": False, "error": "Richiesta non valida"}), 400
    elif isinstance(e, InternalServerError):
        return jsonify({"success": False, "error": "Errore interno del server"}), 500
    else:
        return jsonify({"success": False, "error": str(e)}), 500

# Definizione dei tipi per le funzioni di Flask
def flask_route(rule: str, **options: Any) -> Callable[[Callable[..., FlaskResponse]], Callable[..., FlaskResponse]]:
    return app.route(rule, **options)

def flask_jsonify(*args: Any, **kwargs: Any) -> WerkzeugResponse:
    return jsonify(*args, **kwargs)

# Tipo per le funzioni di route
RouteFunction = Callable[..., FlaskResponse]

app = Flask(__name__)
app.secret_key = 'raee-2025-access-control-system'

# Configura CORS per permettere richieste cross-origin con credenziali
CORS(app, 
     supports_credentials=True,
     resources={r"/*": {"origins": "*"}},
     allow_headers=["Content-Type", "Authorization"],
     expose_headers=["Content-Type", "X-CSRFToken"],
     methods=["GET", "POST", "PUT", "DELETE", "OPTIONS"])

# Configura sessione per funzionare cross-origin
app.config.update(
    SESSION_COOKIE_SECURE=False,  # Impostare a True se si usa HTTPS
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE='Lax'
)

project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..'))
sys.path.insert(0, project_root)

# Database path come database_manager.py
DB_PATH = os.path.join(project_root, 'src', 'access.db')

# IMPORTA I MODULI DOPO aver definito le funzioni condivise
from api.modules.profilo import profilo_bp
from api.modules.user_management import user_management_bp
from api.modules.log_management import log_management_bp
from api.modules.utenti_autorizzati import utenti_autorizzati_bp
from api.modules.system_users import system_users_bp
from api.modules.activities import activities_bp
from api.modules.configurazione_accessi import configurazione_accessi_bp

# Registra i blueprint
app.register_blueprint(profilo_bp)
app.register_blueprint(user_management_bp)
app.register_blueprint(log_management_bp)
app.register_blueprint(utenti_autorizzati_bp)
app.register_blueprint(system_users_bp)
app.register_blueprint(activities_bp)
app.register_blueprint(configurazione_accessi_bp)

# ===============================
# ROUTES PRINCIPALI
# ===============================

@flask_route('/')
@require_auth()
def dashboard() -> FlaskResponse:
    """Dashboard principale con template personalizzato per ruolo"""
    # Menu items per admin
    menu_items: List[Dict[str, str]] = []
    if session.get('role') == 'admin':
        menu_items = [
            {
                'url': '/utenti-autorizzati',
                'icon': 'fas fa-users',
                'text': 'Utenti Autorizzati'
            },
            {
                'url': '/admin/users',
                'icon': 'fas fa-users-cog',
                'text': 'Gestione Utenti Sistema'
            },
            {
                'url': '/configurazione-orari',
                'icon': 'fas fa-clock',
                'text': 'Configurazione Orari'
            }
        ]
    
    return render_template_string(
        get_dashboard_template(), 
        session=session,
        menu_items=menu_items
    )

@app.route('/utenti-autorizzati')
@require_auth()
@require_permission('all')
def utenti_autorizzati_page() -> FlaskResponse:
    """Pagina gestione utenti autorizzati"""
    with open(os.path.join(os.path.dirname(__file__), 'templates', 'utenti_autorizzati.html'), 'r') as f:
        template = f.read()
    return render_template_string(template, session=session)

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        password = request.form.get('password', '').strip()
        
        logger.debug(f"Tentativo di login per l'utente: {username}")
        
        if not username or not password:
            logger.debug("Username o password mancanti")
            return render_template_string(LOGIN_TEMPLATE, error="Inserire username e password")
        
        # Verifica credenziali nel database
        success, role = verify_user(username, password)
        
        logger.debug(f"Risultato verifica utente: success={success}, role={role}")
        
        if success:
            conn = get_db_connection()
            if conn:
                try:
                    cursor = conn.cursor()
                    # Aggiorna last_login
                    cursor.execute("""
                        UPDATE utenti_sistema 
                        SET last_login = CURRENT_TIMESTAMP,
                            modified_at = CURRENT_TIMESTAMP,
                            modified_by = 'system'
                        WHERE username = ?
                    """, (username,))
                    
                    # Log accesso
                    cursor.execute("""
                        INSERT INTO eventi_sistema (tipo_evento, livello, messaggio, componente)
                        VALUES (?, ?, ?, ?)
                    """, ('LOGIN', 'INFO', f'Login utente {username} ({role})', 'AUTH'))
                    
                    conn.commit()
                    logger.debug("Aggiornamento last_login e log accesso completati")
                except Exception as e:
                    logger.error(f"Errore durante l'aggiornamento del database: {e}")
                    conn.rollback()
                finally:
                    conn.close()

            # Imposta dati sessione
            session['username'] = username
            session['role'] = role
            session['logged_in'] = True
            session['login_time'] = datetime.now().strftime('%d/%m/%Y %H:%M')
            session['role_name'] = USER_ROLES.get(role, {}).get('name', 'Utente')
            session['permissions'] = USER_ROLES.get(role, {}).get('permissions', [])
            
            logger.debug("Dati sessione impostati correttamente")
            logger.debug(f"Sessione attuale: {session}")
            
            return redirect('/')
        else:
            logger.debug("Autenticazione fallita")
            return render_template_string(LOGIN_TEMPLATE, error="Credenziali non valide")
    
    # Mostra info sui livelli nel form di login
    login_info = """
    <div class="mt-4 text-center">
        <small class="text-muted">
            <strong>Utenti di test:</strong><br>
            🔴 admin/admin123 (Amministratore)<br>
            🔵 manager/manager123 (Gestore Utenti)<br>
            🟢 viewer/viewer123 (Visualizzatore)
        </small>
    </div>
    """
    
    return render_template_string(LOGIN_TEMPLATE + login_info)

@app.route('/logout')
def logout():
    """Gestisce il logout utente con gestione errori robusta"""
    try:
        username = session.get('username')
        role = session.get('role')
        
        # Log logout se possibile
        if username:
            try:
                conn = get_db_connection()
                if conn:
                    try:
                        cursor = conn.cursor()
                        cursor.execute("""
                            INSERT INTO eventi_sistema (tipo_evento, livello, messaggio, componente)
                            VALUES (?, ?, ?, ?)
                        """, ('LOGOUT', 'INFO', f'Logout utente {username} ({role})', 'AUTH'))
                        conn.commit()
                    except Exception as e:
                        logger.error(f"Errore logging logout: {e}")
                    finally:
                        conn.close()
            except Exception as e:
                logger.error(f"Errore connessione DB durante logout: {e}")
        
        # Pulisci la sessione in ogni caso
        session.clear()
        
        return redirect('/login')
        
    except Exception as e:
        logger.error(f"Errore durante logout: {e}")
        # Forza pulizia sessione anche in caso di errore
        session.clear()
        return redirect('/login')

@app.route('/api/profile/info')
@require_auth()
def api_profile_info():
    """Restituisce informazioni profilo dalla sessione"""
    return jsonify({
        'success': True,
        'user': {
            'username': session.get('username'),
            'role': session.get('role'),
            'login_time': session.get('login_time', datetime.now().strftime('%d/%m/%Y %H:%M'))
        }
    })

@app.route('/api/user-menu-html')
@require_auth()
def api_user_menu_html():
    """Restituisce HTML del menu utente con dati sessione"""
    
    # Mappa ruoli aggiornata per 3 livelli
    role_names = {
        'admin': 'Amministratore',
        'user_manager': 'Gestore Utenti', 
        'viewer': 'Visualizzatore'
    }
    
    user_role = session.get('role', 'viewer')
    user_role_name = role_names.get(user_role, 'Utente')
    username = session.get('username', 'user')
    
    # Template del menu inline
    menu_html = f'''
    <div class="user-menu-container">
        <!-- Trigger Menu -->
        <div class="user-menu-trigger">
            <div class="user-avatar">
                {username[0].upper()}
            </div>
            <div class="user-menu-info">
                <div class="user-menu-name">{username}</div>
                <div class="user-menu-role">{user_role_name}</div>
            </div>
            <i class="fas fa-chevron-down" style="color: white; font-size: 0.8rem;"></i>
        </div>
        
        <!-- Dropdown Menu -->
        <div class="user-menu-dropdown">
            <div class="user-menu-header">
                <div class="avatar-large">
                    {username[0].upper()}
                </div>
                <div class="user-name">{username}</div>
                <div class="user-email">{user_role_name}</div>
            </div>
            
            <div class="user-menu-items">
                <a href="#" class="user-menu-item" data-action="profile">
                    <i class="fas fa-user-circle"></i>
                    <span class="user-menu-item-text">Il Mio Profilo</span>
                </a>
                
                <a href="#" class="user-menu-item" data-action="change-password">
                    <i class="fas fa-key"></i>
                    <span class="user-menu-item-text">Cambio Password</span>
                </a>
                
                <div class="user-menu-divider"></div>
                
                <a href="/logout" class="user-menu-item logout">
                    <i class="fas fa-sign-out-alt"></i>
                    <span class="user-menu-item-text">Logout</span>
                </a>
            </div>
        </div>
    </div>
    
    <!-- Overlay -->
    <div class="user-menu-overlay"></div>
    '''
    
    return menu_html

# ===============================
# STATIC FILES
# ===============================

@app.route('/static/<path:path>')
def send_static(path):
    return send_from_directory(os.path.join(os.path.dirname(__file__), 'static'), path)

# ===============================
# API ENDPOINTS - DATI
# ===============================

@app.route('/api/stats')
@require_auth()
def api_stats():
    """Statistiche usando schema database_manager.py"""
    conn = get_db_connection()
    if not conn:
        return jsonify({'error': 'Database non disponibile'}), 500
    
    try:
        cursor = conn.cursor()
        
        # Oggi
        today = datetime.now().strftime('%Y-%m-%d')
        
        # Accessi oggi
        cursor.execute("""
            SELECT COUNT(*) 
            FROM log_accessi 
            WHERE DATE(timestamp) = ?
        """, (today,))
        accessi_oggi = cursor.fetchone()[0]
        
        # Accessi autorizzati oggi
        cursor.execute("""
            SELECT COUNT(*) 
            FROM log_accessi 
            WHERE DATE(timestamp) = ? AND autorizzato = 1
        """, (today,))
        autorizzati_oggi = cursor.fetchone()[0]
        
        return jsonify({
            'accessi_oggi': accessi_oggi,
            'autorizzati_oggi': autorizzati_oggi
        })
        
    except Exception as e:
        print(f"Errore API stats: {e}")
        return jsonify({'error': str(e)}), 500
    finally:
        conn.close()

@app.route('/api/users/count')
@require_auth()
def api_users_count():
    """Count utenti usando schema database_manager.py"""
    conn = get_db_connection()
    if not conn:
        return jsonify({'error': 'Database non disponibile'}), 500
    
    try:
        cursor = conn.cursor()
        cursor.execute("SELECT COUNT(*) FROM utenti_autorizzati WHERE attivo = 1")
        count = cursor.fetchone()[0]
        return jsonify({'count': count})
    except Exception as e:
        print(f"Errore API users count: {e}")
        return jsonify({'error': str(e)}), 500
    finally:
        conn.close()

@app.route('/api/recent-accesses')
@require_auth()
def api_recent_accesses():
    """Accessi recenti usando schema database_manager.py"""
    limit = request.args.get('limit', 10, type=int)
    
    conn = get_db_connection()
    if not conn:
        return jsonify({'error': 'Database non disponibile'}), 500
    
    try:
        cursor = conn.cursor()
        cursor.execute("""
            SELECT 
                la.timestamp, 
                la.codice_fiscale, 
                la.autorizzato,
                COALESCE(ua.nome || ' ' || ua.cognome, ua.nome, ua.cognome, 'Utente sconosciuto') as nome_completo
            FROM log_accessi la
            LEFT JOIN utenti_autorizzati ua ON la.codice_fiscale = ua.codice_fiscale
            ORDER BY la.timestamp DESC
            LIMIT ?
        """, (limit,))
        
        results = cursor.fetchall()
        accesses = []
        
        for row in results:
            accesses.append({
                'timestamp': row[0],
                'codice_fiscale': row[1],
                'autorizzato': bool(row[2]),
                'nome': row[3]
            })
        
        return jsonify({'accesses': accesses})
        
    except Exception as e:
        print(f"Errore API recent accesses: {e}")
        return jsonify({'error': str(e)}), 500
    finally:
        conn.close()

# ===============================
# API ENDPOINTS - TEST HARDWARE
# ===============================

@app.route('/api/test/gate')
@require_auth()
def api_test_gate():
    """Test cancello"""
    return hardware_tests.test_gate(get_db_connection)

@app.route('/api/test_relay', methods=['POST'])
@require_auth()
def api_test_relay():
    """Test USB-RLY08"""
    return hardware_tests.test_relay()

@app.route('/api/test/integrated', methods=['POST'])
@require_auth()
def api_test_integrated():
    """Test integrato completo"""
    return hardware_tests.test_integrated(get_db_connection)

@app.route('/api/hardware/test-reader', methods=['POST'])
@require_auth()
def api_hardware_test_reader():
    """Test lettore tessere - CORRETTA CHIAMATA A hardware_tests"""
    return hardware_tests.test_reader()

# ===============================
# API ENDPOINTS - STATI
# ===============================

@app.route('/api/relay_status')
@require_auth()
def api_relay_status():
    """Stato test relay"""
    return hardware_tests.get_relay_status()

@app.route('/api/integrated_status')
@require_auth()
def api_integrated_status():
    """Stato test integrato"""
    return hardware_tests.get_integrated_status()

@app.route('/api/hardware/status')
@require_auth()
def api_hardware_status():
    """Stato test hardware"""
    test_id = request.args.get('test_id')
    return hardware_tests.get_hardware_status(test_id)

# ===============================
# ROUTES GESTIONE SISTEMA ADMIN
# ===============================

@app.route('/admin/users')
@require_auth()
@require_permission('all')  # Solo admin
def admin_users():
    """Gestione completa utenti - Solo Admin"""
    with open(os.path.join(os.path.dirname(__file__), 'static', 'html', 'user-management.html'), 'r') as f:
        template = f.read()
    return render_template_string(template, session=session)

@app.route('/admin/config')
@require_auth()
@require_permission('all')  # Solo admin
def admin_config():
    """Configurazioni sistema - Solo Admin"""
    return render_template_string(ADMIN_CONFIG_TEMPLATE, session=session)

@app.route('/admin/backup')
@require_auth()
@require_permission('all')  # Solo admin
def admin_backup():
    """Backup & Restore - Solo Admin"""
    return render_template_string(ADMIN_BACKUP_TEMPLATE, session=session)

@app.route('/configurazione-orari')
@require_auth()
@require_permission('all')
def configurazione_orari():
    """Pagina configurazione orari accesso"""
    with open(os.path.join(os.path.dirname(__file__), 'templates', 'configurazione_orari.html'), 'r') as f:
        template = f.read()
    return render_template_string(template, session=session)
# ===============================
# API ENDPOINTS BACKUP (utilizzando backup_module esistente)
# ===============================

@app.route('/api/backup/status')
@require_auth()
@require_permission('all')
def api_backup_status():
    try:
        files = []
        now = datetime.now()
        for fname in os.listdir(BACKUP_DIR):
            fpath = os.path.join(BACKUP_DIR, fname)
            if os.path.isfile(fpath):
                stat = os.stat(fpath)
                ext = os.path.splitext(fname)[1]
                tipo = 'Completo' if ext == '.tar.gz' else 'Database'
                size_mb = stat.st_size / (1024 * 1024)
                created = datetime.fromtimestamp(stat.st_mtime)
                eta = now - created
                eta_str = f"{eta.days} giorni" if eta.days > 0 else f"{eta.seconds//3600} ore"
                # Checksum (opzionale)
                checksum = "-"
                files.append({
                    'name': fname,
                    'tipo': tipo,
                    'dimensione': f"{size_mb:.1f} MB" if size_mb < 1024 else f"{size_mb/1024:.1f} GB",
                    'data_creazione': created.strftime("%d/%m/%Y %H:%M"),
                    'eta': eta_str,
                    'checksum': checksum
                })
        return jsonify({'success': True, 'backups': files})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/backup/create', methods=['POST'])
@require_auth()
@require_permission('all')
def api_backup_create():
    data = request.get_json()
    backup_type = data.get('type', 'complete')
    return backup_module.create_backup(backup_type)

@app.route('/api/backup/cleanup', methods=['POST'])
@require_auth()
@require_permission('all')
def api_backup_cleanup():
    return backup_module.cleanup_old_backups()

@app.route('/api/backup/schedule', methods=['POST'])
@require_auth()
@require_permission('all')
def api_backup_schedule():
    """Salva configurazione schedulazione backup"""
    try:
        data = request.get_json()
        scheduling = data.get('scheduling', 'daily')
        retention = int(data.get('retention', 7))
        conn = get_db_connection()
        if not conn:
            return jsonify({'success': False, 'error': 'Database non disponibile'}), 500
        try:
            cursor = conn.cursor()
            cursor.execute('''
                INSERT OR REPLACE INTO system_settings (key, value, updated_at)
                VALUES (?, ?, CURRENT_TIMESTAMP)
            ''', ('backup.scheduling', scheduling))
            cursor.execute('''
                INSERT OR REPLACE INTO system_settings (key, value, updated_at)
                VALUES (?, ?, CURRENT_TIMESTAMP)
            ''', ('backup.retention', str(retention)))
            conn.commit()
            return jsonify({'success': True, 'message': 'Schedulazione backup salvata'})
        finally:
            conn.close()
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/backup/schedule')
@require_auth()
@require_permission('all')
def api_get_backup_schedule():
    """Restituisce configurazione schedulazione backup"""
    try:
        conn = get_db_connection()
        if not conn:
            return jsonify({'success': False, 'error': 'Database non disponibile'}), 500
        try:
            cursor = conn.cursor()
            cursor.execute("SELECT key, value FROM system_settings WHERE key LIKE 'backup.%'")
            settings = dict(cursor.fetchall())
            return jsonify({'success': True, 'schedule': settings})
        finally:
            conn.close()
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/backup/config', methods=['GET', 'POST'])
@require_auth()
@require_permission('all')
def api_backup_config():
    if request.method == 'GET':
        return backup_module.load_config()
    else:
        config = request.get_json()
        return backup_module.save_config(config)

# ===============================
# API ENDPOINTS CONFIGURAZIONI SISTEMA
# ===============================

@app.route('/api/system/config/save', methods=['POST'])
@require_auth()
@require_permission('all')
def api_save_system_config():
    """Salva configurazioni sistema"""
    try:
        data = request.get_json()
        conn = get_db_connection()
        if not conn:
            return jsonify({'success': False, 'error': 'Database non disponibile'}), 500
        try:
            cursor = conn.cursor()
            for section, values in data.items():
                for key, value in values.items():
                    # Forza il prefisso 'sistema.' per tutte le chiavi di sistema
                    if not section.startswith('sistema'):
                        config_key = f"sistema.{key}"
                    else:
                        config_key = f"{section}.{key}"
                    if isinstance(value, (dict, list)):
                        import json
                        json_value = json.dumps(value)
                    else:
                        json_value = str(value)
                    cursor.execute('''
                        INSERT OR REPLACE INTO system_settings (key, value, updated_at)
                        VALUES (?, ?, CURRENT_TIMESTAMP)
                    ''', (config_key, json_value))
            conn.commit()
            # Log evento
            cursor.execute('''
                INSERT INTO eventi_sistema (tipo_evento, livello, messaggio, componente)
                VALUES (?, ?, ?, ?)
            ''', ('CONFIG_UPDATE', 'INFO', 'Configurazioni sistema aggiornate', 'SYSTEM'))
            conn.commit()
            return jsonify({
                'success': True, 
                'message': 'Configurazioni salvate con successo'
            })
        finally:
            conn.close()
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

# 3. AGGIUNGI il nuovo endpoint per il reset (dopo api_system_restart, circa riga 620)
@app.route('/api/system/config/reset', methods=['POST'])
@require_auth()
@require_permission('all')
def api_reset_system_config():
    """Ripristina configurazioni ai valori default"""
    try:
        # Ottieni configurazioni default
        conn = get_db_connection()
        if not conn:
            return jsonify({'success': False, 'error': 'Database non disponibile'}), 500
        
        try:
            cursor = conn.cursor()
            
            # Crea tabella se non esiste
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS system_settings (
                    key TEXT PRIMARY KEY,
                    value TEXT NOT NULL,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            ''')
            
            # Elimina tutte le configurazioni personalizzate
            cursor.execute('DELETE FROM system_settings')
            
            # Inserisci valori default
            default_values = {
                'sistema.nome_installazione': 'Isola Ecologica RAEE - Rende',
                'sistema.versione': '1.0.0',
                'sistema.ambiente': 'production',
                'sistema.debug_mode': 'false',
                'sistema.porta_web': '5000',
                'sistema.timeout_sessione': '1800',
                
                'hardware.lettore_porta': '/dev/ttyACM0',
                'hardware.relay_porta': '/dev/ttyUSB0',
                'hardware.relay_baudrate': '19200',
                'hardware.gate_duration': '8.0',
                
                'sicurezza.max_tentativi_login': '5',
                'sicurezza.durata_blocco_minuti': '15',
                'sicurezza.rotazione_password_giorni': '90',
                'sicurezza.log_audit_abilitato': 'true',
                
                'email.smtp_server': '',
                'email.smtp_porta': '587',
                'email.mittente': '',
                'email.report_automatici': 'false',
                'email.frequenza_report': 'weekly'
            }
            
            for key, value in default_values.items():
                cursor.execute('''
                    INSERT INTO system_settings (key, value, updated_at)
                    VALUES (?, ?, CURRENT_TIMESTAMP)
                ''', (key, value))
            
            conn.commit()
            
            # Log evento
            cursor.execute('''
                INSERT INTO eventi_sistema (tipo_evento, livello, messaggio, componente)
                VALUES (?, ?, ?, ?)
            ''', ('CONFIG_RESET', 'WARNING', 'Configurazioni ripristinate ai valori default', 'SYSTEM'))
            
            conn.commit();
            
            return jsonify({
                'success': True,
                'message': 'Configurazioni ripristinate ai valori default'
            })
            
        finally:
            conn.close()
            
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/system/restart', methods=['POST'])
@require_auth()
@require_permission('all')
def api_system_restart():
    """Riavvia realmente il sistema tramite systemd"""
    try:
        import subprocess
        # Riavvia il servizio systemd (modifica il nome se necessario)
        subprocess.Popen(['sudo', 'systemctl', 'restart', 'access-control-system'])
        return jsonify({
            'success': True,
            'message': 'Sistema in riavvio...'
        })
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

# ===============================
# API ENDPOINTS CONFIGURAZIONI - USANDO CONFIG ESISTENTE
# ===============================



@app.route('/api/email/config')
@require_auth()
def api_get_email_config():
    """Ottieni configurazione email"""
    try:
        # Carica da database temporaneo
        conn = get_db_connection()
        if not conn:
            return jsonify({'success': False, 'error': 'Database non disponibile'}), 500
        
        try:
            cursor = conn.cursor()
            cursor.execute("SELECT key, value FROM system_settings WHERE key LIKE 'email.%'")
            settings = cursor.fetchall()
            
            config = {
                'smtp_server': '',
                'smtp_port': 587,
                'mittente': '',
                'frequenza_report': 'weekly',
                'orario_invio': '08:00',
                'includi_statistiche': True,
                'includi_errori': True
            }
            
            # Popola con valori salvati
            for key, value in settings:
                setting_name = key.replace('email.', '')
                if setting_name in config:
                    try:
                        # Prova a convertire numeri e boolean
                        if value.lower() in ('true', 'false'):
                            config[setting_name] = value.lower() == 'true'
                        elif value.isdigit():
                            config[setting_name] = int(value)
                        else:
                            config[setting_name] = value
                    except:
                        config[setting_name] = value
            
            return jsonify({'success': True, 'config': config})
            
        finally:
            conn.close()
            
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/email/save-smtp', methods=['POST'])
@require_auth()
@require_permission('all')
def api_save_smtp_config():
    """Salva configurazione SMTP"""
    try:
        data = request.get_json()
        
        conn = get_db_connection()
        if not conn:
            return jsonify({'success': False, 'error': 'Database non disponibile'}), 500
        
        try:
            cursor = conn.cursor()
            
            # Crea tabella se non esiste
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS system_settings (
                    key TEXT PRIMARY KEY,
                    value TEXT NOT NULL,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            ''')
            
            # Salva configurazioni email
            email_settings = {
                'smtp_server': data.get('smtp_server', ''),
                'smtp_port': str(data.get('smtp_port', 587)),
                'mittente': data.get('mittente', '')
            }
            
            for key, value in email_settings.items():
                cursor.execute('''
                    INSERT OR REPLACE INTO system_settings (key, value, updated_at)
                    VALUES (?, ?, CURRENT_TIMESTAMP)
                ''', (f'email.{key}', value))
            
            # Non salvare password per sicurezza
            if data.get('password'):
                cursor.execute('''
                    INSERT OR REPLACE INTO system_settings (key, value, updated_at)
                    VALUES (?, ?, CURRENT_TIMESTAMP)
                ''', ('email.password_set', 'true'))
            
            conn.commit()
            
            return jsonify({'success': True, 'message': 'Configurazione SMTP salvata'})
            
        finally:
            conn.close()
            
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/devices/config')
@require_auth()
def api_get_devices_config():
    """Ottieni configurazione dispositivi"""
    try:
        # Carica da database temporaneo
        conn = get_db_connection()
        if not conn:
            return jsonify({'success': False, 'error': 'Database non disponibile'}), 500
        
        try:
            cursor = conn.cursor()
            cursor.execute("SELECT key, value FROM system_settings WHERE key LIKE 'dispositivi.%'")
            settings = cursor.fetchall()
            
            config = {
                'reader': {
                    'tipo': 'HID Omnikey 5427CK',
                    'porta': '/dev/ttyACM0',
                    'timeout': 30,
                    'retry_tentativi': 3
                },
                'relay': {
                    'porta': '/dev/ttyUSB0',
                    'baud_rate': 19200,
                    'modulo_id': 8
                }
            }
            
            # Popola con valori salvati
            for key, value in settings:
                parts = key.split('.')
                if len(parts) >= 3:
                    device = parts[1]  # lettore_cf o rele
                    setting = parts[2]
                    
                    if device == 'lettore_cf' and setting in config['reader']:
                        try:
                            if setting in ['timeout', 'retry_tentativi']:
                                config['reader'][setting] = int(value)
                            else:
                                config['reader'][setting] = value
                        except:
                            config['reader'][setting] = value
                    elif device == 'rele' and setting in config['relay']:
                        try:
                            if setting in ['baud_rate', 'modulo_id']:
                                config['relay'][setting] = int(value)
                            else:
                                config['relay'][setting] = value
                        except:
                            config['relay'][setting] = value
            
            return jsonify({'success': True, **config})
            
        finally:
            conn.close()
            
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/devices/config/reader', methods=['POST'])
@require_auth()
@require_permission('all')
def api_save_reader_config():
    """Salva configurazione lettore nel database"""
    try:
        data = request.get_json()
        if not data.get('tipo') or not data.get('porta'):
            return jsonify({'success': False, 'error': 'Configurazione incompleta'}), 400

        conn = get_db_connection()
        if not conn:
            return jsonify({'success': False, 'error': 'Database non disponibile'}), 500

        try:
            cursor = conn.cursor()
            settings = {
                'dispositivi.lettore_cf.tipo': data['tipo'],
                'dispositivi.lettore_cf.porta': data['porta'],
                'dispositivi.lettore_cf.timeout': str(data.get('timeout', 30)),
                'dispositivi.lettore_cf.retry_tentativi': str(data.get('retry_tentativi', 3))
            }
            for key, value in settings.items():
                cursor.execute('''
                    INSERT OR REPLACE INTO system_settings (key, value, updated_at)
                    VALUES (?, ?, CURRENT_TIMESTAMP)
                ''', (key, value))
            conn.commit()
            return jsonify({'success': True, 'message': 'Configurazione lettore salvata'})
        finally:
            conn.close()
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/devices/config/relay', methods=['POST'])
@require_auth()
@require_permission('all')
def api_save_relay_config():
    """Salva configurazione relè nel database"""
    try:
        data = request.get_json()
        if not data.get('porta') or not data.get('baud_rate'):
            return jsonify({'success': False, 'error': 'Configurazione incompleta'}), 400

        conn = get_db_connection()
        if not conn:
            return jsonify({'success': False, 'error': 'Database non disponibile'}), 500

        try:
            cursor = conn.cursor()
            settings = {
                'dispositivi.rele.porta': data['porta'],
                'dispositivi.rele.baud_rate': str(data['baud_rate']),
                'dispositivi.rele.modulo_id': str(data.get('modulo_id', 8))
            }
            for key, value in settings.items():
                cursor.execute('''
                    INSERT OR REPLACE INTO system_settings (key, value, updated_at)
                    VALUES (?, ?, CURRENT_TIMESTAMP)
                ''', (key, value))
            # Salva mapping se presente
            if 'mapping' in data:
                import json
                cursor.execute('''
                    INSERT OR REPLACE INTO system_settings (key, value, updated_at)
                    VALUES (?, ?, CURRENT_TIMESTAMP)
                ''', ('dispositivi.rele.mapping', json.dumps(data['mapping'])))
            conn.commit()
            return jsonify({'success': True, 'message': 'Configurazione relè salvata'})
        finally:
            conn.close()
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/system/config')
@require_auth()
def api_get_system_config():
    """Restituisce tutte le configurazioni di sistema dal database"""
    try:
        conn = get_db_connection()
        if not conn:
            return jsonify({'success': False, 'error': 'Database non disponibile'}), 500

        try:
            cursor = conn.cursor()
            # Prendi tutte le chiavi di sistema, hardware, sicurezza, email
            cursor.execute("""
                SELECT key, value FROM system_settings
                WHERE key LIKE 'sistema.%'
                   OR key LIKE 'hardware.%'
                   OR key LIKE 'sicurezza.%'
                   OR key LIKE 'email.%'
            """)
            settings = cursor.fetchall()
            config = {}
            for key, value in settings:
                section, name = key.split('.', 1)
                if section not in config:
                    config[section] = {}
                config[section][name] = value
            return jsonify({'success': True, 'config': config})
        finally:
            conn.close()
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

BACKUP_DIR = os.path.join(project_root, 'backup')
if not os.path.exists(BACKUP_DIR):
    os.makedirs(BACKUP_DIR)

def get_db_connection():
    """Connessione database come database_manager.py"""
    try:
        conn = sqlite3.connect(DB_PATH)
        conn.row_factory = sqlite3.Row
        return conn
    except Exception as e:
        print(f"Errore connessione DB: {e}")
        return None

def ensure_system_settings_table():
    conn = get_db_connection()
    if conn:
        try:
            cursor = conn.cursor()
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS system_settings (
                    key TEXT PRIMARY KEY,
                    value TEXT NOT NULL,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            ''')
            conn.commit()
        finally:
            conn.close()

def ensure_eventi_sistema_table():
    conn = get_db_connection()
    if conn:
        try:
            cursor = conn.cursor()
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS eventi_sistema (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    tipo_evento TEXT,
                    livello TEXT,
                    messaggio TEXT,
                    componente TEXT,
                    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
                )
            ''')
            conn.commit()
        finally:
            conn.close()

# Ora puoi chiamarla!
config_manager = get_config_manager()
ensure_system_settings_table()
ensure_eventi_sistema_table()

# ===============================
# MAIN
# ===============================

if __name__ == '__main__':
    print("🌐 Avvio dashboard web modulare")
    print(f"📄 Database: {DB_PATH}")
    print("🔗 URL: http://0.0.0.0:5000")
    
    # Crea directory static se non esiste
    static_dir = os.path.join(os.path.dirname(__file__), 'static')
    if not os.path.exists(static_dir):
        os.makedirs(static_dir)
        print(f"📁 Creata directory static: {static_dir}")
    
    app.run(host='0.0.0.0', port=5000, debug=False, threaded=True)

print("=== ENDPOINTS REGISTRATI ===")
for rule in app.url_map.iter_rules():
    print(rule)
print("============================")

def scheduled_backup():
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    backup_filename = f'access_{timestamp}.db'
    src = DB_PATH
    dst = os.path.join(BACKUP_DIR, backup_filename)
    shutil.copy2(src, dst)
    print(f"[SCHEDULER] Backup creato: {backup_filename}")

    # Retention
    conn = get_db_connection()
    retention = 7
    if conn:
        try:
            cursor = conn.cursor()
            cursor.execute("SELECT value FROM system_settings WHERE key='backup.retention'")
            row = cursor.fetchone()
            if row:
                retention = int(row[0])
        finally:
            conn.close()
    files = sorted(
        [os.path.join(BACKUP_DIR, f) for f in os.listdir(BACKUP_DIR) if os.path.isfile(os.path.join(BACKUP_DIR, f))],
        key=lambda x: os.path.getmtime(x)
    )
    to_delete = files[:-retention]
    for f in to_delete:
        os.remove(f)
        print(f"[SCHEDULER] Backup eliminato per retention: {os.path.basename(f)}")

# Scarica backup
@app.route('/api/backup/download/<filename>')
@require_auth()
@require_permission('all')
def api_backup_download(filename: str) -> FlaskResponse:
    return send_from_directory(BACKUP_DIR, filename, as_attachment=True)

# Elimina backup
@app.route('/api/backup/delete/<filename>', methods=['DELETE'])
@require_auth()
@require_permission('all')
def api_backup_delete(filename: str) -> FlaskResponse:
    try:
        fpath = os.path.join(BACKUP_DIR, filename)
        if os.path.exists(fpath):
            os.remove(fpath)
            return jsonify({'success': True, 'message': 'Backup eliminato'})
        else:
            return jsonify({'success': False, 'error': 'File non trovato'}), 404
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

# Ripristina backup (sovrascrive access.db)
@app.route('/api/backup/restore/<filename>', methods=['POST'])
@require_auth()
@require_permission('all')
def api_backup_restore(filename: str) -> FlaskResponse:
    try:
        fpath = os.path.join(BACKUP_DIR, filename)
        if os.path.exists(fpath):
            shutil.copy2(fpath, DB_PATH)
            return jsonify({'success': True, 'message': 'Backup ripristinato'})
        else:
            return jsonify({'success': False, 'error': 'File non trovato'}), 404
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500
