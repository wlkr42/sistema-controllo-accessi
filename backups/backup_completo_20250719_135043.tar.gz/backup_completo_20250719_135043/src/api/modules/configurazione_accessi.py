from flask import Blueprint, jsonify, request, session
from datetime import datetime, time
from ..utils import get_db_connection, require_auth, require_permission
from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.triggers.cron import CronTrigger

configurazione_accessi_bp = Blueprint('configurazione_accessi', __name__)

def init_scheduler():
    """Inizializza lo scheduler per il reset mensile dei contatori"""
    scheduler = BackgroundScheduler()
    
    # Esegui il reset alle 00:01 del primo giorno di ogni mese
    scheduler.add_job(
        reset_contatori_mensili,
        trigger=CronTrigger(day='1', hour='0', minute='1'),
        id='reset_contatori_mensili'
    )
    
    scheduler.start()

def reset_contatori_mensili():
    """Resetta i contatori e riattiva gli utenti il primo del mese"""
    conn = get_db_connection()
    if not conn:
        return
    
    try:
        cursor = conn.cursor()
        
        # Archivia i conteggi del mese precedente
        cursor.execute("""
            INSERT INTO conteggio_ingressi_mensili_archive
            SELECT *, CURRENT_TIMESTAMP as data_archiviazione
            FROM conteggio_ingressi_mensili
        """)
        
        # Elimina i conteggi correnti
        cursor.execute("DELETE FROM conteggio_ingressi_mensili")
        
        # Riattiva tutti gli utenti disattivati per limite ingressi
        cursor.execute("""
            UPDATE utenti_autorizzati 
            SET attivo = 1,
                data_modifica = CURRENT_TIMESTAMP,
                modificato_da = 'system'
            WHERE attivo = 0
        """)
        
        conn.commit()
        
    except Exception as e:
        print(f"Errore reset contatori: {e}")
        
    finally:
        conn.close()

def check_orario_apertura(codice_fiscale):
    """Verifica se l'orario corrente è all'interno dell'intervallo di apertura"""
    conn = get_db_connection()
    if not conn:
        return False, "Errore connessione database"
    
    try:
        cursor = conn.cursor()
        
        # Ottieni il giorno della settimana (0=domenica, 6=sabato)
        giorno_settimana = datetime.now().weekday()
        if giorno_settimana == 6:  # Se è domenica (6), imposta a 0
            giorno_settimana = 0
        else:  # Altrimenti aggiungi 1 per allineare con il nostro schema
            giorno_settimana += 1
            
        ora_corrente = datetime.now().time()
        
        # Verifica orari del giorno
        cursor.execute("""
            SELECT isola_aperta, 
                   mattina_apertura, mattina_chiusura,
                   pomeriggio_apertura, pomeriggio_chiusura
            FROM orari_settimanali 
            WHERE giorno = ?
        """, (giorno_settimana,))
        
        row = cursor.fetchone()
        if not row:
            return False, "Configurazione orari non trovata"
            
        isola_aperta, m_open, m_close, p_open, p_close = row
        
        if not isola_aperta:
            return False, "L'isola ecologica è chiusa oggi"
            
        # Converti stringhe orari in oggetti time
        def parse_time(t):
            return datetime.strptime(t, '%H:%M').time() if t else None
            
        m_open = parse_time(m_open)
        m_close = parse_time(m_close)
        p_open = parse_time(p_open)
        p_close = parse_time(p_close)
        
        # Verifica se l'ora corrente è in uno degli intervalli
        in_mattina = (m_open and m_close and m_open <= ora_corrente <= m_close)
        in_pomeriggio = (p_open and p_close and p_open <= ora_corrente <= p_close)
        
        if not (in_mattina or in_pomeriggio):
            return False, "L'isola ecologica è chiusa in questo orario"
            
        return True, "Orario di accesso valido"
        
    finally:
        conn.close()

def check_limite_ingressi(codice_fiscale):
    """Verifica se l'utente ha raggiunto il limite mensile di ingressi"""
    conn = get_db_connection()
    if not conn:
        return False, "Errore connessione database"
    
    try:
        cursor = conn.cursor()
        
        # Ottieni il limite configurato per l'utente
        cursor.execute("""
            SELECT max_ingressi_mensili 
            FROM limiti_utenti 
            WHERE codice_fiscale = ?
        """, (codice_fiscale,))
        
        row = cursor.fetchone()
        max_ingressi = row[0] if row else 10  # Default 10 se non configurato
        
        # Ottieni il conteggio del mese corrente
        now = datetime.now()
        cursor.execute("""
            SELECT numero_ingressi 
            FROM conteggio_ingressi_mensili 
            WHERE codice_fiscale = ? AND mese = ? AND anno = ?
        """, (codice_fiscale, now.month, now.year))
        
        row = cursor.fetchone()
        ingressi_attuali = row[0] if row else 0
        
        if ingressi_attuali >= max_ingressi:
            # Disattiva l'utente
            cursor.execute("""
                UPDATE utenti_autorizzati 
                SET attivo = 0,
                    data_modifica = CURRENT_TIMESTAMP,
                    modificato_da = 'system'
                WHERE codice_fiscale = ?
            """, (codice_fiscale,))
            
            conn.commit()
            return False, f"Limite mensile di {max_ingressi} ingressi raggiunto"
            
        return True, "Ingresso consentito"
        
    finally:
        conn.close()

def incrementa_contatore_ingressi(codice_fiscale):
    """Incrementa il contatore degli ingressi mensili per l'utente"""
    conn = get_db_connection()
    if not conn:
        return False
    
    try:
        cursor = conn.cursor()
        now = datetime.now()
        
        # Inserisci o aggiorna il conteggio
        cursor.execute("""
            INSERT INTO conteggio_ingressi_mensili 
                (codice_fiscale, mese, anno, numero_ingressi, ultimo_ingresso)
            VALUES (?, ?, ?, 1, CURRENT_TIMESTAMP)
            ON CONFLICT(codice_fiscale, mese, anno) 
            DO UPDATE SET 
                numero_ingressi = numero_ingressi + 1,
                ultimo_ingresso = CURRENT_TIMESTAMP
        """, (codice_fiscale, now.month, now.year))
        
        conn.commit()
        return True
        
    except Exception as e:
        print(f"Errore incremento contatore: {e}")
        return False
        
    finally:
        conn.close()

# API Endpoints

@configurazione_accessi_bp.route('/api/configurazione/orari', methods=['GET'])
@require_auth()
def get_orari():
    """Ottieni la configurazione degli orari"""
    conn = get_db_connection()
    if not conn:
        return jsonify({'success': False, 'error': 'Database non disponibile'}), 500
    
    try:
        cursor = conn.cursor()
        cursor.execute("""
            SELECT giorno, isola_aperta,
                   mattina_apertura, mattina_chiusura,
                   pomeriggio_apertura, pomeriggio_chiusura
            FROM orari_settimanali
            ORDER BY giorno
        """)
        
        schedule = {}
        for row in cursor.fetchall():
            schedule[row[0]] = {
                'isola_aperta': bool(row[1]),
                'mattina_apertura': row[2],
                'mattina_chiusura': row[3],
                'pomeriggio_apertura': row[4],
                'pomeriggio_chiusura': row[5]
            }
            
        return jsonify({
            'success': True,
            'schedule': schedule
        })
        
    finally:
        conn.close()

@configurazione_accessi_bp.route('/api/configurazione/orari', methods=['POST'])
@require_auth()
@require_permission('all')
def save_orari():
    """Salva la configurazione degli orari"""
    data = request.get_json()
    schedule = data.get('schedule')
    
    if not schedule:
        return jsonify({
            'success': False,
            'error': 'Dati mancanti'
        }), 400
    
    conn = get_db_connection()
    if not conn:
        return jsonify({'success': False, 'error': 'Database non disponibile'}), 500
    
    try:
        cursor = conn.cursor()
        
        for giorno, config in schedule.items():
            cursor.execute("""
                INSERT OR REPLACE INTO orari_settimanali (
                    giorno, isola_aperta,
                    mattina_apertura, mattina_chiusura,
                    pomeriggio_apertura, pomeriggio_chiusura,
                    modificato_da
                ) VALUES (?, ?, ?, ?, ?, ?, ?)
            """, (
                int(giorno),
                config['isola_aperta'],
                config['mattina_apertura'],
                config['mattina_chiusura'],
                config['pomeriggio_apertura'],
                config['pomeriggio_chiusura'],
                session.get('username')
            ))
        
        conn.commit()
        
        return jsonify({
            'success': True,
            'message': 'Configurazione orari salvata con successo'
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500
        
    finally:
        conn.close()

@configurazione_accessi_bp.route('/api/configurazione/limiti', methods=['GET'])
@require_auth()
def get_limiti():
    """Ottieni la configurazione dei limiti di ingressi"""
    codice_fiscale = request.args.get('codice_fiscale')
    
    conn = get_db_connection()
    if not conn:
        return jsonify({'success': False, 'error': 'Database non disponibile'}), 500
    
    try:
        cursor = conn.cursor()
        
        # Ottieni il limite default dal sistema
        cursor.execute("""
            SELECT value FROM system_settings 
            WHERE key = 'sistema.max_ingressi_mensili'
        """)
        row = cursor.fetchone()
        default_limit = int(row[0]) if row else 10
        
        if codice_fiscale:
            # Ottieni limite specifico utente
            cursor.execute("""
                SELECT max_ingressi_mensili 
                FROM limiti_utenti 
                WHERE codice_fiscale = ?
            """, (codice_fiscale,))
            
            row = cursor.fetchone()
            return jsonify({
                'success': True,
                'max_ingressi_mensili': row[0] if row else default_limit
            })
        else:
            # Ottieni il limite default
            return jsonify({
                'success': True,
                'max_ingressi_mensili': default_limit
            })
        
    finally:
        conn.close()

@configurazione_accessi_bp.route('/api/configurazione/limiti', methods=['POST'])
@require_auth()
@require_permission('all')
def save_limiti():
    """Salva la configurazione dei limiti di ingressi"""
    data = request.get_json()
    
    codice_fiscale = data.get('codice_fiscale')
    max_ingressi = data.get('max_ingressi_mensili')
    
    if not max_ingressi or max_ingressi < 1:
        return jsonify({
            'success': False,
            'error': 'Numero massimo ingressi non valido'
        }), 400
    
    conn = get_db_connection()
    if not conn:
        return jsonify({'success': False, 'error': 'Database non disponibile'}), 500
    
    try:
        cursor = conn.cursor()
        
        if codice_fiscale:
            # Aggiorna limite specifico utente
            cursor.execute("""
                INSERT OR REPLACE INTO limiti_utenti (
                    codice_fiscale, max_ingressi_mensili, modificato_da
                ) VALUES (?, ?, ?)
            """, (codice_fiscale, max_ingressi, session.get('username')))
        else:
            # Aggiorna limite default nel sistema
            cursor.execute("""
                INSERT OR REPLACE INTO system_settings (
                    key, value, updated_at
                ) VALUES (?, ?, CURRENT_TIMESTAMP)
            """, ('sistema.max_ingressi_mensili', str(max_ingressi)))
        
        conn.commit()
        
        return jsonify({
            'success': True,
            'message': 'Limite ingressi salvato con successo'
        })
        
    finally:
        conn.close()

# Inizializza lo scheduler al caricamento del modulo
init_scheduler()
