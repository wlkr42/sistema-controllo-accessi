# File: /opt/access_control/src/api/web_api.py
# Dashboard web allineata a database_manager.py esistente

from flask import Flask, render_template_string, request, jsonify, session, redirect
from flask_cors import CORS
import sqlite3
import logging
import os
from datetime import datetime, timedelta
import hashlib

app = Flask(__name__)
app.secret_key = 'raee-2025-access-control-system'
CORS(app)

# Database path come database_manager.py
DB_PATH = os.path.join(os.path.dirname(__file__), '..', 'access.db')

# Users predefiniti (hashati)
USERS = {
    'admin': {'password': hashlib.sha256('admin123'.encode()).hexdigest(), 'role': 'admin'},
    'gestore': {'password': hashlib.sha256('gestore123'.encode()).hexdigest(), 'role': 'gestore'},
    'readonly': {'password': hashlib.sha256('readonly123'.encode()).hexdigest(), 'role': 'readonly'}
}

def get_db_connection():
    """Connessione database come database_manager.py"""
    try:
        conn = sqlite3.connect(DB_PATH)
        conn.row_factory = sqlite3.Row
        return conn
    except Exception as e:
        print(f"Errore connessione DB: {e}")
        return None

def require_auth():
    """Decorator autenticazione"""
    def decorator(f):
        def wrapper(*args, **kwargs):
            if 'username' not in session:
                return redirect('/login')
            return f(*args, **kwargs)
        wrapper.__name__ = f.__name__
        return wrapper
    return decorator

# ===============================
# ROUTES PRINCIPALI
# ===============================

@app.route('/')
@require_auth()
def dashboard():
    """Dashboard principale con schema database_manager.py"""
    return render_template_string(DASHBOARD_TEMPLATE)

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        password_hash = hashlib.sha256(password.encode()).hexdigest()
        
        if username in USERS and USERS[username]['password'] == password_hash:
            session['username'] = username
            session['role'] = USERS[username]['role']
            return redirect('/')
        else:
            return render_template_string(LOGIN_TEMPLATE, error="Credenziali non valide")
    
    return render_template_string(LOGIN_TEMPLATE)

@app.route('/logout')
def logout():
    session.clear()
    return redirect('/login')

# ===============================
# API ENDPOINTS - SCHEMA CORRETTO
# ===============================

@app.route('/api/stats')
@require_auth()
def api_stats():
    """Statistiche usando schema database_manager.py"""
    conn = get_db_connection()
    if not conn:
        return jsonify({'error': 'Database non disponibile'}), 500
    
    try:
        cursor = conn.cursor()
        
        # Oggi
        today = datetime.now().strftime('%Y-%m-%d')
        
        # Accessi oggi - SCHEMA CORRETTO log_accessi
        cursor.execute("""
            SELECT COUNT(*) 
            FROM log_accessi 
            WHERE DATE(timestamp) = ?
        """, (today,))
        accessi_oggi = cursor.fetchone()[0]
        
        # Accessi autorizzati oggi - COLONNA CORRETTA autorizzato
        cursor.execute("""
            SELECT COUNT(*) 
            FROM log_accessi 
            WHERE DATE(timestamp) = ? AND autorizzato = 1
        """, (today,))
        autorizzati_oggi = cursor.fetchone()[0]
        
        return jsonify({
            'accessi_oggi': accessi_oggi,
            'autorizzati_oggi': autorizzati_oggi
        })
        
    except Exception as e:
        print(f"Errore API stats: {e}")
        return jsonify({'error': str(e)}), 500
    finally:
        conn.close()

@app.route('/api/users/count')
@require_auth()
def api_users_count():
    """Count utenti usando schema database_manager.py"""
    conn = get_db_connection()
    if not conn:
        return jsonify({'error': 'Database non disponibile'}), 500
    
    try:
        cursor = conn.cursor()
        # TABELLA CORRETTA utenti_autorizzati
        cursor.execute("SELECT COUNT(*) FROM utenti_autorizzati WHERE attivo = 1")
        count = cursor.fetchone()[0]
        return jsonify({'count': count})
    except Exception as e:
        print(f"Errore API users count: {e}")
        return jsonify({'error': str(e)}), 500
    finally:
        conn.close()

@app.route('/api/recent-accesses')
@require_auth()
def api_recent_accesses():
    """Accessi recenti usando schema database_manager.py"""
    limit = request.args.get('limit', 10, type=int)
    
    conn = get_db_connection()
    if not conn:
        return jsonify({'error': 'Database non disponibile'}), 500
    
    try:
        cursor = conn.cursor()
        # JOIN CORRETTO con nomi tabelle italiane
        cursor.execute("""
            SELECT 
                la.timestamp, 
                la.codice_fiscale, 
                la.autorizzato,
                COALESCE(ua.nome || ' ' || ua.cognome, ua.nome, ua.cognome, 'Utente sconosciuto') as nome_completo
            FROM log_accessi la
            LEFT JOIN utenti_autorizzati ua ON la.codice_fiscale = ua.codice_fiscale
            ORDER BY la.timestamp DESC
            LIMIT ?
        """, (limit,))
        
        results = cursor.fetchall()
        accesses = []
        
        for row in results:
            accesses.append({
                'timestamp': row[0],
                'codice_fiscale': row[1],
                'autorizzato': bool(row[2]),
                'nome': row[3]
            })
        
        return jsonify({'accesses': accesses})
        
    except Exception as e:
        print(f"Errore API recent accesses: {e}")
        return jsonify({'error': str(e)}), 500
    finally:
        conn.close()

@app.route('/api/test/gate')
@require_auth()
def api_test_gate():
    """Test cancello"""
    try:
        # Import controller come nel main.py
        import sys
        sys.path.insert(0, '/opt/access_control/src/hardware')
        from usb_rly08_controller import USBRLY08Controller

# ===== IMPORT AGGIUNTIVI PER TEST HARDWARE =====
import threading
import time
from pathlib import Path

# Import moduli hardware con fallback
try:
    from hardware.card_reader import CardReader
    CARD_READER_AVAILABLE = True
except ImportError as e:
    print(f"⚠️ CardReader non disponibile: {e}")
    CardReader = None
    CARD_READER_AVAILABLE = False

try:
    from hardware.usb_rly08_controller import USBRLY08Controller
    USB_RLY08_AVAILABLE = True
except ImportError as e:
    print(f"⚠️ USB-RLY08 non disponibile: {e}")
    USBRLY08Controller = None
    USB_RLY08_AVAILABLE = False

# Variabili globali per test
test_results = {}
test_lock = threading.Lock()
# ===== FINE IMPORT AGGIUNTIVI =====

        
        controller = USBRLY08Controller()
        if controller.connect():
            controller.open_gate()
            return jsonify({'success': True, 'message': 'Cancello aperto per test'})
        else:
            return jsonify({'success': False, 'error': 'Impossibile connettersi al controller'})
    except Exception as e:
        return jsonify({'success': False, 'error': f'Errore test cancello: {str(e)}'})

# ===============================
# TEMPLATES
# ===============================

LOGIN_TEMPLATE = """
<!DOCTYPE html>
<html>
<head>
    <title>Sistema Controllo Accessi - Login</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        body { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); min-height: 100vh; }
        .login-container { max-width: 400px; margin: 0 auto; padding-top: 100px; }
        .card { border: none; border-radius: 15px; box-shadow: 0 8px 30px rgba(0,0,0,0.1); }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="card">
            <div class="card-body p-5">
                <div class="text-center mb-4">
                    <i class="fas fa-shield-alt fa-3x text-primary mb-3"></i>
                    <h4>Sistema Controllo Accessi</h4>
                    <p class="text-muted">Isola Ecologica RAEE - Rende</p>
                </div>
                
                {% if error %}
                <div class="alert alert-danger">{{ error }}</div>
                {% endif %}
                
                <form method="POST">
                    <div class="mb-3">
                        <label class="form-label">Username</label>
                        <input type="text" class="form-control" name="username" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Password</label>
                        <input type="password" class="form-control" name="password" required>
                    </div>
                    <button type="submit" class="btn btn-primary w-100">
                        <i class="fas fa-sign-in-alt me-2"></i>Accedi
                    </button>
                </form>
                
                <div class="mt-4 text-center">
                    <small class="text-muted">
                        Credenziali: admin/admin123, gestore/gestore123, readonly/readonly123
                    </small>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
"""

DASHBOARD_TEMPLATE = """
<!DOCTYPE html>
<html>
<head>
    <title>Sistema Controllo Accessi - Dashboard</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        body { background-color: #f8f9fa; }
        .navbar { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); }
        .stat-card { border: none; border-radius: 15px; box-shadow: 0 4px 15px rgba(0,0,0,0.1); transition: transform 0.2s; }
        .stat-card:hover { transform: translateY(-5px); }
        .stat-number { font-size: 2.5rem; font-weight: bold; }
        .hardware-card { border-radius: 15px; box-shadow: 0 4px 15px rgba(0,0,0,0.1); }
    </style>
</head>
<body>
    <nav class="navbar navbar-dark">
        <div class="container-fluid">
            <span class="navbar-brand mb-0 h1">
                <i class="fas fa-shield-alt me-2"></i>Sistema Controllo Accessi
            </span>
            <div class="navbar-nav">
                <span class="navbar-text me-3">Isola Ecologica RAEE - Rende | Dashboard Finale</span>
                <a href="/logout" class="btn btn-outline-light btn-sm">
                    <i class="fas fa-sign-out-alt me-1"></i>Logout
                </a>
            </div>
        </div>
    </nav>

    <div class="container-fluid mt-4">
        <!-- Statistiche -->
        <div class="row mb-4">
            <div class="col-md-4">
                <div class="card stat-card">
                    <div class="card-body text-center">
                        <i class="fas fa-clock fa-2x text-primary mb-3"></i>
                        <div class="stat-number text-primary" id="accessi-oggi">-</div>
                        <h6 class="text-muted">Accessi Oggi</h6>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card stat-card">
                    <div class="card-body text-center">
                        <i class="fas fa-check-circle fa-2x text-success mb-3"></i>
                        <div class="stat-number text-success" id="autorizzati">-</div>
                        <h6 class="text-muted">Autorizzati</h6>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card stat-card">
                    <div class="card-body text-center">
                        <i class="fas fa-users fa-2x text-info mb-3"></i>
                        <div class="stat-number text-info" id="utenti-totali">-</div>
                        <h6 class="text-muted">Utenti Totali</h6>
                    </div>
                </div>
            </div>
        </div>

        <!-- Hardware Test + Accessi Recenti -->
        <div class="row">
            <div class="col-md-6">
                <div class="card hardware-card">
                    <div class="card-header">
                        <h5><i class="fas fa-cogs me-2"></i>Test Hardware</h5>
                    </div>
                    <div class="card-body">
                        <button class="btn btn-success btn-lg w-100" onclick="testGate()">
                            <i class="fas fa-door-open me-2"></i>Test Cancello
                        </button>
                        <div id="gate-status" class="mt-3"></div>
                    </div>
                </div>
            </div>
            
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header">
                        <h5><i class="fas fa-history me-2"></i>Ultimi Accessi</h5>
                    </div>
                    <div class="card-body" id="recent-accesses">
                        <div class="text-center text-muted">Caricamento...</div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Carica dati dashboard
        function loadDashboardData() {
            // Statistiche
            fetch('/api/stats')
                .then(response => response.json())
                .then(data => {
                    if (!data.error) {
                        document.getElementById('accessi-oggi').textContent = data.accessi_oggi || '0';
                        document.getElementById('autorizzati').textContent = data.autorizzati_oggi || '0';
                    }
                })
                .catch(error => console.error('Errore stats:', error));

            // Utenti totali
            fetch('/api/users/count')
                .then(response => response.json())
                .then(data => {
                    if (!data.error) {
                        document.getElementById('utenti-totali').textContent = data.count || '0';
                    }
                })
                .catch(error => console.error('Errore users count:', error));

            // Accessi recenti
            fetch('/api/recent-accesses')
                .then(response => response.json())
                .then(data => {
                    if (!data.error && data.accesses) {
                        let html = '';
                        data.accesses.slice(0, 5).forEach(access => {
                            const status = access.autorizzato ? 
                                '<span class="badge bg-success">Autorizzato</span>' : 
                                '<span class="badge bg-danger">Negato</span>';
                            const time = new Date(access.timestamp).toLocaleTimeString();
                            html += `
                                <div class="d-flex justify-content-between align-items-center border-bottom py-2">
                                    <div>
                                        <strong>${access.nome}</strong><br>
                                        <small class="text-muted">${access.codice_fiscale}</small>
                                    </div>
                                    <div class="text-end">
                                        ${status}<br>
                                        <small class="text-muted">${time}</small>
                                    </div>
                                </div>
                            `;
                        });
                        document.getElementById('recent-accesses').innerHTML = html || '<div class="text-muted">Nessun accesso recente</div>';
                    }
                })
                .catch(error => console.error('Errore recent accesses:', error));
        }

        // Test cancello
        function testGate() {
            const btn = event.target;
            const status = document.getElementById('gate-status');
            
            btn.disabled = true;
            btn.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Test in corso...';
            status.innerHTML = '<div class="alert alert-info">Test cancello in corso...</div>';
            
            fetch('/api/test/gate')
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        status.innerHTML = '<div class="alert alert-success">✅ Test cancello completato con successo</div>';
                    } else {
                        status.innerHTML = `<div class="alert alert-danger">❌ ${data.error}</div>`;
                    }
                })
                .catch(error => {
                    status.innerHTML = `<div class="alert alert-danger">❌ Errore comunicazione: ${error}</div>`;
                })
                .finally(() => {
                    btn.disabled = false;
                    btn.innerHTML = '<i class="fas fa-door-open me-2"></i>Test Cancello';
                    setTimeout(() => status.innerHTML = '', 5000);
                });
        }

        // Auto-refresh ogni 5 secondi
        loadDashboardData();
        setInterval(loadDashboardData, 5000);
    </script>
</body>
</html>
"""


# ===== API TEST HARDWARE =====

@app.route('/api/test/reader', methods=['POST'])
@require_auth()
def api_test_reader():
    """API per test lettore tessere con feedback real-time"""
    global test_results
    
    if not CARD_READER_AVAILABLE:
        return jsonify({
            'success': False,
            'error': 'Modulo CardReader non disponibile'
        }), 500
    
    with test_lock:
        test_results['reader'] = {
            'status': 'running',
            'message': 'Test lettore in corso...',
            'timestamp': time.time(),
            'details': []
        }
    
    def run_reader_test():
        """Test lettore in thread separato"""
        try:
            details = []
            details.append("🔄 Inizializzazione lettore OMNIKEY 5427CK...")
            
            with test_lock:
                test_results['reader']['details'] = details.copy()
            
            reader = CardReader()
            
            # Test connessione
            details.append("🔌 Test connessione lettori...")
            if reader.test_connection():
                details.append(f"✅ Trovati {len(reader.readers)} lettori")
                for i, r in enumerate(reader.readers):
                    details.append(f"   Lettore {i+1}: {str(r)}")
            else:
                details.append("❌ Nessun lettore smart card trovato")
                with test_lock:
                    test_results['reader'] = {
                        'status': 'error',
                        'message': 'Nessun lettore trovato',
                        'timestamp': time.time(),
                        'details': details
                    }
                return
            
            # Test APDU
            details.append("💳 Test sequenza APDU...")
            details.append("   Inserire tessera sanitaria per test completo...")
            
            with test_lock:
                test_results['reader']['details'] = details.copy()
                test_results['reader']['message'] = 'Pronto per tessera (timeout 8s)...'
            
            # Test con timeout
            start_time = time.time()
            timeout = 8
            card_found = False
            
            while (time.time() - start_time) < timeout and not card_found:
                try:
                    cf = reader._read_card_robust(timeout=1)
                    if cf and len(cf) == 16:
                        details.append(f"✅ Tessera letta: {cf}")
                        details.append("✅ Sequenza APDU ISO7816 OK")
                        details.append("✅ Estrazione codice fiscale OK")
                        details.append("✅ Formato codice fiscale valido")
                        card_found = True
                        break
                except:
                    pass
                
                remaining = int(timeout - (time.time() - start_time))
                with test_lock:
                    test_results['reader']['message'] = f'Attendere tessera (timeout: {remaining}s)'
            
            if card_found:
                details.append("🎯 TEST LETTORE COMPLETATO CON SUCCESSO!")
                final_status = 'success'
                final_message = 'Lettore completamente funzionante'
            else:
                details.append("⚠️ Timeout - nessuna tessera inserita")
                details.append("💡 Hardware lettore operativo")
                final_status = 'warning'
                final_message = 'Hardware OK - Nessuna tessera testata'
            
            with test_lock:
                test_results['reader'] = {
                    'status': final_status,
                    'message': final_message,
                    'timestamp': time.time(),
                    'details': details
                }
                
        except Exception as e:
            with test_lock:
                test_results['reader'] = {
                    'status': 'error',
                    'message': f'Errore test: {str(e)}',
                    'timestamp': time.time(),
                    'details': details + [f"❌ Errore: {str(e)}"]
                }
    
    threading.Thread(target=run_reader_test, daemon=True).start()
    
    return jsonify({
        'success': True,
        'message': 'Test lettore avviato',
        'test_id': 'reader'
    })

@app.route('/api/test/relay', methods=['POST'])
@require_auth()
def api_test_relay():
    """API per test USB-RLY08 con feedback real-time"""
    global test_results
    
    if not USB_RLY08_AVAILABLE:
        return jsonify({
            'success': False,
            'error': 'Modulo USB-RLY08 non disponibile'
        }), 500
    
    with test_lock:
        test_results['relay'] = {
            'status': 'running',
            'message': 'Test USB-RLY08 in corso...',
            'timestamp': time.time(),
            'details': []
        }
    
    def run_relay_test():
        """Test USB-RLY08 in thread separato"""
        try:
            details = []
            details.append("🔄 Inizializzazione USB-RLY08...")
            
            with test_lock:
                test_results['relay']['details'] = details.copy()
            
            # Test connessione su porte multiple
            ports_to_test = ["/dev/ttyACM0", "/dev/ttyUSB0"]
            controller = None
            connected_port = None
            
            for port in ports_to_test:
                details.append(f"🔌 Test connessione {port}...")
                with test_lock:
                    test_results['relay']['details'] = details.copy()
                
                try:
                    test_controller = USBRLY08Controller(port=port)
                    if test_controller.connect():
                        details.append(f"✅ USB-RLY08 connesso a {port}")
                        controller = test_controller
                        connected_port = port
                        break
                    else:
                        details.append(f"❌ Connessione fallita a {port}")
                except Exception as e:
                    details.append(f"❌ Errore {port}: {str(e)}")
            
            if not controller:
                details.append("❌ USB-RLY08 non trovato su nessuna porta")
                with test_lock:
                    test_results['relay'] = {
                        'status': 'error',
                        'message': 'USB-RLY08 non collegato',
                        'timestamp': time.time(),
                        'details': details
                    }
                return
            
            # Test comunicazione
            details.append("📋 Test comunicazione seriale...")
            with test_lock:
                test_results['relay']['details'] = details.copy()
            
            if controller.health_check():
                details.append("✅ Comunicazione seriale OK")
            else:
                details.append("❌ Errore comunicazione")
                controller.disconnect()
                with test_lock:
                    test_results['relay'] = {
                        'status': 'error',
                        'message': 'Errore comunicazione',
                        'timestamp': time.time(),
                        'details': details
                    }
                return
            
            # Test stati relè
            details.append("�� Lettura stati relè...")
            states = controller.get_relay_states()
            if states:
                details.append(f"✅ Stati letti: {len(states)} relè disponibili")
                for name, state in list(states.items())[:3]:  # Mostra primi 3
                    status = "ON" if state else "OFF"
                    details.append(f"   {name}: {status}")
            
            with test_lock:
                test_results['relay']['details'] = details.copy()
            
            # Test sicuro relè (lampeggio veloce)
            details.append("🔧 Test funzionamento relè...")
            
            # Test LED Verde
            details.append("   🟢 Test LED Verde...")
            controller._set_relay_state(controller.RelayChannel.LED_GREEN, True)
            time.sleep(0.3)
            controller._set_relay_state(controller.RelayChannel.LED_GREEN, False)
            details.append("   ✅ LED Verde OK")
            
            time.sleep(0.2)
            
            # Test LED Rosso
            details.append("   🔴 Test LED Rosso...")
            controller._set_relay_state(controller.RelayChannel.LED_RED, True)
            time.sleep(0.3)
            controller._set_relay_state(controller.RelayChannel.LED_RED, False)
            details.append("   ✅ LED Rosso OK")
            
            time.sleep(0.2)
            
            # Test funzioni sistema
            details.append("🎯 Test segnalazioni sistema...")
            controller.access_granted()  # LED Verde + Buzzer
            time.sleep(1)
            details.append("   ✅ Segnalazione accesso OK")
            
            # Spegni tutto
            controller.emergency_stop()
            details.append("💡 Spegnimento tutti i relè...")
            
            # Disconnessione
            controller.disconnect()
            details.append("🎯 TEST USB-RLY08 COMPLETATO CON SUCCESSO!")
            
            with test_lock:
                test_results['relay'] = {
                    'status': 'success',
                    'message': f'USB-RLY08 completamente funzionante su {connected_port}',
                    'timestamp': time.time(),
                    'details': details
                }
                
        except Exception as e:
            if 'controller' in locals() and controller:
                try:
                    controller.disconnect()
                except:
                    pass
            
            with test_lock:
                test_results['relay'] = {
                    'status': 'error',
                    'message': f'Errore test: {str(e)}',
                    'timestamp': time.time(),
                    'details': details + [f"❌ Errore: {str(e)}"]
                }
    
    threading.Thread(target=run_relay_test, daemon=True).start()
    
    return jsonify({
        'success': True,
        'message': 'Test USB-RLY08 avviato',
        'test_id': 'relay'
    })

@app.route('/api/test/status')
@require_auth()
def api_test_status():
    """API per stato test in corso"""
    global test_results
    
    test_id = request.args.get('test_id')
    
    with test_lock:
        if test_id and test_id in test_results:
            return jsonify({
                'success': True,
                'test': test_results[test_id]
            })
        else:
            return jsonify({
                'success': True,
                'tests': test_results
            })

# ===== FINE API TEST HARDWARE =====


@app.route('/test-hardware')
def test_hardware():
    """Test hardware con possibilità di test reali"""
    hardware_status = {
        'lettore_cf': {'status': 'unknown', 'message': 'Hardware non testato'},
        'rele_usb': {'status': 'unknown', 'message': 'Hardware non testato'},
        'rete': {'status': 'ok', 'message': 'Connessione web funzionante'}
    }
    
    # Verifica moduli disponibili
    if CARD_READER_AVAILABLE:
        hardware_status['lettore_cf']['status'] = 'ready'
        hardware_status['lettore_cf']['message'] = 'Modulo pronto - Test disponibile'
    else:
        hardware_status['lettore_cf']['status'] = 'error'
        hardware_status['lettore_cf']['message'] = 'Modulo non disponibile (pyscard?)'
    
    if USB_RLY08_AVAILABLE:
        hardware_status['rele_usb']['status'] = 'ready'
        hardware_status['rele_usb']['message'] = 'Modulo pronto - Test disponibile'
    else:
        hardware_status['rele_usb']['status'] = 'error'
        hardware_status['rele_usb']['message'] = 'Modulo non disponibile (pyserial?)'
    
    return {
        'status': 'success',
        'message': 'Test hardware avanzati disponibili',
        'hardware': hardware_status
    }


if __name__ == '__main__':
    print("🌐 Avvio dashboard web allineata a database_manager.py")
    print(f"📄 Database: {DB_PATH}")
    print("🔗 URL: http://0.0.0.0:5000")
    app.run(host='0.0.0.0', port=5000, debug=False, threaded=True)
