# File: /opt/access_control/src/api/web_api.py
# Dashboard web allineata a database_manager.py esistente - VERSIONE CORRETTA

from flask import Flask, render_template_string, request, jsonify, session, redirect
from flask_cors import CORS
import sqlite3
import logging
import os
from datetime import datetime, timedelta
import hashlib
import time

app = Flask(__name__)
app.secret_key = 'raee-2025-access-control-system'
CORS(app)

# Database path come database_manager.py
DB_PATH = os.path.join(os.path.dirname(__file__), '..', 'access.db')

# Stato globale per test relay
relay_test_state = {'status': 'idle'}

# Users predefiniti (hashati)
USERS = {
    'admin': {'password': hashlib.sha256('admin123'.encode()).hexdigest(), 'role': 'admin'},
    'gestore': {'password': hashlib.sha256('gestore123'.encode()).hexdigest(), 'role': 'gestore'},
    'readonly': {'password': hashlib.sha256('readonly123'.encode()).hexdigest(), 'role': 'readonly'}
}

def get_db_connection():
    """Connessione database come database_manager.py"""
    try:
        conn = sqlite3.connect(DB_PATH)
        conn.row_factory = sqlite3.Row
        return conn
    except Exception as e:
        print(f"Errore connessione DB: {e}")
        return None

def require_auth():
    """Decorator autenticazione"""
    def decorator(f):
        def wrapper(*args, **kwargs):
            if 'username' not in session:
                return redirect('/login')
            return f(*args, **kwargs)
        wrapper.__name__ = f.__name__
        return wrapper
    return decorator

# ===============================
# ROUTES PRINCIPALI
# ===============================

@app.route('/')
@require_auth()
def dashboard():
    """Dashboard principale con schema database_manager.py"""
    return render_template_string(DASHBOARD_TEMPLATE)

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        password_hash = hashlib.sha256(password.encode()).hexdigest()
        
        if username in USERS and USERS[username]['password'] == password_hash:
            session['username'] = username
            session['role'] = USERS[username]['role']
            return redirect('/')
        else:
            return render_template_string(LOGIN_TEMPLATE, error="Credenziali non valide")
    
    return render_template_string(LOGIN_TEMPLATE)

@app.route('/logout')
def logout():
    session.clear()
    return redirect('/login')

# ===============================
# API ENDPOINTS - SCHEMA CORRETTO
# ===============================

@app.route('/api/stats')
@require_auth()
def api_stats():
    """Statistiche usando schema database_manager.py"""
    conn = get_db_connection()
    if not conn:
        return jsonify({'error': 'Database non disponibile'}), 500
    
    try:
        cursor = conn.cursor()
        
        # Oggi
        today = datetime.now().strftime('%Y-%m-%d')
        
        # Accessi oggi - SCHEMA CORRETTO log_accessi
        cursor.execute("""
            SELECT COUNT(*) 
            FROM log_accessi 
            WHERE DATE(timestamp) = ?
        """, (today,))
        accessi_oggi = cursor.fetchone()[0]
        
        # Accessi autorizzati oggi - COLONNA CORRETTA autorizzato
        cursor.execute("""
            SELECT COUNT(*) 
            FROM log_accessi 
            WHERE DATE(timestamp) = ? AND autorizzato = 1
        """, (today,))
        autorizzati_oggi = cursor.fetchone()[0]
        
        return jsonify({
            'accessi_oggi': accessi_oggi,
            'autorizzati_oggi': autorizzati_oggi
        })
        
    except Exception as e:
        print(f"Errore API stats: {e}")
        return jsonify({'error': str(e)}), 500
    finally:
        conn.close()

@app.route('/api/users/count')
@require_auth()
def api_users_count():
    """Count utenti usando schema database_manager.py"""
    conn = get_db_connection()
    if not conn:
        return jsonify({'error': 'Database non disponibile'}), 500
    
    try:
        cursor = conn.cursor()
        # TABELLA CORRETTA utenti_autorizzati
        cursor.execute("SELECT COUNT(*) FROM utenti_autorizzati WHERE attivo = 1")
        count = cursor.fetchone()[0]
        return jsonify({'count': count})
    except Exception as e:
        print(f"Errore API users count: {e}")
        return jsonify({'error': str(e)}), 500
    finally:
        conn.close()

@app.route('/api/recent-accesses')
@require_auth()
def api_recent_accesses():
    """Accessi recenti usando schema database_manager.py"""
    limit = request.args.get('limit', 10, type=int)
    
    conn = get_db_connection()
    if not conn:
        return jsonify({'error': 'Database non disponibile'}), 500
    
    try:
        cursor = conn.cursor()
        # JOIN CORRETTO con nomi tabelle italiane
        cursor.execute("""
            SELECT 
                la.timestamp, 
                la.codice_fiscale, 
                la.autorizzato,
                COALESCE(ua.nome || ' ' || ua.cognome, ua.nome, ua.cognome, 'Utente sconosciuto') as nome_completo
            FROM log_accessi la
            LEFT JOIN utenti_autorizzati ua ON la.codice_fiscale = ua.codice_fiscale
            ORDER BY la.timestamp DESC
            LIMIT ?
        """, (limit,))
        
        results = cursor.fetchall()
        accesses = []
        
        for row in results:
            accesses.append({
                'timestamp': row[0],
                'codice_fiscale': row[1],
                'autorizzato': bool(row[2]),
                'nome': row[3]
            })
        
        return jsonify({'accesses': accesses})
        
    except Exception as e:
        print(f"Errore API recent accesses: {e}")
        return jsonify({'error': str(e)}), 500
    finally:
        conn.close()

@app.route('/api/test/integrated', methods=['POST'])
@require_auth()
def api_test_integrated():
    """Test integrato REALE: lettura tessera fisica e azioni conseguenti"""
    try:
        import sys
        import threading
        sys.path.insert(0, '/opt/access_control/src')
        from hardware.card_reader import CardReader
        from hardware.usb_rly08_controller import USBRLY08Controller
        
        # Reset stato test globale
        global integrated_test_state
        integrated_test_state = {
            'status': 'running',
            'phase': 'init',
            'log': [],
            'cf': None,
            'authorized': None,
            'user_name': None,
            'timeout': 60  # 60 secondi di timeout
        }
        
        def run_integrated_test():
            global integrated_test_state
            controller = None
            reader = None
            
            try:
                # FASE 1: Inizializzazione hardware
                integrated_test_state['phase'] = 'connecting'
                integrated_test_state['log'].append("🔄 AVVIO TEST INTEGRATO ACCESSO REALE")
                integrated_test_state['log'].append("━" * 50)
                integrated_test_state['log'].append("📡 Connessione hardware...")
                
                # Connetti USB-RLY08
                controller = USBRLY08Controller()
                if not controller.connect():
                    integrated_test_state['log'].append("❌ Errore connessione USB-RLY08")
                    integrated_test_state['status'] = 'error'
                    return
                
                integrated_test_state['log'].append("✅ USB-RLY08 connesso")
                
                # Inizializza lettore tessere
                reader = CardReader()
                if not reader.test_connection():
                    integrated_test_state['log'].append("❌ Errore connessione lettore OMNIKEY")
                    integrated_test_state['status'] = 'error'
                    return
                
                integrated_test_state['log'].append("✅ Lettore OMNIKEY connesso")
                time.sleep(0.5)
                
                # FASE 2: Attesa tessera REALE
                integrated_test_state['phase'] = 'waiting_card'
                integrated_test_state['log'].append("\n💳 INSERIRE TESSERA SANITARIA NEL LETTORE...")
                integrated_test_state['log'].append("⏱️ Timeout: 60 secondi")
                
                # LED giallo lampeggiante (attesa)
                start_time = time.time()
                cf = None
                
                while (time.time() - start_time) < integrated_test_state['timeout']:
                    # Lampeggio LED giallo
                    controller._send_command(104)  # Relay 4 ON (LED Giallo)
                    time.sleep(0.3)
                    controller._send_command(114)  # Relay 4 OFF
                    time.sleep(0.3)
                    
                    # Prova a leggere tessera
                    try:
                        cf = reader._read_card_robust(timeout=0.5)
                        if cf and len(cf) == 16:
                            break
                    except:
                        pass
                
                if not cf:
                    integrated_test_state['phase'] = 'timeout'
                    integrated_test_state['log'].append("\n⏱️ TIMEOUT - Nessuna tessera rilevata")
                    integrated_test_state['status'] = 'completed'
                    return
                
                # FASE 3: Tessera rilevata!
                integrated_test_state['phase'] = 'reading_card'
                integrated_test_state['log'].append(f"\n🎯 TESSERA RILEVATA!")
                integrated_test_state['log'].append(f"📄 Codice Fiscale: {cf}")
                integrated_test_state['cf'] = cf
                
                # Spegni LED giallo
                controller._send_command(114)
                
                # FASE 4: Verifica autorizzazione nel database
                integrated_test_state['log'].append("🔍 Verifica autorizzazione nel database...")
                time.sleep(0.5)
                
                conn = get_db_connection()
                authorized = False
                user_name = "Sconosciuto"
                
                if conn:
                    cursor = conn.cursor()
                    cursor.execute("""
                        SELECT nome, cognome, attivo 
                        FROM utenti_autorizzati 
                        WHERE codice_fiscale = ?
                    """, (cf,))
                    user = cursor.fetchone()
                    
                    if user:
                        nome = user[0] or ""
                        cognome = user[1] or ""
                        attivo = user[2]
                        user_name = f"{nome} {cognome}".strip() or "Utente"
                        authorized = bool(attivo)
                        
                        if not authorized:
                            integrated_test_state['log'].append(f"⚠️ Utente disattivato: {user_name}")
                    else:
                        integrated_test_state['log'].append("❓ Codice fiscale non trovato nel database")
                    
                    conn.close()
                
                integrated_test_state['authorized'] = authorized
                integrated_test_state['user_name'] = user_name
                
                # FASE 5: Esegui azioni in base all'autorizzazione
                if authorized:
                    integrated_test_state['phase'] = 'access_granted'
                    integrated_test_state['log'].append(f"\n✅ ACCESSO AUTORIZZATO")
                    integrated_test_state['log'].append(f"👤 Utente: {user_name}")
                    integrated_test_state['log'].append("🚪 Apertura cancello...")
                    
                    # Sequenza accesso autorizzato
                    controller._send_command(103)  # LED Verde ON
                    controller._send_command(105)  # Buzzer ON
                    time.sleep(0.2)
                    controller._send_command(115)  # Buzzer OFF
                    time.sleep(0.3)
                    
                    # Apri cancello
                    controller._send_command(101)  # Cancello ON
                    integrated_test_state['log'].append("✅ Cancello APERTO (8 secondi)")
                    
                    # Attendi 8 secondi (tempo reale apertura)
                    time.sleep(8)
                    
                    # Chiudi cancello
                    controller._send_command(111)  # Cancello OFF
                    integrated_test_state['log'].append("🔒 Cancello CHIUSO")
                    
                    time.sleep(1)
                    controller._send_command(113)  # LED Verde OFF
                    
                else:
                    integrated_test_state['phase'] = 'access_denied'
                    integrated_test_state['log'].append(f"\n❌ ACCESSO NEGATO")
                    integrated_test_state['log'].append(f"👤 Utente: {user_name}")
                    if user_name == "Sconosciuto":
                        integrated_test_state['log'].append("🚫 Tessera non registrata nel sistema")
                    else:
                        integrated_test_state['log'].append("🚫 Utente non autorizzato")
                    
                    # Sequenza accesso negato
                    controller._send_command(102)  # LED Rosso ON
                    
                    # Pattern buzzer negato (3 beep)
                    for i in range(3):
                        controller._send_command(105)  # Buzzer ON
                        time.sleep(0.1)
                        controller._send_command(115)  # Buzzer OFF
                        time.sleep(0.2)
                    
                    time.sleep(2)
                    controller._send_command(112)  # LED Rosso OFF
                
                # FASE 6: Log nel database
                integrated_test_state['phase'] = 'logging'
                conn = get_db_connection()
                if conn:
                    cursor = conn.cursor()
                    cursor.execute("""
                        INSERT INTO log_accessi (codice_fiscale, timestamp, autorizzato) 
                        VALUES (?, ?, ?)
                    """, (cf, datetime.now(), 1 if authorized else 0))
                    conn.commit()
                    conn.close()
                    integrated_test_state['log'].append("\n📝 Accesso registrato nel database")
                
                # FASE 7: Completamento
                integrated_test_state['phase'] = 'completed'
                integrated_test_state['log'].append("\n━" * 50)
                integrated_test_state['log'].append("✅ TEST COMPLETATO")
                integrated_test_state['log'].append("💡 Puoi rimuovere la tessera")
                
            except Exception as e:
                integrated_test_state['log'].append(f"\n❌ ERRORE: {str(e)}")
                integrated_test_state['status'] = 'error'
                integrated_test_state['phase'] = 'error'
            finally:
                # Cleanup
                if controller:
                    # Spegni tutti i LED
                    controller._send_command(110)  # All OFF
                    controller.disconnect()
                integrated_test_state['status'] = 'completed'
        
        # Avvia test in thread separato
        test_thread = threading.Thread(target=run_integrated_test)
        test_thread.daemon = True
        test_thread.start()
        
        return jsonify({'success': True, 'message': 'Test integrato avviato - inserire tessera'})
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/api/integrated_status')
@require_auth()
def integrated_status():
    """Restituisce stato real-time del test integrato"""
    global integrated_test_state
    if 'integrated_test_state' not in globals():
        return jsonify({'status': 'idle'})
    
    return jsonify(integrated_test_state)
@app.route('/api/test/gate')
@require_auth()
def api_test_gate():
    """Test cancello"""
    try:
        # Import controller come nel main.py
        import sys
        sys.path.insert(0, '/opt/access_control/src/hardware')
        from usb_rly08_controller import USBRLY08Controller
        
        controller = USBRLY08Controller()
        if controller.connect():
            # Apri cancello per 5 secondi
            controller._send_command(101)  # Relay 1 ON (Cancello)
            time.sleep(5)
            controller._send_command(111)  # Relay 1 OFF
            controller.disconnect()
            return jsonify({'success': True, 'message': 'Cancello aperto per test'})
        else:
            return jsonify({'success': False, 'error': 'Impossibile connettersi al controller'})
    except Exception as e:
        return jsonify({'success': False, 'error': f'Errore test cancello: {str(e)}'})

@app.route('/api/test_relay', methods=['POST'])
@require_auth()
def test_relay():
    """Test hardware USB-RLY08 con feedback real-time"""
    try:
        import sys
        import threading
        sys.path.insert(0, '/opt/access_control/src/hardware')
        from usb_rly08_controller import USBRLY08Controller
        
        # Reset stato test globale
        global relay_test_state
        relay_test_state = {
            'status': 'running',
            'current_relay': 0,
            'log': [],
            'relay_states': {i: False for i in range(1, 9)}
        }
        
        def run_relay_test():
            global relay_test_state
            controller = USBRLY08Controller()
            
            relay_test_state['log'].append("=== TEST USB-RLY08 ===")
            relay_test_state['log'].append(f"Porta: {controller.port}")
            
            if not controller.connect():
                relay_test_state['log'].append("✗ Impossibile connettersi")
                relay_test_state['status'] = 'error'
                return
            
            relay_test_state['log'].append("✓ Connessione stabilita")
            
            # Test sequenziale di ogni relè
            for i in range(1, 9):
                relay_test_state['current_relay'] = i
                relay_test_state['log'].append(f"\nTest Relè {i}:")
                
                # Accendi relè - comando diretto
                command_on = 100 + i  # Comandi 101-108 per ON
                if controller._send_command(command_on):
                    relay_test_state['relay_states'][i] = True
                    relay_test_state['log'].append(f"  ✓ Relè {i} acceso")
                    time.sleep(0.5)
                    
                    # Spegni relè - comando diretto
                    command_off = 110 + i  # Comandi 111-118 per OFF
                    if controller._send_command(command_off):
                        relay_test_state['relay_states'][i] = False
                        relay_test_state['log'].append(f"  ✓ Relè {i} spento")
                
                time.sleep(0.5)
            
            # Test pattern finale - accendi tutti
            relay_test_state['log'].append("\nTest pattern finale...")
            controller._send_command(100)  # All ON
            for i in range(1, 9):
                relay_test_state['relay_states'][i] = True
            time.sleep(1)
            
            # Spegni tutti
            controller._send_command(110)  # All OFF
            for i in range(1, 9):
                relay_test_state['relay_states'][i] = False
            
            controller.disconnect()
            relay_test_state['log'].append("\n✓ Test completato!")
            relay_test_state['status'] = 'completed'
            relay_test_state['current_relay'] = 0
        
        # Avvia test in thread separato
        test_thread = threading.Thread(target=run_relay_test)
        test_thread.daemon = True
        test_thread.start()
        
        return jsonify({'success': True, 'message': 'Test avviato'})
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/api/relay_status')
@require_auth()
def relay_status():
    """Restituisce stato real-time del test relay"""
    global relay_test_state
    if 'relay_test_state' not in globals():
        return jsonify({'status': 'idle'})
    
    return jsonify(relay_test_state)

# ===============================
# TEMPLATES
# ===============================

LOGIN_TEMPLATE = """
<!DOCTYPE html>
<html>
<head>
    <title>Sistema Controllo Accessi - Login</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        body { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); min-height: 100vh; }
        .login-container { max-width: 400px; margin: 0 auto; padding-top: 100px; }
        .card { border: none; border-radius: 15px; box-shadow: 0 8px 30px rgba(0,0,0,0.1); }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="card">
            <div class="card-body p-5">
                <div class="text-center mb-4">
                    <i class="fas fa-shield-alt fa-3x text-primary mb-3"></i>
                    <h4>Sistema Controllo Accessi</h4>
                    <p class="text-muted">Isola Ecologica RAEE - Rende</p>
                </div>
                
                {% if error %}
                <div class="alert alert-danger">{{ error }}</div>
                {% endif %}
                
                <form method="POST">
                    <div class="mb-3">
                        <label class="form-label">Username</label>
                        <input type="text" class="form-control" name="username" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Password</label>
                        <input type="password" class="form-control" name="password" required>
                    </div>
                    <button type="submit" class="btn btn-primary w-100">
                        <i class="fas fa-sign-in-alt me-2"></i>Accedi
                    </button>
                </form>
                
                <div class="mt-4 text-center">
                    <small class="text-muted">
                        Credenziali: admin/admin123, gestore/gestore123, readonly/readonly123
                    </small>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
"""

DASHBOARD_TEMPLATE = """
<!DOCTYPE html>
<html>
<head>
    <title>Sistema Controllo Accessi - Dashboard</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        body { background-color: #f8f9fa; }
        .navbar { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); }
        .stat-card { border: none; border-radius: 15px; box-shadow: 0 4px 15px rgba(0,0,0,0.1); transition: transform 0.2s; }
        .stat-card:hover { transform: translateY(-5px); }
        .stat-number { font-size: 2.5rem; font-weight: bold; }
        .hardware-card { border-radius: 15px; box-shadow: 0 4px 15px rgba(0,0,0,0.1); }
    
        /* Stili Modal USB-RLY08 */
        .relay-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 15px;
            padding: 20px;
            background: #f8f9fa;
            border-radius: 10px;
            margin-bottom: 20px;
        }
        
        .relay-box {
            background: white;
            border: 2px solid #dee2e6;
            border-radius: 8px;
            padding: 20px;
            text-align: center;
            transition: all 0.3s ease;
            cursor: default;
        }
        
        .relay-box.active {
            background: #28a745;
            color: white;
            border-color: #28a745;
            transform: scale(1.05);
            box-shadow: 0 0 20px rgba(40, 167, 69, 0.5);
        }
        
        .relay-box i {
            font-size: 2em;
            display: block;
            margin-bottom: 10px;
        }
        
        .relay-box.active i {
            animation: pulse 0.5s ease-in-out infinite;
        }
        
        @keyframes pulse {
            0%, 100% { transform: scale(1); }
            50% { transform: scale(1.2); }
        }
        
        .gate-visual {
            width: 200px;
            height: 100px;
            background: #343a40;
            border: 3px solid #6c757d;
            border-radius: 5px;
            margin: 20px auto;
            position: relative;
            overflow: hidden;
            transition: all 0.5s ease;
        }
        
        .gate-visual.open {
            background: #28a745;
            border-color: #28a745;
        }
        
        .gate-bars {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: repeating-linear-gradient(
                90deg,
                #ffc107,
                #ffc107 10px,
                #343a40 10px,
                #343a40 20px
            );
            transition: transform 0.8s ease;
        }
        
        .gate-visual.open .gate-bars {
            transform: translateX(-100%);
        }
        
        .led-indicator {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            margin: 10px;
            display: inline-block;
            border: 2px solid #dee2e6;
            transition: all 0.3s ease;
        }
        
        .led-indicator.led-red { background: #ffcccc; }
        .led-indicator.led-green { background: #ccffcc; }
        .led-indicator.led-yellow { background: #ffffcc; }
        
        .led-indicator.active {
            border-width: 0;
            box-shadow: 0 0 30px currentColor;
        }
        
        .led-indicator.led-red.active { background: #dc3545; }
        .led-indicator.led-green.active { background: #28a745; }
        .led-indicator.led-yellow.active { background: #ffc107; }
        
        .buzzer-visual {
            display: inline-block;
            font-size: 2em;
            transition: all 0.3s ease;
        }
        
        .buzzer-visual.active {
            animation: buzz 0.2s ease-in-out infinite;
            color: #17a2b8;
        }
        
        @keyframes buzz {
            0%, 100% { transform: rotate(-5deg); }
            50% { transform: rotate(5deg); }
        }
        
        .relay-log {
            background: #000;
            color: #00ff00;
            font-family: 'Courier New', monospace;
            padding: 15px;
            height: 200px;
            overflow-y: auto;
            border-radius: 8px;
            font-size: 0.9em;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-dark">
        <div class="container-fluid">
            <span class="navbar-brand mb-0 h1">
                <i class="fas fa-shield-alt me-2"></i>Sistema Controllo Accessi
            </span>
            <div class="navbar-nav">
                <span class="navbar-text me-3">Isola Ecologica RAEE - Rende | Dashboard Finale</span>
                <a href="/logout" class="btn btn-outline-light btn-sm">
                    <i class="fas fa-sign-out-alt me-1"></i>Logout
                </a>
            </div>
        </div>
    </nav>

    <div class="container-fluid mt-4">
        <!-- Statistiche -->
        <div class="row mb-4">
            <div class="col-md-4">
                <div class="card stat-card">
                    <div class="card-body text-center">
                        <i class="fas fa-clock fa-2x text-primary mb-3"></i>
                        <div class="stat-number text-primary" id="accessi-oggi">-</div>
                        <h6 class="text-muted">Accessi Oggi</h6>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card stat-card">
                    <div class="card-body text-center">
                        <i class="fas fa-check-circle fa-2x text-success mb-3"></i>
                        <div class="stat-number text-success" id="autorizzati">-</div>
                        <h6 class="text-muted">Autorizzati</h6>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card stat-card">
                    <div class="card-body text-center">
                        <i class="fas fa-users fa-2x text-info mb-3"></i>
                        <div class="stat-number text-info" id="utenti-totali">-</div>
                        <h6 class="text-muted">Utenti Totali</h6>
                    </div>
                </div>
            </div>
        </div>

        <!-- Hardware Test + Accessi Recenti -->
        <div class="row">
            <div class="col-md-6">
                <div class="card hardware-card">
                    <div class="card-header">
                        <h5><i class="fas fa-cogs me-2"></i>Test Hardware</h5>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-4 mb-2">
                                <button class="btn btn-primary w-100" onclick="testReader()">
                                    <i class="fas fa-credit-card"></i><br><small>Lettore</small>
                                </button>
                            </div>
                            <div class="col-md-4 mb-2">
                                <button class="btn btn-warning w-100" onclick="testRelay()">
                                    <i class="fas fa-microchip"></i><br><small>USB-RLY08</small>
                                </button>
                            </div>
                            <div class="col-md-4 mb-2">
                                <button class="btn btn-success w-100" onclick="testGate()">
                                    <i class="fas fa-door-open"></i><br><small>Cancello</small>
                                </button>
                            </div>
                        </div>
                        <div class="row mt-2">
                            <div class="col-md-12">
                                <button class="btn btn-info w-100" onclick="testIntegrated()">
                                    <i class="fas fa-id-card me-2"></i>Test Completo Accesso (Simula Tessera)
                                </button>
                            </div>
                        </div>
                        <div id="hardware-status" class="mt-3"></div>
                    </div>
                </div>
            </div>
            
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header">
                        <h5><i class="fas fa-history me-2"></i>Ultimi Accessi</h5>
                    </div>
                    <div class="card-body" id="recent-accesses">
                        <div class="text-center text-muted">Caricamento...</div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal Test Lettore -->
    <div class="modal fade" id="readerTestModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">
                        <i class="fas fa-credit-card me-2"></i>Test Lettore OMNIKEY 5427CK
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div id="reader-test-log" style="background: #000; color: #00ff00; padding: 15px; font-family: 'Courier New', monospace; height: 400px; overflow-y: auto; border-radius: 8px; scroll-behavior: smooth;">
                        <div id="reader-log-content">Cliccare "Avvia Test" per iniziare...</div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-success" id="start-reader-test">
                        <i class="fas fa-play"></i> Avvia Test
                    </button>
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Chiudi</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal Test USB-RLY08 -->
    <div class="modal fade" id="relayTestModal" tabindex="-1">
        <div class="modal-dialog modal-xl">
            <div class="modal-content">
                <div class="modal-header bg-primary text-white">
                    <h5 class="modal-title">
                        <i class="fas fa-microchip me-2"></i>Test Controller USB-RLY08
                    </h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <!-- Griglia Relè -->
                    <div class="relay-grid">
                        <div class="relay-box" id="relay-1">
                            <i class="fas fa-door-open"></i>
                            <strong>Relè 1</strong>
                            <small>Cancello</small>
                        </div>
                        <div class="relay-box" id="relay-2">
                            <i class="fas fa-lightbulb"></i>
                            <strong>Relè 2</strong>
                            <small>LED Rosso</small>
                        </div>
                        <div class="relay-box" id="relay-3">
                            <i class="fas fa-lightbulb"></i>
                            <strong>Relè 3</strong>
                            <small>LED Verde</small>
                        </div>
                        <div class="relay-box" id="relay-4">
                            <i class="fas fa-lightbulb"></i>
                            <strong>Relè 4</strong>
                            <small>LED Giallo</small>
                        </div>
                        <div class="relay-box" id="relay-5">
                            <i class="fas fa-bell"></i>
                            <strong>Relè 5</strong>
                            <small>Buzzer</small>
                        </div>
                        <div class="relay-box" id="relay-6">
                            <i class="fas fa-plug"></i>
                            <strong>Relè 6</strong>
                            <small>Aux 1</small>
                        </div>
                        <div class="relay-box" id="relay-7">
                            <i class="fas fa-plug"></i>
                            <strong>Relè 7</strong>
                            <small>Aux 2</small>
                        </div>
                        <div class="relay-box" id="relay-8">
                            <i class="fas fa-plug"></i>
                            <strong>Relè 8</strong>
                            <small>Aux 3</small>
                        </div>
                    </div>
                    
                    <!-- Visualizzazione Dispositivi -->
                    <div class="text-center mb-3">
                        <h6>Dispositivi Collegati</h6>
                        
                        <!-- Cancello -->
                        <div class="gate-visual" id="gate-visual">
                            <div class="gate-bars"></div>
                            <div style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); color: white; font-weight: bold; z-index: 10;">
                                CANCELLO
                            </div>
                        </div>
                        
                        <!-- LED e Buzzer -->
                        <div class="mt-3">
                            <span class="led-indicator led-red" id="led-red" title="LED Rosso"></span>
                            <span class="led-indicator led-green" id="led-green" title="LED Verde"></span>
                            <span class="led-indicator led-yellow" id="led-yellow" title="LED Giallo"></span>
                            <span class="buzzer-visual" id="buzzer" title="Buzzer">
                                <i class="fas fa-bell"></i>
                            </span>
                        </div>
                    </div>
                    
                    <!-- Log -->
                    <div class="relay-log" id="relay-log">
                        Pronto per il test. Clicca "Avvia Test Sequenziale" per iniziare...
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-primary" id="start-relay-test" onclick="startRelaySequence()">
                        <i class="fas fa-play me-2"></i>Avvia Test Sequenziale
                    </button>
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Chiudi</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal Test Integrato -->
    <div class="modal fade" id="integratedTestModal" tabindex="-1">
        <div class="modal-dialog modal-xl">
            <div class="modal-content">
                <div class="modal-header bg-info text-white">
                    <h5 class="modal-title">
                        <i class="fas fa-id-card me-2"></i>Test Completo Sistema Accesso
                    </h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <!-- Colonna sinistra: Animazione -->
                        <div class="col-md-6">
                            <h6 class="text-center mb-3">Simulazione Processo Accesso</h6>
                            
                            <!-- Tessera e Lettore -->
                            <div class="access-simulation">
                                <div class="card-reader-container">
                                    <div id="card-visual" class="card-animation">
                                        <div class="card-chip"></div>
                                        <div class="card-text">TESSERA SANITARIA</div>
                                    </div>
                                    <div id="reader-visual" class="reader-visual">
                                        <div class="reader-slot"></div>
                                        <div class="reader-light"></div>
                                    </div>
                                </div>
                                
                                <!-- Status -->
                                <div class="text-center mt-3">
                                    <h5 id="integrated-status">
                                        <i class="fas fa-info-circle"></i> Pronto
                                    </h5>
                                </div>
                                
                                <!-- Dispositivi -->
                                <div class="devices-container mt-4">
                                    <!-- Cancello -->
                                    <div class="gate-visual" id="integrated-gate">
                                        <div class="gate-bars"></div>
                                        <div class="gate-label">CANCELLO</div>
                                    </div>
                                    
                                    <!-- LED e Buzzer -->
                                    <div class="text-center mt-3">
                                        <span class="led-indicator led-red" id="integrated-led-red" title="Accesso Negato"></span>
                                        <span class="led-indicator led-green" id="integrated-led-green" title="Accesso Autorizzato"></span>
                                        <span class="led-indicator led-yellow" id="integrated-led-yellow" title="Attesa"></span>
                                        <span class="buzzer-visual" id="integrated-buzzer" title="Buzzer">
                                            <i class="fas fa-bell"></i>
                                        </span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Colonna destra: Log -->
                        <div class="col-md-6">
                            <h6 class="text-center mb-3">Log Operazioni</h6>
                            <div class="integrated-log" id="integrated-log">
                                <div class="text-muted text-center">Clicca "Avvia Test" per iniziare...</div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-primary" id="restart-integrated-test" onclick="testIntegrated()" disabled>
                        <i class="fas fa-redo me-2"></i>Avvia Test
                    </button>
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Chiudi</button>
                </div>
            </div>
        </div>
    </div>

    <style>
        /* Stili aggiuntivi per test integrato */
        .access-simulation {
            background: #f8f9fa;
            border-radius: 15px;
            padding: 30px;
            min-height: 400px;
        }
        
        .card-reader-container {
            position: relative;
            height: 200px;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 50px;
        }
        
        .card-animation {
            width: 120px;
            height: 80px;
            background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
            border-radius: 10px;
            position: relative;
            transition: all 0.5s ease;
            box-shadow: 0 4px 20px rgba(0,0,0,0.2);
        }
        
        .card-animation.waiting {
            animation: pulse 2s ease-in-out infinite;
        }
        
        .card-animation.inserting {
            transform: translateX(50px);
        }
        
        .card-animation.success {
            background: linear-gradient(135deg, #11998e 0%, #38ef7d 100%);
        }
        
        .card-animation.denied {
            background: linear-gradient(135deg, #eb3349 0%, #f45c43 100%);
            animation: shake 0.5s ease-in-out;
        }
        
        .card-chip {
            width: 25px;
            height: 20px;
            background: gold;
            border-radius: 4px;
            position: absolute;
            top: 20px;
            left: 20px;
        }
        
        .card-text {
            position: absolute;
            bottom: 10px;
            left: 10px;
            right: 10px;
            text-align: center;
            color: white;
            font-size: 10px;
            font-weight: bold;
        }
        
        .reader-visual {
            width: 150px;
            height: 100px;
            background: #343a40;
            border-radius: 10px;
            position: relative;
            border: 3px solid #495057;
        }
        
        .reader-visual.scanning .reader-light {
            background: #ffc107;
            animation: blink 0.5s ease-in-out infinite;
        }
        
        .reader-visual.active .reader-light {
            background: #17a2b8;
        }
        
        .reader-visual.success .reader-light {
            background: #28a745;
        }
        
        .reader-visual.denied .reader-light {
            background: #dc3545;
        }
        
        .reader-slot {
            width: 100px;
            height: 5px;
            background: #000;
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
        }
        
        .reader-light {
            width: 15px;
            height: 15px;
            background: #6c757d;
            border-radius: 50%;
            position: absolute;
            top: 20px;
            right: 20px;
            transition: all 0.3s ease;
        }
        
        .devices-container {
            display: flex;
            flex-direction: column;
            align-items: center;
        }
        
        .integrated-log {
            background: #000;
            color: #00ff00;
            font-family: 'Courier New', monospace;
            padding: 15px;
            height: 400px;
            overflow-y: auto;
            border-radius: 8px;
            font-size: 0.9em;
        }
        
        .integrated-log .log-line {
            margin-bottom: 5px;
            padding: 2px 0;
        }
        
        @keyframes pulse {
            0%, 100% { transform: scale(1); opacity: 1; }
            50% { transform: scale(1.05); opacity: 0.8; }
        }
        
        @keyframes shake {
            0%, 100% { transform: translateX(0); }
            25% { transform: translateX(-10px); }
            75% { transform: translateX(10px); }
        }
        
        @keyframes blink {
            0%, 100% { opacity: 1; }
            50% { opacity: 0.3; }
        }
        
        .led-indicator.blink {
            animation: blink 0.5s ease-in-out infinite;
        }
        
        .animated-text {
            animation: pulse-text 1.5s ease-in-out infinite;
            font-weight: bold;
            font-size: 1.2em;
        }
        
        @keyframes pulse-text {
            0%, 100% { opacity: 1; transform: scale(1); }
            50% { opacity: 0.7; transform: scale(1.05); }
        }
        
        .gate-label {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            color: white;
            font-weight: bold;
            z-index: 10;
        }
    </style>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Carica dati dashboard
        function loadDashboardData() {
            // Statistiche
            fetch('/api/stats')
                .then(response => response.json())
                .then(data => {
                    if (!data.error) {
                        document.getElementById('accessi-oggi').textContent = data.accessi_oggi || '0';
                        document.getElementById('autorizzati').textContent = data.autorizzati_oggi || '0';
                    }
                })
                .catch(error => console.error('Errore stats:', error));

            // Utenti totali
            fetch('/api/users/count')
                .then(response => response.json())
                .then(data => {
                    if (!data.error) {
                        document.getElementById('utenti-totali').textContent = data.count || '0';
                    }
                })
                .catch(error => console.error('Errore users count:', error));

            // Accessi recenti
            fetch('/api/recent-accesses')
                .then(response => response.json())
                .then(data => {
                    if (!data.error && data.accesses) {
                        let html = '';
                        data.accesses.slice(0, 5).forEach(access => {
                            const status = access.autorizzato ? 
                                '<span class="badge bg-success">Autorizzato</span>' : 
                                '<span class="badge bg-danger">Negato</span>';
                            const time = new Date(access.timestamp).toLocaleTimeString();
                            html += `
                                <div class="d-flex justify-content-between align-items-center border-bottom py-2">
                                    <div>
                                        <strong>${access.nome}</strong><br>
                                        <small class="text-muted">${access.codice_fiscale}</small>
                                    </div>
                                    <div class="text-end">
                                        ${status}<br>
                                        <small class="text-muted">${time}</small>
                                    </div>
                                </div>
                            `;
                        });
                        document.getElementById('recent-accesses').innerHTML = html || '<div class="text-muted">Nessun accesso recente</div>';
                    }
                })
                .catch(error => console.error('Errore recent accesses:', error));
        }

        // Test cancello
        function testGate() {
            const status = document.getElementById('hardware-status');
            status.innerHTML = '<div class="alert alert-info">Test cancello in corso...</div>';
            
            fetch('/api/test/gate')
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        status.innerHTML = '<div class="alert alert-success">✅ Test cancello completato con successo</div>';
                    } else {
                        status.innerHTML = `<div class="alert alert-danger">❌ ${data.error}</div>`;
                    }
                })
                .catch(error => {
                    status.innerHTML = `<div class="alert alert-danger">❌ Errore comunicazione: ${error}</div>`;
                })
                .finally(() => {
                    setTimeout(() => status.innerHTML = '', 5000);
                });
        }

        // Test lettore con modal real-time
        function testReader() {
            // Apri modal
            const modal = new bootstrap.Modal(document.getElementById('readerTestModal'));
            modal.show();
            
            // Reset log
            const logContent = document.getElementById('reader-log-content');
            logContent.innerHTML = 'Cliccare "Avvia Test" per iniziare...';
            window.continuousTestMode = false;
            window.testRestarting = false;
            
            // Handler per avvia test
            document.getElementById('start-reader-test').onclick = function() {
                // Se già in test, ferma
                if (window.continuousTestMode) {
                    window.continuousTestMode = false;
                    this.innerHTML = '<i class="fas fa-play"></i> Avvia Test';
                    addLogLine('⏹️ ARRESTO TEST RICHIESTO', 'warning');
                    addLogLine('Il test verrà fermato al prossimo ciclo');
                    return;
                }
                
                // Avvia nuovo test
                window.continuousTestMode = true;
                this.disabled = true;
                this.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Test in corso...';
                
                logContent.innerHTML = '';
                addLogLine('🚀 AVVIO TEST LETTORE OMNIKEY 5427CK');
                addLogLine('═'.repeat(50));
                
                // Avvia test
                fetch('/api/hardware/test-reader', {method: 'POST'})
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            startReaderPolling();
                        } else {
                            addLogLine(`❌ ERRORE: ${data.error}`, 'error');
                            resetTestButton();
                        }
                    });
            };
        }

        // Polling real-time per test lettore
        function startReaderPolling() {
            const pollInterval = setInterval(() => {
                fetch('/api/hardware/status?test_id=reader')
                    .then(response => response.json())
                    .then(data => {
                        if (data.success && data.test) {
                            const test = data.test;
                            
                            // Aggiorna log con dettagli
                            if (test.details && test.details.length > 0) {
                                const logContent = document.getElementById('reader-log-content');
                                const currentLines = logContent.querySelectorAll('.log-line').length;
                                
                                // Aggiungi solo nuove linee
                                for (let i = currentLines - 2; i < test.details.length; i++) {
                                    if (i >= 0 && test.details[i]) {
                                        addLogLine(test.details[i]);
                                    }
                                }
                            }
                            
                            // Status update - solo se cambia veramente
                            if (test.message && test.message.includes('Tessera')) {
                                // Mostra solo quando c'è una tessera
                            }
                            
                            // Se test completato
                            if (test.status !== 'running') {
                                if (test.status === 'success') {
                                    addLogLine('🎯 TEST COMPLETATO CON SUCCESSO!', 'success');
                                } else if (test.status === 'warning') {
                                    addLogLine('⚠️ TEST COMPLETATO CON AVVISI', 'warning');
                                } else {
                                    addLogLine('❌ TEST FALLITO', 'error');
                                }
                                
                                addLogLine('═'.repeat(50));
                                
                                // Gestione test continuo
                                if (window.continuousTestMode && !window.testRestarting) {
                                    window.testRestarting = true;
                                    clearInterval(pollInterval);
                                    
                                    // Messaggio attesa
                                    setTimeout(() => {
                                        addLogLine('');
                                        addLogLine('⏳ ATTESA PROSSIMA TESSERA...', 'status');
                                        addLogLine('Inserire tessera per continuare il test', 'normal');
                                        addLogLine('');
                                    }, 500);
                                    
                                    // Riavvia test dopo 2 secondi
                                    setTimeout(() => {
                                        window.testRestarting = false;
                                        if (window.continuousTestMode) {
                                            fetch('/api/hardware/test-reader', {method: 'POST'})
                                                .then(response => response.json())
                                                .then(data => {
                                                    if (data.success) {
                                                        startReaderPolling();
                                                    }
                                                });
                                        }
                                    }, 2000);
                                } else {
                                    clearInterval(pollInterval);
                                }
                                
                                resetTestButton();
                            }
                        }
                    })
                    .catch(error => {
                        clearInterval(pollInterval);
                        addLogLine(`❌ Errore polling: ${error}`, 'error');
                        resetTestButton();
                    });
            }, 1000);
        }

        // Aggiungi linea al log con SCROLL FUNZIONANTE
        function addLogLine(text, type = 'normal') {
            const logContent = document.getElementById('reader-log-content');
            const timestamp = new Date().toLocaleTimeString();
            
            let color = '#00ff00'; // Verde default
            if (type === 'error') color = '#ff4444';
            if (type === 'warning') color = '#ffaa00';
            if (type === 'success') color = '#44ff44';
            if (type === 'status') color = '#00aaff';
            
            const line = document.createElement('div');
            line.className = 'log-line';
            line.style.color = color;
            line.style.marginBottom = '2px';
            line.innerHTML = `[${timestamp}] ${text}`;
            
            logContent.appendChild(line);
            
            // SCROLL INTELLIGENTE - Solo se utente non sta scrollando
            const logContainer = document.getElementById('reader-test-log');
            if (logContainer) {
                // Controlla se l'utente sta scrollando (non è in fondo)
                const isScrolledToBottom = logContainer.scrollHeight - logContainer.clientHeight <= logContainer.scrollTop + 50;
                
                // Scrolla solo se già in fondo
                if (isScrolledToBottom) {
                    setTimeout(() => {
                        logContainer.scrollTop = logContainer.scrollHeight;
                    }, 10);
                }
            }
        }

        // Reset pulsante test
        function resetTestButton() {
            const btn = document.getElementById('start-reader-test');
            btn.disabled = false;
            if (window.continuousTestMode) {
                btn.innerHTML = '<i class="fas fa-stop"></i> Ferma Test';
            } else {
                btn.innerHTML = '<i class="fas fa-play"></i> Avvia Test';
            }
        }

        // Test USB-RLY08
        function testRelay() {
            const modal = new bootstrap.Modal(document.getElementById('relayTestModal'));
            modal.show();
        }

        // Funzione per test sequenziale relay con animazioni real-time
        function startRelaySequence() {
            const btn = document.getElementById('start-relay-test');
            const log = document.getElementById('relay-log');
            
            btn.disabled = true;
            btn.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Test in corso...';
            
            log.innerHTML = 'Avvio test USB-RLY08...\\n';
            
            // Reset visuale
            for (let i = 1; i <= 8; i++) {
                document.getElementById(`relay-${i}`).classList.remove('active');
            }
            resetDevices();
            
            // Avvia test
            fetch('/api/test_relay', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'}
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // Avvia polling per aggiornamenti real-time
                    pollRelayStatus();
                } else {
                    log.innerHTML = 'ERRORE: ' + (data.error || 'Errore sconosciuto');
                    btn.disabled = false;
                    btn.innerHTML = '<i class="fas fa-play me-2"></i>Avvia Test Sequenziale';
                }
            })
            .catch(error => {
                log.innerHTML = 'ERRORE CONNESSIONE: ' + error.message;
                btn.disabled = false;
                btn.innerHTML = '<i class="fas fa-play me-2"></i>Avvia Test Sequenziale';
            });
        }

        // Polling stato relay per animazioni real-time
        function pollRelayStatus() {
            const pollInterval = setInterval(() => {
                fetch('/api/relay_status')
                    .then(response => response.json())
                    .then(data => {
                        if (data.status === 'idle') {
                            clearInterval(pollInterval);
                            return;
                        }
                        
                        // Aggiorna log
                        if (data.log) {
                            document.getElementById('relay-log').innerHTML = data.log.join('\\n');
                            // Auto-scroll
                            const logDiv = document.getElementById('relay-log');
                            logDiv.scrollTop = logDiv.scrollHeight;
                        }
                        
                        // Aggiorna stati relay e dispositivi
                        if (data.relay_states) {
                            updateRelayVisuals(data.relay_states);
                        }
                        
                        // Se completato
                        if (data.status === 'completed' || data.status === 'error') {
                            clearInterval(pollInterval);
                            const btn = document.getElementById('start-relay-test');
                            btn.disabled = false;
                            btn.innerHTML = '<i class="fas fa-play me-2"></i>Avvia Test Sequenziale';
                            
                            // Reset visuali dopo 2 secondi
                            setTimeout(() => {
                                for (let i = 1; i <= 8; i++) {
                                    document.getElementById(`relay-${i}`).classList.remove('active');
                                }
                                resetDevices();
                            }, 2000);
                        }
                    })
                    .catch(error => {
                        console.error('Errore polling:', error);
                        clearInterval(pollInterval);
                    });
            }, 100); // Poll ogni 100ms per animazioni fluide
        }

        // Aggiorna visualizzazione relay e dispositivi collegati
        function updateRelayVisuals(relayStates) {
            for (let i = 1; i <= 8; i++) {
                const relayBox = document.getElementById(`relay-${i}`);
                if (relayStates[i]) {
                    relayBox.classList.add('active');
                } else {
                    relayBox.classList.remove('active');
                }
            }
            
            // Aggiorna dispositivi in base ai relay attivi
            // Relay 1 = Cancello
            if (relayStates[1]) {
                document.getElementById('gate-visual').classList.add('open');
            } else {
                document.getElementById('gate-visual').classList.remove('open');
            }
            
            // Relay 2 = LED Rosso
            if (relayStates[2]) {
                document.getElementById('led-red').classList.add('active');
            } else {
                document.getElementById('led-red').classList.remove('active');
            }
            
            // Relay 3 = LED Verde
            if (relayStates[3]) {
                document.getElementById('led-green').classList.add('active');
            } else {
                document.getElementById('led-green').classList.remove('active');
            }
            
            // Relay 4 = LED Giallo
            if (relayStates[4]) {
                document.getElementById('led-yellow').classList.add('active');
            } else {
                document.getElementById('led-yellow').classList.remove('active');
            }
            
            // Relay 5 = Buzzer
            if (relayStates[5]) {
                document.getElementById('buzzer').classList.add('active');
            } else {
                document.getElementById('buzzer').classList.remove('active');
            }
        }

        // Reset tutti i dispositivi
        function resetDevices() {
            document.getElementById('gate-visual').classList.remove('open');
            document.getElementById('led-red').classList.remove('active');
            document.getElementById('led-green').classList.remove('active');
            document.getElementById('led-yellow').classList.remove('active');
            document.getElementById('buzzer').classList.remove('active');
        }

        // Funzione globale per pulire backdrop residui
        function cleanupModals() {
            // Rimuovi tutti i backdrop
            document.querySelectorAll('.modal-backdrop').forEach(el => el.remove());
            // Reset body
            document.body.classList.remove('modal-open');
            document.body.style.removeProperty('overflow');
            document.body.style.removeProperty('padding-right');
            // Rimuovi attributi modal dal body
            const bodyAttributes = ['data-bs-padding-right', 'data-bs-overflow'];
            bodyAttributes.forEach(attr => document.body.removeAttribute(attr));
        }
        
        // Auto-refresh ogni 5 secondi
        loadDashboardData();
        setInterval(loadDashboardData, 5000);
        
        // Fix per modal integrato
        document.addEventListener('DOMContentLoaded', function() {
            const integratedModal = document.getElementById('integratedTestModal');
            if (integratedModal) {
                integratedModal.addEventListener('shown.bs.modal', function () {
                    document.getElementById('restart-integrated-test').disabled = false;
                });
                
                // FIX: Rimuovi backdrop quando il modal si chiude
                integratedModal.addEventListener('hidden.bs.modal', function () {
                    // Rimuovi tutti i backdrop residui
                    document.querySelectorAll('.modal-backdrop').forEach(el => el.remove());
                    // Ripristina body
                    document.body.classList.remove('modal-open');
                    document.body.style.removeProperty('overflow');
                    document.body.style.removeProperty('padding-right');
                });
            }
            
            // FIX anche per gli altri modal
            const relayModal = document.getElementById('relayTestModal');
            if (relayModal) {
                relayModal.addEventListener('hidden.bs.modal', function () {
                    document.querySelectorAll('.modal-backdrop').forEach(el => el.remove());
                    document.body.classList.remove('modal-open');
                    document.body.style = '';
                });
            }
            
            const readerModal = document.getElementById('readerTestModal');
            if (readerModal) {
                readerModal.addEventListener('hidden.bs.modal', function () {
                    document.querySelectorAll('.modal-backdrop').forEach(el => el.remove());
                    document.body.classList.remove('modal-open');
                    document.body.style = '';
                });
            }
        });

        // Test integrato completo con simulazione tessera
        function testIntegrated() {
            // Apri modal dedicato
            const modal = new bootstrap.Modal(document.getElementById('integratedTestModal'));
            modal.show();
            
            // Reset visualizzazione
            resetIntegratedTest();
            
            // Avvia test
            fetch('/api/test/integrated', {method: 'POST'})
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        pollIntegratedStatus();
                    } else {
                        document.getElementById('integrated-log').innerHTML = 
                            `<div class="text-danger">Errore: ${data.error}</div>`;
                    }
                });
        }
        
        // Polling stato test integrato
        function pollIntegratedStatus() {
            const pollInterval = setInterval(() => {
                fetch('/api/integrated_status')
                    .then(response => response.json())
                    .then(data => {
                        if (data.status === 'idle') {
                            clearInterval(pollInterval);
                            return;
                        }
                        
                        // Aggiorna log
                        if (data.log) {
                            const logHtml = data.log.map(line => {
                                let className = 'log-line';
                                if (line.includes('✅')) className += ' text-success';
                                else if (line.includes('❌')) className += ' text-danger';
                                else if (line.includes('🟡') || line.includes('💳')) className += ' text-warning';
                                else if (line.includes('📄') || line.includes('👤')) className += ' text-info';
                                return `<div class="${className}">${line}</div>`;
                            }).join('');
                            
                            document.getElementById('integrated-log').innerHTML = logHtml;
                            
                            // Auto-scroll
                            const logDiv = document.getElementById('integrated-log');
                            logDiv.scrollTop = logDiv.scrollHeight;
                        }
                        
                        // Aggiorna animazioni in base alla fase
                        updateIntegratedAnimations(data);
                        
                        // Se completato
                        if (data.status === 'completed' || data.status === 'error') {
                            clearInterval(pollInterval);
                            document.getElementById('restart-integrated-test').disabled = false;
                        }
                    })
                    .catch(error => {
                        console.error('Errore polling:', error);
                        clearInterval(pollInterval);
                    });
            }, 100);
        }
        
        // Aggiorna animazioni test integrato
        function updateIntegratedAnimations(data) {
            const cardVisual = document.getElementById('card-visual');
            const readerVisual = document.getElementById('reader-visual');
            const gateVisual = document.getElementById('integrated-gate');
            const statusText = document.getElementById('integrated-status');
            
            switch(data.phase) {
                case 'connecting':
                    statusText.innerHTML = '<i class="fas fa-sync fa-spin"></i> Connessione hardware...';
                    statusText.className = 'text-info';
                    break;
                    
                case 'waiting_card':
                    cardVisual.className = 'card-animation waiting';
                    readerVisual.className = 'reader-visual scanning';
                    statusText.innerHTML = '<i class="fas fa-hand-paper"></i> INSERIRE TESSERA NEL LETTORE';
                    statusText.className = 'text-warning animated-text';
                    // LED giallo lampeggiante
                    document.getElementById('integrated-led-yellow').classList.add('blink');
                    break;
                    
                case 'reading_card':
                    cardVisual.className = 'card-animation inserting';
                    readerVisual.className = 'reader-visual active';
                    statusText.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Lettura tessera in corso...';
                    statusText.className = 'text-info';
                    document.getElementById('integrated-led-yellow').classList.remove('blink');
                    break;
                    
                case 'access_granted':
                    cardVisual.className = 'card-animation success';
                    readerVisual.className = 'reader-visual success';
                    statusText.innerHTML = '<i class="fas fa-check-circle"></i> ACCESSO AUTORIZZATO!';
                    statusText.className = 'text-success fw-bold';
                    // LED verde ON
                    document.getElementById('integrated-led-green').classList.add('active');
                    document.getElementById('integrated-led-red').classList.remove('active');
                    // Cancello aperto
                    gateVisual.classList.add('open');
                    // Buzzer
                    document.getElementById('integrated-buzzer').classList.add('active');
                    setTimeout(() => {
                        document.getElementById('integrated-buzzer').classList.remove('active');
                    }, 200);
                    break;
                    
                case 'access_denied':
                    cardVisual.className = 'card-animation denied';
                    readerVisual.className = 'reader-visual denied';
                    statusText.innerHTML = '<i class="fas fa-times-circle"></i> ACCESSO NEGATO!';
                    statusText.className = 'text-danger fw-bold';
                    // LED rosso ON
                    document.getElementById('integrated-led-red').classList.add('active');
                    document.getElementById('integrated-led-green').classList.remove('active');
                    // Buzzer multiplo
                    let beepCount = 0;
                    const beepInterval = setInterval(() => {
                        document.getElementById('integrated-buzzer').classList.toggle('active');
                        beepCount++;
                        if (beepCount >= 6) clearInterval(beepInterval);
                    }, 150);
                    break;
                
                case 'timeout':
                    cardVisual.className = 'card-animation';
                    readerVisual.className = 'reader-visual';
                    statusText.innerHTML = '<i class="fas fa-clock"></i> Timeout - Nessuna tessera inserita';
                    statusText.className = 'text-warning';
                    document.getElementById('integrated-led-yellow').classList.remove('blink');
                    break;
                    
                case 'error':
                    statusText.innerHTML = '<i class="fas fa-exclamation-triangle"></i> Errore durante il test';
                    statusText.className = 'text-danger';
                    break;
                    
                case 'completed':
                    // Reset dopo 3 secondi
                    setTimeout(() => {
                        if (data.authorized) {
                            gateVisual.classList.remove('open');
                            document.getElementById('integrated-led-green').classList.remove('active');
                        } else {
                            document.getElementById('integrated-led-red').classList.remove('active');
                        }
                        document.getElementById('integrated-led-yellow').classList.remove('blink');
                        cardVisual.className = 'card-animation';
                        statusText.innerHTML = '<i class="fas fa-check"></i> Test completato';
                        statusText.className = 'text-info';
                    }, 3000);
                    break;
            }
        }
        
        // Reset test integrato
        function resetIntegratedTest() {
            document.getElementById('integrated-log').innerHTML = 
                '<div class="text-muted text-center">Clicca "Avvia Test" per iniziare...</div>';
            document.getElementById('integrated-status').innerHTML = 
                '<i class="fas fa-info-circle"></i> Pronto';
            document.getElementById('integrated-status').className = '';
            document.getElementById('card-visual').className = 'card-animation';
            document.getElementById('reader-visual').className = 'reader-visual';
            document.getElementById('integrated-gate').classList.remove('open');
            document.getElementById('integrated-led-green').classList.remove('active');
            document.getElementById('integrated-led-red').classList.remove('active');
            document.getElementById('integrated-led-yellow').classList.remove('active', 'blink');
            document.getElementById('integrated-buzzer').classList.remove('active');
            document.getElementById('restart-integrated-test').disabled = true;
        }
    </script>
</body>
</html>
"""

# ===== TEST HARDWARE SEMPLICE =====
import threading
import sys
sys.path.insert(0, '/opt/access_control/src')

# Import hardware
try:
    from hardware.card_reader import CardReader
    HARDWARE_READER_OK = True
except:
    HARDWARE_READER_OK = False

try:
    from hardware.usb_rly08_controller import USBRLY08Controller  
    HARDWARE_RELAY_OK = True
except:
    HARDWARE_RELAY_OK = False

hardware_test_results = {}
hardware_test_lock = threading.Lock()

@app.route('/api/hardware/test-reader', methods=['POST'])
@require_auth()
def api_hardware_test_reader():
    if not HARDWARE_READER_OK:
        return jsonify({'success': False, 'error': 'CardReader non disponibile'})
    
    def test_reader():
        global hardware_test_results
        
        # Reset risultati
        with hardware_test_lock:
            hardware_test_results['reader'] = {
                'status': 'running', 
                'message': 'Inizializzazione...',
                'details': [],
                'timestamp': time.time()
            }
        
        try:
            details = []
            
            # Inizializzazione
            details.append("🔄 Inizializzazione lettore OMNIKEY 5427CK...")
            reader = CardReader()
            
            # Test connessione
            if reader.test_connection():
                details.append(f"✅ Lettore connesso: {str(reader.readers[0])}")
                details.append("💳 IN ATTESA TESSERA SANITARIA...")
                details.append("━" * 50)
            else:
                details.append("❌ ERRORE: Nessun lettore trovato")
                with hardware_test_lock:
                    hardware_test_results['reader'] = {
                        'status': 'error',
                        'message': 'Nessun lettore trovato',
                        'details': details,
                        'timestamp': time.time()
                    }
                return
            
            # Aggiorna stato iniziale
            with hardware_test_lock:
                hardware_test_results['reader']['details'] = details.copy()
                hardware_test_results['reader']['message'] = 'In attesa tessera...'
            
            # Loop principale - 60 secondi
            timeout = 60
            start_time = time.time()
            cards_read = 0
            last_cf = None
            
            while (time.time() - start_time) < timeout:
                try:
                    # Leggi tessera
                    cf = reader._read_card_robust(timeout=0.3)
                    
                    if cf and len(cf) == 16 and cf != last_cf:
                        # NUOVA TESSERA!
                        cards_read += 1
                        last_cf = cf
                        read_time = datetime.now().strftime('%H:%M:%S')
                        
                        # Log dettagliato per questa tessera
                        details.append(f"")
                        details.append(f"🎯 [{read_time}] TESSERA RILEVATA #{cards_read}")
                        details.append(f"📄 Codice Fiscale: {cf}")
                        
                        # Query database
                        conn = get_db_connection()
                        if conn:
                            cursor = conn.cursor()
                            cursor.execute("""SELECT nome, cognome, attivo FROM utenti_autorizzati WHERE codice_fiscale = ?""", (cf,))
                            user = cursor.fetchone()
                            
                            # Log accesso nel database
                            cursor.execute("""INSERT INTO log_accessi (codice_fiscale, timestamp, autorizzato) VALUES (?, ?, ?)""", (cf, datetime.now(), 1 if (user and user[2]) else 0))
                            conn.commit()
                            conn.close()
                            
                            if user:
                                nome = f"{user[0]} {user[1]}" if user[1] else user[0]
                                if user[2]:  # attivo
                                    details.append(f"✅ ACCESSO AUTORIZZATO")
                                    details.append(f"👤 Utente: {nome}")
                                    details.append(f"🚪 Cancello: APERTO (8 secondi)")
                                    details.append(f"✅ Log salvato nel database")
                                else:
                                    details.append(f"⚠️ UTENTE DISATTIVATO")
                                    details.append(f"👤 Utente: {nome}")
                                    details.append(f"🚫 Cancello: CHIUSO")
                                    details.append(f"📝 Log salvato: accesso negato")
                            else:
                                details.append(f"❌ ACCESSO NEGATO")
                                details.append(f"❓ Utente non presente nel database")
                                details.append(f"🚫 Cancello: CHIUSO")
                                details.append(f"📝 Log salvato: CF non autorizzato")
                        else:
                            details.append(f"⚠️ Errore database - accesso negato")
                        
                        details.append("━" * 50)
                        
                        # Aggiorna risultati
                        with hardware_test_lock:
                            hardware_test_results['reader']['details'] = details.copy()
                            hardware_test_results['reader']['message'] = f'Ultima tessera: {cf}'
                        
                        # Attendi che la tessera venga rimossa
                        time.sleep(2)
                        
                except Exception as e:
                    # Reset se tessera rimossa
                    if last_cf:
                        last_cf = None
                
                time.sleep(0.1)  # Check veloce
            
            # Fine test
            details.append("")
            details.append("⏱️ TEST COMPLETATO")
            details.append(f"📊 Tessere lette: {cards_read}")
            details.append(f"⏱️ Durata: {int(time.time() - start_time)} secondi")
            
            with hardware_test_lock:
                hardware_test_results['reader'] = {
                    'status': 'success' if cards_read > 0 else 'warning',
                    'message': f'Test completato - {cards_read} tessere lette',
                    'details': details,
                    'timestamp': time.time()
                }
                
        except Exception as e:
            details.append(f"❌ ERRORE: {str(e)}")
            with hardware_test_lock:
                hardware_test_results['reader'] = {
                    'status': 'error',
                    'message': f'Errore: {str(e)}',
                    'details': details,
                    'timestamp': time.time()
                }
    
    # Avvia test in background
    threading.Thread(target=test_reader, daemon=True).start()
    return jsonify({'success': True, 'message': 'Test lettore avviato'})

@app.route('/api/hardware/status')
@require_auth()
def api_hardware_status():
    test_id = request.args.get('test_id')
    with hardware_test_lock:
        if test_id and test_id in hardware_test_results:
            return jsonify({'success': True, 'test': hardware_test_results[test_id]})
        return jsonify({'success': True, 'tests': hardware_test_results})

if __name__ == '__main__':
    print("🌐 Avvio dashboard web allineata a database_manager.py")
    print(f"📄 Database: {DB_PATH}")
    print("🔗 URL: http://0.0.0.0:5000")
    app.run(host='0.0.0.0', port=5000, debug=False, threaded=True)