# File: /opt/access_control/src/api/dashboard_templates.py
# Template HTML per dashboard web

LOGIN_TEMPLATE = """
<!DOCTYPE html>
<html>
<head>
    <title>Sistema Controllo Accessi - Login</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        body { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); min-height: 100vh; }
        .login-container { max-width: 400px; margin: 0 auto; padding-top: 100px; }
        .card { border: none; border-radius: 15px; box-shadow: 0 8px 30px rgba(0,0,0,0.1); }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="card">
            <div class="card-body p-5">
                <div class="text-center mb-4">
                    <i class="fas fa-shield-alt fa-3x text-primary mb-3"></i>
                    <h4>Sistema Controllo Accessi</h4>
                    <p class="text-muted">Isola Ecologica RAEE - Rende</p>
                </div>
                
                {% if error %}
                <div class="alert alert-danger">{{ error }}</div>
                {% endif %}
                
                <form method="POST">
                    <div class="mb-3">
                        <label class="form-label">Username</label>
                        <input type="text" class="form-control" name="username" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Password</label>
                        <input type="password" class="form-control" name="password" required>
                    </div>
                    <button type="submit" class="btn btn-primary w-100">
                        <i class="fas fa-sign-in-alt me-2"></i>Accedi
                    </button>
                </form>
                
                <div class="mt-4 text-center">
                    <small class="text-muted">
                        Credenziali: admin/admin123, gestore/gestore123, readonly/readonly123
                    </small>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
"""

# Importa dashboard template da file separato per evitare file troppo grande
def get_dashboard_template():
    """Carica il template dashboard da file"""
    import os
    template_path = os.path.join(os.path.dirname(__file__), 'dashboard_template.html')
    try:
        with open(template_path, 'r', encoding='utf-8') as f:
            return f.read()
    except:
        # Fallback template minimo se file non trovato
        return """
<!DOCTYPE html>
<html>
<head>
    <title>Sistema Controllo Accessi - Dashboard</title>
    <meta charset="utf-8">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h1>Dashboard Sistema Controllo Accessi</h1>
        <div class="alert alert-warning">
            Template completo non trovato. Verificare file dashboard_template.html
        </div>
        <a href="/logout" class="btn btn-primary">Logout</a>
    </div>
</body>
</html>
"""
