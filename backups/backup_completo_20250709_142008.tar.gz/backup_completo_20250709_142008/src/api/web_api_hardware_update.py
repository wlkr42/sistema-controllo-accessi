# File: /opt/access_control/src/api/web_api_hardware_update.py
# Aggiornamento web_api.py per integrare test hardware reali

"""
ISTRUZIONI PER L'AGGIORNAMENTO:

1. Salvare backup del web_api.py esistente:
   cp /opt/access_control/src/api/web_api.py /opt/access_control/src/api/web_api_backup.py

2. Aggiungere questo codice al web_api.py esistente:
   - Import aggiuntivi all'inizio del file
   - Nuove route API per test hardware
   - JavaScript aggiornato per interfaccia dashboard

3. Riavviare dashboard per vedere i nuovi test
"""

# ========================================
# IMPORT AGGIUNTIVI DA AGGIUNGERE ALL'INIZIO DI WEB_API.PY
# ========================================

import sys
import threading
import time
from pathlib import Path

# Aggiungi path per hardware
sys.path.append('/opt/access_control/src')

# Import moduli hardware (con fallback se non disponibili)
try:
    from hardware.card_reader import CardReader
    CARD_READER_AVAILABLE = True
except ImportError as e:
    print(f"⚠️ CardReader non disponibile: {e}")
    CardReader = None
    CARD_READER_AVAILABLE = False

try:
    from hardware.usb_rly08_controller import USBRLY08Controller
    USB_RLY08_AVAILABLE = True
except ImportError as e:
    print(f"⚠️ USB-RLY08 non disponibile: {e}")
    USBRLY08Controller = None
    USB_RLY08_AVAILABLE = False

# Variabili globali per test
test_results = {}
test_lock = threading.Lock()

# ========================================
# NUOVE ROUTE API DA AGGIUNGERE A WEB_API.PY
# ========================================

@app.route('/api/test/reader', methods=['POST'])
@require_auth()
def api_test_reader():
    """API per test lettore tessere con feedback real-time"""
    global test_results
    
    if not CARD_READER_AVAILABLE:
        return jsonify({
            'success': False,
            'error': 'Modulo CardReader non disponibile'
        }), 500
    
    with test_lock:
        test_results['reader'] = {
            'status': 'running',
            'message': 'Test lettore in corso...',
            'timestamp': time.time(),
            'details': []
        }
    
    def run_reader_test():
        """Test lettore in thread separato"""
        try:
            details = []
            details.append("🔄 Inizializzazione lettore OMNIKEY 5427CK...")
            
            # Aggiorna risultati
            with test_lock:
                test_results['reader']['details'] = details.copy()
            
            reader = CardReader()
            
            # Test connessione
            details.append("🔌 Test connessione lettori...")
            if reader.test_connection():
                details.append(f"✅ Trovati {len(reader.readers)} lettori")
                for i, r in enumerate(reader.readers):
                    details.append(f"   Lettore {i+1}: {str(r)}")
            else:
                details.append("❌ Nessun lettore smart card trovato")
                with test_lock:
                    test_results['reader'] = {
                        'status': 'error',
                        'message': 'Nessun lettore trovato',
                        'timestamp': time.time(),
                        'details': details
                    }
                return
            
            # Test APDU
            details.append("💳 Test sequenza APDU...")
            details.append("   Inserire tessera sanitaria per test completo...")
            
            with test_lock:
                test_results['reader']['details'] = details.copy()
                test_results['reader']['message'] = 'Pronto per tessera (timeout 8s)...'
            
            # Test con timeout
            start_time = time.time()
            timeout = 8
            card_found = False
            
            while (time.time() - start_time) < timeout and not card_found:
                try:
                    cf = reader._read_card_robust(timeout=1)
                    if cf and len(cf) == 16:
                        details.append(f"✅ Tessera letta: {cf}")
                        details.append("✅ Sequenza APDU ISO7816 OK")
                        details.append("✅ Estrazione codice fiscale OK")
                        details.append("✅ Formato codice fiscale valido")
                        card_found = True
                        break
                except:
                    pass
                
                remaining = int(timeout - (time.time() - start_time))
                with test_lock:
                    test_results['reader']['message'] = f'Attendere tessera (timeout: {remaining}s)'
            
            if card_found:
                details.append("🎯 TEST LETTORE COMPLETATO CON SUCCESSO!")
                final_status = 'success'
                final_message = 'Lettore completamente funzionante'
            else:
                details.append("⚠️ Timeout - nessuna tessera inserita")
                details.append("💡 Hardware lettore operativo")
                final_status = 'warning'
                final_message = 'Hardware OK - Nessuna tessera testata'
            
            with test_lock:
                test_results['reader'] = {
                    'status': final_status,
                    'message': final_message,
                    'timestamp': time.time(),
                    'details': details
                }
                
        except Exception as e:
            with test_lock:
                test_results['reader'] = {
                    'status': 'error',
                    'message': f'Errore test: {str(e)}',
                    'timestamp': time.time(),
                    'details': details + [f"❌ Errore: {str(e)}"]
                }
    
    threading.Thread(target=run_reader_test, daemon=True).start()
    
    return jsonify({
        'success': True,
        'message': 'Test lettore avviato',
        'test_id': 'reader'
    })

@app.route('/api/test/relay', methods=['POST'])
@require_auth()
def api_test_relay():
    """API per test USB-RLY08 con feedback real-time"""
    global test_results
    
    if not USB_RLY08_AVAILABLE:
        return jsonify({
            'success': False,
            'error': 'Modulo USB-RLY08 non disponibile'
        }), 500
    
    with test_lock:
        test_results['relay'] = {
            'status': 'running',
            'message': 'Test USB-RLY08 in corso...',
            'timestamp': time.time(),
            'details': []
        }
    
    def run_relay_test():
        """Test USB-RLY08 in thread separato"""
        try:
            details = []
            details.append("🔄 Inizializzazione USB-RLY08...")
            
            with test_lock:
                test_results['relay']['details'] = details.copy()
            
            # Test connessione su porte multiple
            ports_to_test = ["/dev/ttyACM0", "/dev/ttyUSB0"]
            controller = None
            connected_port = None
            
            for port in ports_to_test:
                details.append(f"🔌 Test connessione {port}...")
                with test_lock:
                    test_results['relay']['details'] = details.copy()
                
                try:
                    test_controller = USBRLY08Controller(port=port)
                    if test_controller.connect():
                        details.append(f"✅ USB-RLY08 connesso a {port}")
                        controller = test_controller
                        connected_port = port
                        break
                    else:
                        details.append(f"❌ Connessione fallita a {port}")
                except Exception as e:
                    details.append(f"❌ Errore {port}: {str(e)}")
            
            if not controller:
                details.append("❌ USB-RLY08 non trovato su nessuna porta")
                with test_lock:
                    test_results['relay'] = {
                        'status': 'error',
                        'message': 'USB-RLY08 non collegato',
                        'timestamp': time.time(),
                        'details': details
                    }
                return
            
            # Test comunicazione
            details.append("📋 Test comunicazione seriale...")
            with test_lock:
                test_results['relay']['details'] = details.copy()
            
            if controller.health_check():
                details.append("✅ Comunicazione seriale OK")
            else:
                details.append("❌ Errore comunicazione")
                controller.disconnect()
                with test_lock:
                    test_results['relay'] = {
                        'status': 'error',
                        'message': 'Errore comunicazione',
                        'timestamp': time.time(),
                        'details': details
                    }
                return
            
            # Test stati relè
            details.append("📊 Lettura stati relè...")
            states = controller.get_relay_states()
            if states:
                details.append(f"✅ Stati letti: {len(states)} relè disponibili")
                for name, state in list(states.items())[:3]:  # Mostra primi 3
                    status = "ON" if state else "OFF"
                    details.append(f"   {name}: {status}")
            
            with test_lock:
                test_results['relay']['details'] = details.copy()
            
            # Test sicuro relè (lampeggio veloce)
            details.append("🔧 Test funzionamento relè...")
            
            # Test LED Verde
            details.append("   🟢 Test LED Verde...")
            controller._set_relay_state(controller.RelayChannel.LED_GREEN, True)
            time.sleep(0.3)
            controller._set_relay_state(controller.RelayChannel.LED_GREEN, False)
            details.append("   ✅ LED Verde OK")
            
            time.sleep(0.2)
            
            # Test LED Rosso
            details.append("   🔴 Test LED Rosso...")
            controller._set_relay_state(controller.RelayChannel.LED_RED, True)
            time.sleep(0.3)
            controller._set_relay_state(controller.RelayChannel.LED_RED, False)
            details.append("   ✅ LED Rosso OK")
            
            time.sleep(0.2)
            
            # Test funzioni sistema
            details.append("🎯 Test segnalazioni sistema...")
            controller.access_granted()  # LED Verde + Buzzer
            time.sleep(1)
            details.append("   ✅ Segnalazione accesso OK")
            
            # Spegni tutto
            controller.emergency_stop()
            details.append("💡 Spegnimento tutti i relè...")
            
            # Disconnessione
            controller.disconnect()
            details.append("🎯 TEST USB-RLY08 COMPLETATO CON SUCCESSO!")
            
            with test_lock:
                test_results['relay'] = {
                    'status': 'success',
                    'message': f'USB-RLY08 completamente funzionante su {connected_port}',
                    'timestamp': time.time(),
                    'details': details
                }
                
        except Exception as e:
            if 'controller' in locals() and controller:
                try:
                    controller.disconnect()
                except:
                    pass
            
            with test_lock:
                test_results['relay'] = {
                    'status': 'error',
                    'message': f'Errore test: {str(e)}',
                    'timestamp': time.time(),
                    'details': details + [f"❌ Errore: {str(e)}"]
                }
    
    threading.Thread(target=run_relay_test, daemon=True).start()
    
    return jsonify({
        'success': True,
        'message': 'Test USB-RLY08 avviato',
        'test_id': 'relay'
    })

@app.route('/api/test/status')
@require_auth()
def api_test_status():
    """API per stato test in corso"""
    global test_results
    
    test_id = request.args.get('test_id')
    
    with test_lock:
        if test_id and test_id in test_results:
            return jsonify({
                'success': True,
                'test': test_results[test_id]
            })
        else:
            return jsonify({
                'success': True,
                'tests': test_results
            })

# ========================================
# AGGIORNAMENTO ROUTE /test-hardware ESISTENTE
# ========================================

# SOSTITUIRE la funzione test_hardware esistente con questa:
@app.route('/test-hardware')
def test_hardware():
    """Test hardware con possibilità di test reali"""
    hardware_status = {
        'lettore_cf': {'status': 'unknown', 'message': 'Hardware non testato'},
        'rele_usb': {'status': 'unknown', 'message': 'Hardware non testato'},
        'rete': {'status': 'ok', 'message': 'Connessione web funzionante'}
    }
    
    # Verifica moduli disponibili
    if CARD_READER_AVAILABLE:
        hardware_status['lettore_cf']['status'] = 'ready'
        hardware_status['lettore_cf']['message'] = 'Modulo pronto - Test disponibile'
    else:
        hardware_status['lettore_cf']['status'] = 'error'
        hardware_status['lettore_cf']['message'] = 'Modulo non disponibile (pyscard?)'
    
    if USB_RLY08_AVAILABLE:
        hardware_status['rele_usb']['status'] = 'ready'
        hardware_status['rele_usb']['message'] = 'Modulo pronto - Test disponibile'
    else:
        hardware_status['rele_usb']['status'] = 'error'
        hardware_status['rele_usb']['message'] = 'Modulo non disponibile (pyserial?)'
    
    return {
        'status': 'success',
        'message': 'Test hardware avanzati disponibili',
        'hardware': hardware_status
    }

# ========================================
# JAVASCRIPT AGGIORNATO PER DASHBOARD
# ========================================

DASHBOARD_HARDWARE_JS = """
<!-- AGGIUNGERE QUESTO JAVASCRIPT ALLA SEZIONE DISPOSITIVI DELLA DASHBOARD -->

<script>
// Variabili per polling test
let testPollingIntervals = {};

// Funzione per avviare test lettore
async function startReaderTest() {
    const button = document.getElementById('test-reader-btn');
    const output = document.getElementById('reader-test-output');
    
    if (!button || !output) return;
    
    // Disabilita pulsante
    button.disabled = true;
    button.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Test in corso...';
    
    // Pulisci output
    output.innerHTML = '<div class="loading">Avvio test lettore...</div>';
    
    try {
        // Avvia test
        const response = await fetch('/api/test/reader', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'}
        });
        
        const data = await response.json();
        
        if (data.success) {
            // Avvia polling per aggiornamenti
            startTestPolling('reader', output, button);
        } else {
            output.innerHTML = `<div class="error">❌ ${data.error}</div>`;
            button.disabled = false;
            button.innerHTML = '<i class="fas fa-play"></i> Test Lettore';
        }
    } catch (error) {
        output.innerHTML = `<div class="error">❌ Errore: ${error.message}</div>`;
        button.disabled = false;
        button.innerHTML = '<i class="fas fa-play"></i> Test Lettore';
    }
}

// Funzione per avviare test USB-RLY08
async function startRelayTest() {
    const button = document.getElementById('test-relay-btn');
    const output = document.getElementById('relay-test-output');
    
    if (!button || !output) return;
    
    // Disabilita pulsante
    button.disabled = true;
    button.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Test in corso...';
    
    // Pulisci output
    output.innerHTML = '<div class="loading">Avvio test USB-RLY08...</div>';
    
    try {
        // Avvia test
        const response = await fetch('/api/test/relay', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'}
        });
        
        const data = await response.json();
        
        if (data.success) {
            // Avvia polling per aggiornamenti
            startTestPolling('relay', output, button);
        } else {
            output.innerHTML = `<div class="error">❌ ${data.error}</div>`;
            button.disabled = false;
            button.innerHTML = '<i class="fas fa-play"></i> Test USB-RLY08';
        }
    } catch (error) {
        output.innerHTML = `<div class="error">❌ Errore: ${error.message}</div>`;
        button.disabled = false;
        button.innerHTML = '<i class="fas fa-play"></i> Test USB-RLY08';
    }
}

// Polling per aggiornamenti test
function startTestPolling(testId, outputElement, buttonElement) {
    // Ferma polling precedente se esiste
    if (testPollingIntervals[testId]) {
        clearInterval(testPollingIntervals[testId]);
    }
    
    testPollingIntervals[testId] = setInterval(async () => {
        try {
            const response = await fetch(`/api/test/status?test_id=${testId}`);
            const data = await response.json();
            
            if (data.success && data.test) {
                const test = data.test;
                
                // Aggiorna output
                let html = `<div class="test-status test-${test.status}">`;
                html += `<strong>Status:</strong> ${test.message}<br>`;
                html += `<strong>Tempo:</strong> ${new Date(test.timestamp * 1000).toLocaleTimeString()}<br><br>`;
                
                if (test.details && test.details.length > 0) {
                    html += '<strong>Dettagli:</strong><br>';
                    html += '<div class="test-details">';
                    test.details.forEach(detail => {
                        html += `${detail}<br>`;
                    });
                    html += '</div>';
                }
                
                html += '</div>';
                outputElement.innerHTML = html;
                
                // Se test completato, riabilita pulsante
                if (test.status !== 'running') {
                    clearInterval(testPollingIntervals[testId]);
                    delete testPollingIntervals[testId];
                    
                    buttonElement.disabled = false;
                    if (testId === 'reader') {
                        buttonElement.innerHTML = '<i class="fas fa-play"></i> Test Lettore';
                    } else if (testId === 'relay') {
                        buttonElement.innerHTML = '<i class="fas fa-play"></i> Test USB-RLY08';
                    }
                }
            }
        } catch (error) {
            console.error('Errore polling test:', error);
        }
    }, 1000); // Aggiorna ogni secondo
}

// CSS per styling test
const testStyles = `
<style>
.test-status {
    padding: 15px;
    border-radius: 8px;
    margin: 10px 0;
    font-family: 'Courier New', monospace;
    font-size: 0.9em;
}
.test-success {
    background: #d4edda;
    color: #155724;
    border-left: 4px solid #28a745;
}
.test-warning {
    background: #fff3cd;
    color: #856404;
    border-left: 4px solid #ffc107;
}
.test-error {
    background: #f8d7da;
    color: #721c24;
    border-left: 4px solid #dc3545;
}
.test-running {
    background: #d1ecf1;
    color: #0c5460;
    border-left: 4px solid #17a2b8;
}
.test-details {
    margin-top: 10px;
    padding: 10px;
    background: rgba(0,0,0,0.05);
    border-radius: 4px;
    white-space: pre-line;
}
.loading {
    text-align: center;
    color: #666;
    font-style: italic;
}
.error {
    color: #dc3545;
    font-weight: bold;
}
</style>
`;

// Aggiungi CSS se non presente
if (!document.getElementById('test-hardware-styles')) {
    const styleElement = document.createElement('div');
    styleElement.id = 'test-hardware-styles';
    styleElement.innerHTML = testStyles;
    document.head.appendChild(styleElement);
}

// Cleanup polling quando si cambia pagina
window.addEventListener('beforeunload', function() {
    Object.values(testPollingIntervals).forEach(interval => {
        clearInterval(interval);
    });
});
</script>
"""

# ========================================
# HTML AGGIORNATO PER SEZIONE DISPOSITIVI
# ========================================

DASHBOARD_HARDWARE_HTML = """
<!-- AGGIUNGERE QUESTA SEZIONE ALLA PAGINA DISPOSITIVI -->

<div class="row">
    <div class="col-md-6">
        <div class="card">
            <h4><i class="fas fa-credit-card"></i> Test Lettore Tessere</h4>
            <p class="text-muted">Test funzionamento lettore OMNIKEY 5427CK</p>
            
            <button id="test-reader-btn" class="btn btn-primary mb-3" onclick="startReaderTest()">
                <i class="fas fa-play"></i> Test Lettore
            </button>
            
            <div id="reader-test-output" class="test-output">
                <div class="text-muted">Cliccare "Test Lettore" per avviare il test</div>
            </div>
        </div>
    </div>
    
    <div class="col-md-6">
        <div class="card">
            <h4><i class="fas fa-microchip"></i> Test Controller USB-RLY08</h4>
            <p class="text-muted">Test funzionamento controller relè USB-RLY08</p>
            
            <button id="test-relay-btn" class="btn btn-success mb-3" onclick="startRelayTest()">
                <i class="fas fa-play"></i> Test USB-RLY08
            </button>
            
            <div id="relay-test-output" class="test-output">
                <div class="text-muted">Cliccare "Test USB-RLY08" per avviare il test</div>
            </div>
        </div>
    </div>
</div>
"""

print("✅ Codice di integrazione test hardware pronto")
print()
print("📋 ISTRUZIONI PER L'IMPLEMENTAZIONE:")
print("1. Backup web_api.py esistente")
print("2. Aggiungere import e variabili globali")
print("3. Aggiungere le nuove route API")
print("4. Sostituire la route /test-hardware")
print("5. Aggiungere HTML e JavaScript alla pagina dispositivi")
print("6. Riavviare dashboard")
