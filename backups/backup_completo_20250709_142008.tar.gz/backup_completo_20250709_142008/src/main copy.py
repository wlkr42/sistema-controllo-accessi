# File: /opt/access_control/src/main.py
# APPLICAZIONE PRINCIPALE CON INTEGRAZIONE ODOO

import sys
import os
import time
import signal
import logging
import threading
from datetime import datetime, timedelta
from pathlib import Path

# Aggiungi moduli al path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'hardware'))
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'database'))
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'external'))

# Import moduli
try:
    from card_reader import CardReader
    from database_manager import DatabaseManager
    from odoo_partner_connector import OdooPartnerConnector
    print("✅ Moduli importati correttamente")
except ImportError as e:
    print(f"⚠️ Import warning: {e}")

# Setup logging sicuro
project_root = Path(__file__).parent.parent
log_dir = project_root / "logs"
log_dir.mkdir(exist_ok=True)

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler(log_dir / 'access_control.log')
    ]
)
logger = logging.getLogger(__name__)

# Security audit logger
security_logger = logging.getLogger('security_audit')
security_handler = logging.FileHandler(log_dir / 'security_audit.log')
security_handler.setFormatter(logging.Formatter(
    '%(asctime)s - SECURITY - %(levelname)s - %(message)s'
))
security_logger.addHandler(security_handler)
security_logger.setLevel(logging.INFO)

# Mock components
class MockArduino:
    def access_granted(self):
        print("🟢 Arduino: LED VERDE + Beep")
        logger.info("Hardware: Accesso autorizzato")
    
    def access_denied(self):
        print("🔴 Arduino: LED ROSSO + 3 Beep")
        logger.warning("Hardware: Accesso negato")
    
    def processing(self, active):
        status = "ON" if active else "OFF"
        print(f"🟡 Arduino: Processing {status}")

class MockRelay:
    def open_gate(self, duration=5):
        print(f"🚪 CANCELLO APERTO per {duration} secondi")
        logger.info(f"Hardware: Cancello aperto per {duration}s")
        security_logger.info(f"GATE_OPENED - Duration: {duration}s")

class MockConfigManager:
    """Config Manager mock per OdooPartnerConnector"""
    
    def __init__(self):
        self.config = MockConfig()
    
    def get_config(self):
        return self.config

class MockConfig:
    """Config mock che simula la struttura richiesta"""
    
    def __init__(self):
        # Mock configuration - OdooPartnerConnector controllerà hasattr(self.config, 'odoo')
        self.odoo = None  # Questo farà sì che il connector non trovi config Odoo e userà la configurazione manuale

class AccessControlSystem:
    """Sistema controllo accessi con integrazione Odoo sicura per Rende"""
    
    def __init__(self):
        self.running = False
        self.last_sync_time = None
        self.sync_in_progress = False
        
        # Statistiche con sicurezza
        self.stats = {
            'total': 0, 'authorized': 0, 'denied': 0,
            'sync_operations': 0, 'failed_connections': 0,
            'last_security_check': None
        }
        
        # Rate limiting sicurezza
        self.rate_limiter = {
            'max_attempts_per_minute': 60,
            'attempts_log': [],
            'blocked_until': None
        }
        
        # Componenti
        self.card_reader = None
        self.arduino = MockArduino()
        self.relay = MockRelay()
        self.database = None
        self.odoo_connector = None
        
        # Configurazione Odoo CORRETTA
        self.odoo_config = {
            'url': 'https://app.calabramaceri.it',
            'database': 'cmapp',
            'username': 'controllo-accessi@calabramaceri.it',  # CORRETTO
            'password': 'AcC3ss0C0ntr0l!2025#Rnd',
            'comune': 'Rende',
            'sync_interval_hours': 12
        }
        
        print("🏗️ Sistema con Odoo inizializzato per Rende")
        security_logger.info("SYSTEM_INIT - Access control system started for Rende")
    
    def security_check(self) -> bool:
        """Controlli sicurezza avanzati"""
        try:
            current_time = datetime.now()
            
            # Rate limiting check
            if self.rate_limiter['blocked_until']:
                if current_time < self.rate_limiter['blocked_until']:
                    return False
                else:
                    self.rate_limiter['blocked_until'] = None
            
            # Pulizia rate limiter
            one_minute_ago = current_time - timedelta(minutes=1)
            self.rate_limiter['attempts_log'] = [
                t for t in self.rate_limiter['attempts_log'] if t > one_minute_ago
            ]
            
            # Rate limit check
            if len(self.rate_limiter['attempts_log']) >= self.rate_limiter['max_attempts_per_minute']:
                self.rate_limiter['blocked_until'] = current_time + timedelta(minutes=5)
                security_logger.critical("RATE_LIMIT_EXCEEDED - Sistema bloccato")
                return False
            
            self.stats['last_security_check'] = current_time
            return True
            
        except Exception as e:
            security_logger.error(f"SECURITY_CHECK_FAILED - {e}")
            return False
    
    def log_access_attempt(self, cf: str, authorized: bool):
        """Log sicuro tentativi accesso"""
        timestamp = datetime.now()
        self.rate_limiter['attempts_log'].append(timestamp)
        
        # CF mascherato per log sicurezza
        masked_cf = f"{cf[:4]}***{cf[-4:]}"
        security_logger.info(
            f"ACCESS_ATTEMPT - CF: {masked_cf} - "
            f"Authorized: {authorized} - Timestamp: {timestamp.isoformat()}"
        )
    
    def initialize(self):
        """Inizializza componenti con Odoo"""
        print("🔧 Inizializzazione componenti con Odoo sicuro...")
        
        try:
            # Security check
            if not self.security_check():
                logger.error("❌ Security check fallito")
                return False
            
            # CardReader
            self.card_reader = CardReader()
            logger.info("✅ CardReader inizializzato")
            
            # Database
            db_path = project_root / "src" / "access.db"
            self.database = DatabaseManager(str(db_path))
            
            if not self.database.health_check():
                logger.error("❌ Database non funzionante")
                return False
            
            logger.info("✅ Database inizializzato")
            
            # Odoo Connector con configurazione CORRETTA e FIX CONFIG MANAGER
            mock_config_manager = MockConfigManager()
            self.odoo_connector = OdooPartnerConnector(mock_config_manager)
            self.odoo_connector.configure_connection(
                url=self.odoo_config['url'],
                database=self.odoo_config['database'],
                username=self.odoo_config['username'],  # Email corretta
                password=self.odoo_config['password'],
                comune=self.odoo_config['comune'],
                sync_interval=self.odoo_config['sync_interval_hours'] * 3600
            )
            
            # Test connessione
            success, message = self.odoo_connector.test_connection()
            if success:
                logger.info("✅ Connessione Odoo sicura stabilita")
                security_logger.info(f"ODOO_CONNECTION_SUCCESS - {message}")
                
                # SYNC COMPLETA PRIMA DELL'AVVIO - BLOCCA FINO A COMPLETAMENTO
                print("🔄 Sincronizzazione database in corso...")
                print("⏳ Attendere completamento prima dell'avvio sistema...")
                logger.info("🔄 Esecuzione sync completa OBBLIGATORIA prima dell'avvio...")
                
                sync_success, sync_stats = self.odoo_connector.sync_to_database(self.database)
                
                if sync_success:
                    citizens_added = sync_stats.get('added', 0)
                    citizens_fetched = sync_stats.get('fetched', 0)
                    print(f"✅ Sincronizzazione completata!")
                    print(f"📊 {citizens_fetched} cittadini recuperati, {citizens_added} aggiunti al database")
                    logger.info(f"✅ Sync iniziale completata: {citizens_added} cittadini aggiunti")
                    self.stats['sync_operations'] += 1
                    self.last_sync_time = datetime.now()
                else:
                    print("❌ ERRORE: Sincronizzazione fallita!")
                    logger.error("❌ Sync iniziale fallita - sistema continuerà con database locale")
                    print("⚠️ Sistema continuerà con database locale (solo utenti test)")
                
                # Avvia sync automatica periodica
                self.start_auto_sync()
                
            else:
                logger.warning(f"⚠️ Test Odoo fallito: {message}")
                security_logger.warning(f"ODOO_CONNECTION_FAILED - {message}")
                logger.info("🔄 Sistema continuerà con database locale")
            
            return True
            
        except Exception as e:
            logger.error(f"❌ Errore inizializzazione: {e}")
            security_logger.error(f"INIT_FAILED - {e}")
            return False
    
    def start_auto_sync(self):
        """Avvia sincronizzazione automatica sicura (solo periodica)"""
        def sync_worker():
            while self.running:
                try:
                    # Attendi prossimo ciclo (non sync immediata qui)
                    sleep_hours = self.odoo_config['sync_interval_hours']
                    logger.info(f"⏰ Prossima sync automatica in {sleep_hours} ore")
                    time.sleep(sleep_hours * 3600)
                    
                    # Sync periodica
                    if self.running:  # Controlla se sistema ancora attivo
                        self.perform_sync()
                    
                except Exception as e:
                    logger.error(f"❌ Errore sync worker: {e}")
                    time.sleep(3600)  # Retry dopo 1 ora
        
        sync_thread = threading.Thread(target=sync_worker, daemon=True)
        sync_thread.start()
        logger.info("🔄 Auto-sync Odoo avviata")
    
    def perform_sync(self):
        """Esegue sincronizzazione sicura"""
        if self.sync_in_progress:
            return
        
        self.sync_in_progress = True
        sync_start = datetime.now()
        
        try:
            logger.info("🔄 Inizio sincronizzazione Odoo sicura")
            security_logger.info("SYNC_START - Odoo synchronization initiated")
            
            success, stats = self.odoo_connector.sync_to_database(self.database)
            
            if success:
                self.last_sync_time = datetime.now()
                self.stats['sync_operations'] += 1
                
                duration = (datetime.now() - sync_start).total_seconds()
                logger.info(f"✅ Sync completata in {duration:.2f}s - Stats: {stats}")
                
                security_logger.info(
                    f"SYNC_SUCCESS - Duration: {duration:.2f}s - "
                    f"Citizens: {stats['fetched']} - Added: {stats['added']}"
                )
            else:
                self.stats['failed_connections'] += 1
                logger.warning("⚠️ Sincronizzazione fallita")
                
        except Exception as e:
            logger.error(f"❌ Errore sync: {e}")
            security_logger.error(f"SYNC_ERROR - {e}")
        finally:
            self.sync_in_progress = False
    
    def handle_cf(self, codice_fiscale):
        """Gestisce CF con sicurezza avanzata"""
        if not self.security_check():
            logger.warning("⚠️ Security check fallito - accesso bloccato")
            self.arduino.access_denied()
            return
        
        start_time = time.time()
        masked_cf = f"{codice_fiscale[:4]}***{codice_fiscale[-4:]}"
        
        logger.info(f"🎯 CF ricevuto: {masked_cf}")
        
        # Processing
        self.arduino.processing(True)
        
        try:
            # Verifica accesso
            authorized, user_data = self.database.verify_access(codice_fiscale)
            
            # Log tentativo
            self.log_access_attempt(codice_fiscale, authorized)
            
            # Statistiche
            self.stats['total'] += 1
            if authorized:
                self.stats['authorized'] += 1
            else:
                self.stats['denied'] += 1
            
            # Log database
            processing_time = time.time() - start_time
            self.database.log_access(
                codice_fiscale=codice_fiscale,
                authorized=authorized,
                processing_time=processing_time,
                user_data=user_data,
                terminal_id="RENDE_GATE_001"
            )
            
            # Azioni
            self.arduino.processing(False)
            
            if authorized:
                # ACCESSO OK
                user_name = f"{user_data.get('nome', '')} {user_data.get('cognome', '')}" if user_data else 'Cittadino'
                
                print(f"\n✅ ACCESSO AUTORIZZATO - RENDE")
                print(f"👤 Cittadino: {user_name}")
                print(f"🆔 CF: {masked_cf}")
                print(f"⏱️ Tempo: {processing_time:.2f}s")
                
                self.arduino.access_granted()
                self.relay.open_gate(5)
                
            else:
                # ACCESSO NEGATO
                print(f"\n❌ ACCESSO NEGATO")
                print(f"⚠️ CF non autorizzato: {masked_cf}")
                print(f"🏘️ Comune: {self.odoo_config['comune']}")
                
                self.arduino.access_denied()
            
            # Statistiche
            self.print_stats()
            print("-" * 50)
            
        except Exception as e:
            logger.error(f"❌ Errore gestione CF: {e}")
            security_logger.error(f"CF_HANDLING_ERROR - {e}")
            self.arduino.access_denied()
        finally:
            self.arduino.processing(False)
    
    def print_stats(self):
        """Stampa statistiche sicurezza"""
        total = self.stats['total']
        success_rate = (self.stats['authorized'] / total * 100) if total > 0 else 0
        
        print(f"📊 Stats: {self.stats['authorized']}/{total} autorizzati ({success_rate:.1f}%)")
        print(f"🔄 Sync Odoo: {self.stats['sync_operations']} completate")
        
        if self.last_sync_time:
            hours_ago = (datetime.now() - self.last_sync_time).total_seconds() / 3600
            print(f"⏰ Ultima sync: {hours_ago:.1f}h fa")
    
    def run(self):
        """Avvia sistema sicuro"""
        print("🚀 AVVIO SISTEMA CONTROLLO ACCESSI SICURO")
        print("=" * 50)
        print(f"📅 {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        print(f"🏘️ Comune: {self.odoo_config['comune']}")
        print(f"🔗 Server: {self.odoo_config['url']}")
        print(f"👤 Utente: {self.odoo_config['username']}")
        print()
        print("🔧 Inizializzazione e sincronizzazione database...")
        
        if not self.initialize():
            print("❌ Inizializzazione fallita")
            return False
        
        print(f"\n🏥 SISTEMA SICURO ATTIVO")
        print("=" * 50)
        print("💳 Inserire tessere sanitarie cittadini Rende")
        print("🔐 Controlli sicurezza attivi")
        print("🔄 Sincronizzazione automatica ogni 12h")
        print("📝 Audit log completo")
        print("⏹️ Ctrl+C per fermare")
        print("=" * 50)
        
        try:
            self.running = True
            
            # Avvia CardReader
            self.card_reader.start_continuous_reading(self.handle_cf)
            
        except KeyboardInterrupt:
            print("\n⏹️ Arresto richiesto")
        except Exception as e:
            logger.error(f"\n❌ Errore: {e}")
            security_logger.critical(f"SYSTEM_ERROR - {e}")
        finally:
            self.shutdown()
        
        return True
    
    def shutdown(self):
        """Arresto sicuro sistema"""
        print("\n🛑 Arresto sicuro...")
        security_logger.info("SYSTEM_SHUTDOWN - Secure shutdown initiated")
        
        self.running = False
        
        if self.card_reader:
            self.card_reader.stop()
        
        if self.odoo_connector:
            self.odoo_connector.disconnect()
        
        # Statistiche finali
        print(f"\n📊 STATISTICHE FINALI:")
        print(f"   Accessi totali: {self.stats['total']}")
        print(f"   Autorizzati: {self.stats['authorized']}")
        print(f"   Negati: {self.stats['denied']}")
        print(f"   Sync completate: {self.stats['sync_operations']}")
        
        if self.last_sync_time:
            print(f"   Ultima sync: {self.last_sync_time.strftime('%H:%M:%S')}")
        
        security_logger.info(
            f"SYSTEM_SHUTDOWN_COMPLETE - Total: {self.stats['total']} - "
            f"Authorized: {self.stats['authorized']} - Denied: {self.stats['denied']}"
        )
        
        print("✅ Sistema arrestato in sicurezza")

# Gestione segnali
system = None

def signal_handler(signum, frame):
    print(f"\n🛑 Segnale {signum}...")
    global system
    if system:
        system.running = False
    sys.exit(0)

def main():
    """Main applicazione"""
    print("🏥 SISTEMA CONTROLLO ACCESSI SICURO - RENDE")
    print("=" * 50)
    print(f"⏰ {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("💳 CardReader FUNZIONANTE ✅")
    print("🔗 Integrazione Odoo SICURA ✅")
    print("🏘️ Configurato per Comune di RENDE ✅")
    print()
    
    # Signal handlers
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)
    
    try:
        global system
        system = AccessControlSystem()
        
        if system.run():
            print("✅ Sistema terminato OK")
            sys.exit(0)
        else:
            print("❌ Sistema terminato con errori")
            sys.exit(1)
    
    except Exception as e:
        logger.error(f"❌ Errore critico: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()