#!/usr/bin/env python3
# File: /opt/access_control/scripts/create_project_snapshot.py
# Script per creare snapshot completo del progetto in formato Markdown

import os
import sys
from pathlib import Path
from datetime import datetime
import fnmatch

def create_project_snapshot():
    """Crea snapshot completo del progetto"""
    
    # Directory base del progetto
    project_root = Path("/opt/access_control")
    output_file = project_root / "PROJECT_SNAPSHOT.md"
    
    # File e directory da includere (solo codice funzionale)
    include_patterns = [
        "*.py",           # File Python
        "*.yml", "*.yaml", # File configurazione
        "*.json",         # File JSON
        "*.txt",          # Requirements, README, etc
        "*.md",           # Documentazione
        "*.ino",          # Arduino sketch
        "*.cpp", "*.c", "*.h",  # Codice C/C++
        "*.sql",          # Schema database
        "*.service",      # Systemd services
        "*.conf",         # File configurazione
    ]
    
    # Directory da escludere
    exclude_dirs = {
        "__pycache__",
        ".git", ".vscode",
        "venv", "env", ".env",
        "logs", "backups",
        "cache", ".cache",
        "data",
        "node_modules",
        ".pytest_cache",
        "build", "dist",
        "temp", "tmp"
    }
    
    # File da escludere
    exclude_files = {
        "*.pyc", "*.pyo", "*.pyd",
        "*.log", "*.bak", "*.swp",
        "*.tmp", "*.temp",
        ".DS_Store", "Thumbs.db",
        "*.sqlite", "*.db"  # Database files (troppo grandi)
    }
    
    def should_include_file(file_path):
        """Determina se un file deve essere incluso"""
        file_name = file_path.name
        
        # Escludi file specifici
        for pattern in exclude_files:
            if fnmatch.fnmatch(file_name, pattern):
                return False
        
        # Includi solo file con pattern specificati
        for pattern in include_patterns:
            if fnmatch.fnmatch(file_name, pattern):
                return True
        
        return False
    
    def should_include_dir(dir_path):
        """Determina se una directory deve essere inclusa"""
        return dir_path.name not in exclude_dirs
    
    def get_file_tree(root_path):
        """Genera albero dei file del progetto"""
        tree_lines = []
        
        def add_to_tree(path, prefix=""):
            items = []
            try:
                for item in sorted(path.iterdir()):
                    if item.is_dir() and should_include_dir(item):
                        items.append((item, True))  # True = directory
                    elif item.is_file() and should_include_file(item):
                        items.append((item, False))  # False = file
            except PermissionError:
                tree_lines.append(f"{prefix}[Permission Denied]")
                return
            
            for i, (item, is_dir) in enumerate(items):
                is_last = i == len(items) - 1
                current_prefix = "└── " if is_last else "├── "
                tree_lines.append(f"{prefix}{current_prefix}{item.name}")
                
                if is_dir:
                    next_prefix = prefix + ("    " if is_last else "│   ")
                    add_to_tree(item, next_prefix)
        
        tree_lines.append(f"{root_path.name}/")
        add_to_tree(root_path)
        return tree_lines
    
    def read_file_content(file_path):
        """Legge contenuto file con gestione errori"""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                return f.read()
        except UnicodeDecodeError:
            try:
                with open(file_path, 'r', encoding='latin-1') as f:
                    return f.read()
            except Exception as e:
                return f"[Errore lettura file: {e}]"
        except Exception as e:
            return f"[Errore: {e}]"
    
    def get_all_project_files(root_path):
        """Ottieni tutti i file del progetto da includere"""
        project_files = []
        
        def scan_directory(path, relative_path=""):
            try:
                for item in sorted(path.iterdir()):
                    if item.is_dir() and should_include_dir(item):
                        scan_directory(item, f"{relative_path}/{item.name}" if relative_path else item.name)
                    elif item.is_file() and should_include_file(item):
                        rel_path = f"{relative_path}/{item.name}" if relative_path else item.name
                        project_files.append((item, rel_path))
            except PermissionError:
                pass
        
        scan_directory(root_path)
        return project_files
    
    # Genera snapshot
    print("🔍 Creazione snapshot progetto...")
    
    snapshot_content = []
    
    # Header
    snapshot_content.append("# 📸 SNAPSHOT PROGETTO - SISTEMA CONTROLLO ACCESSI")
    snapshot_content.append("## Tessera Sanitaria - Snapshot Completo")
    snapshot_content.append("")
    snapshot_content.append(f"**Data snapshot**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    snapshot_content.append(f"**Directory progetto**: {project_root}")
    snapshot_content.append("")
    
    # Informazioni sistema
    snapshot_content.append("## 🖥️ INFORMAZIONI SISTEMA")
    snapshot_content.append("```")
    try:
        import platform
        snapshot_content.append(f"OS: {platform.system()} {platform.release()}")
        snapshot_content.append(f"Python: {platform.python_version()}")
        snapshot_content.append(f"Architecture: {platform.machine()}")
    except:
        snapshot_content.append("Informazioni sistema non disponibili")
    snapshot_content.append("```")
    snapshot_content.append("")
    
    # Struttura progetto
    snapshot_content.append("## 📁 STRUTTURA PROGETTO")
    snapshot_content.append("```")
    tree_lines = get_file_tree(project_root)
    snapshot_content.extend(tree_lines)
    snapshot_content.append("```")
    snapshot_content.append("")
    
    # Statistiche
    project_files = get_all_project_files(project_root)
    file_stats = {}
    for file_path, rel_path in project_files:
        ext = file_path.suffix.lower()
        file_stats[ext] = file_stats.get(ext, 0) + 1
    
    snapshot_content.append("## 📊 STATISTICHE PROGETTO")
    snapshot_content.append("```")
    snapshot_content.append(f"Totale file inclusi: {len(project_files)}")
    for ext, count in sorted(file_stats.items()):
        snapshot_content.append(f"File {ext}: {count}")
    snapshot_content.append("```")
    snapshot_content.append("")
    
    # Contenuto file
    snapshot_content.append("## 📄 CONTENUTO FILE PROGETTO")
    snapshot_content.append("")
    
    for file_path, rel_path in project_files:
        print(f"  Processando: {rel_path}")
        
        snapshot_content.append(f"### 📁 `{rel_path}`")
        snapshot_content.append("")
        
        # Informazioni file
        try:
            stat = file_path.stat()
            size = stat.st_size
            modified = datetime.fromtimestamp(stat.st_mtime).strftime('%Y-%m-%d %H:%M:%S')
            snapshot_content.append(f"**Dimensione**: {size} bytes | **Modificato**: {modified}")
        except:
            pass
        
        snapshot_content.append("")
        
        # Contenuto file
        content = read_file_content(file_path)
        
        # Determina linguaggio per syntax highlighting
        ext = file_path.suffix.lower()
        lang_map = {
            '.py': 'python',
            '.yml': 'yaml', '.yaml': 'yaml',
            '.json': 'json',
            '.md': 'markdown',
            '.ino': 'cpp',
            '.cpp': 'cpp', '.c': 'c', '.h': 'c',
            '.sql': 'sql',
            '.service': 'ini',
            '.conf': 'ini',
            '.txt': 'text'
        }
        language = lang_map.get(ext, 'text')
        
        snapshot_content.append(f"```{language}")
        snapshot_content.append(content)
        snapshot_content.append("```")
        snapshot_content.append("")
        snapshot_content.append("---")
        snapshot_content.append("")
    
    # Footer
    snapshot_content.append("## 🏁 FINE SNAPSHOT")
    snapshot_content.append("")
    snapshot_content.append("*Snapshot generato automaticamente dallo script `create_project_snapshot.py`*")
    snapshot_content.append("")
    snapshot_content.append("### 📋 COME USARE QUESTO SNAPSHOT:")
    snapshot_content.append("1. Questo file contiene tutto il codice funzionale del progetto")
    snapshot_content.append("2. Per ricreare il progetto, copiare i file nelle posizioni indicate")
    snapshot_content.append("3. Seguire la struttura directory mostrata sopra")
    snapshot_content.append("4. Installare dipendenze da `requirements.txt`")
    snapshot_content.append("5. Configurare permessi sistema come documentato")
    
    # Scrivi file
    try:
        with open(output_file, 'w', encoding='utf-8') as f:
            f.write('\n'.join(snapshot_content))
        
        print(f"✅ Snapshot creato: {output_file}")
        print(f"📊 File inclusi: {len(project_files)}")
        print(f"📄 Dimensione: {output_file.stat().st_size} bytes")
        
    except Exception as e:
        print(f"❌ Errore creazione snapshot: {e}")
        return False
    
    return True

if __name__ == "__main__":
    if not create_project_snapshot():
        sys.exit(1)
    print("🎯 Snapshot progetto completato!")