# File: /opt/access_control/src/api/hardware_tests.py
# Endpoint per test hardware

from flask import jsonify
import time
import threading
from datetime import datetime
import sys
sys.path.insert(0, '/opt/access_control/src')

# Stato globale per test
relay_test_state = {'status': 'idle'}
integrated_test_state = {'status': 'idle'}
hardware_test_results = {}
hardware_test_lock = threading.Lock()

# Import hardware con gestione errori
try:
    from hardware.card_reader import CardReader
    HARDWARE_READER_OK = True
except:
    HARDWARE_READER_OK = False

try:
    from hardware.usb_rly08_controller import USBRLY08Controller  
    HARDWARE_RELAY_OK = True
except:
    HARDWARE_RELAY_OK = False

def test_gate(get_db_connection):
    """Test cancello semplice"""
    try:
        controller = USBRLY08Controller()
        if controller.connect():
            # Apri cancello per 5 secondi
            controller._send_command(101)  # Relay 1 ON (Cancello)
            time.sleep(5)
            controller._send_command(111)  # Relay 1 OFF
            controller.disconnect()
            return jsonify({'success': True, 'message': 'Cancello aperto per test'})
        else:
            return jsonify({'success': False, 'error': 'Impossibile connettersi al controller'})
    except Exception as e:
        return jsonify({'success': False, 'error': f'Errore test cancello: {str(e)}'})

def test_relay():
    """Test USB-RLY08 con feedback real-time"""
    try:
        # Reset stato test globale
        global relay_test_state
        relay_test_state = {
            'status': 'running',
            'current_relay': 0,
            'log': [],
            'relay_states': {i: False for i in range(1, 9)}
        }
        
        def run_relay_test():
            global relay_test_state
            controller = USBRLY08Controller()
            
            relay_test_state['log'].append("=== TEST USB-RLY08 ===")
            relay_test_state['log'].append(f"Porta: {controller.port}")
            
            if not controller.connect():
                relay_test_state['log'].append("✗ Impossibile connettersi")
                relay_test_state['status'] = 'error'
                return
            
            relay_test_state['log'].append("✓ Connessione stabilita")
            
            # Test sequenziale di ogni relè
            for i in range(1, 9):
                relay_test_state['current_relay'] = i
                relay_test_state['log'].append(f"\nTest Relè {i}:")
                
                # Accendi relè - comando diretto
                command_on = 100 + i  # Comandi 101-108 per ON
                if controller._send_command(command_on):
                    relay_test_state['relay_states'][i] = True
                    relay_test_state['log'].append(f"  ✓ Relè {i} acceso")
                    time.sleep(0.5)
                    
                    # Spegni relè - comando diretto
                    command_off = 110 + i  # Comandi 111-118 per OFF
                    if controller._send_command(command_off):
                        relay_test_state['relay_states'][i] = False
                        relay_test_state['log'].append(f"  ✓ Relè {i} spento")
                
                time.sleep(0.5)
            
            # Test pattern finale - accendi tutti
            relay_test_state['log'].append("\nTest pattern finale...")
            controller._send_command(100)  # All ON
            for i in range(1, 9):
                relay_test_state['relay_states'][i] = True
            time.sleep(1)
            
            # Spegni tutti
            controller._send_command(110)  # All OFF
            for i in range(1, 9):
                relay_test_state['relay_states'][i] = False
            
            controller.disconnect()
            relay_test_state['log'].append("\n✓ Test completato!")
            relay_test_state['status'] = 'completed'
            relay_test_state['current_relay'] = 0
        
        # Avvia test in thread separato
        test_thread = threading.Thread(target=run_relay_test)
        test_thread.daemon = True
        test_thread.start()
        
        return jsonify({'success': True, 'message': 'Test avviato'})
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

def test_integrated(get_db_connection):
    """Test integrato: simulazione completa accesso con hardware configurato"""
    try:
        # Reset stato test globale
        global integrated_test_state
        integrated_test_state = {
            'status': 'running',
            'phase': 'init',
            'log': [],
            'cf': None,
            'authorized': None,
            'user_name': None,
            'timeout': 60  # 60 secondi di timeout
        }
        
        def run_integrated_test():
            global integrated_test_state
            controller = None
            
            try:
                # FASE 1: Leggi configurazione hardware
                integrated_test_state['phase'] = 'connecting'
                integrated_test_state['log'].append("🔄 AVVIO TEST INTEGRATO ACCESSO REALE")
                integrated_test_state['log'].append("━" * 50)
                integrated_test_state['log'].append("📡 Lettura configurazione hardware...")
                
                # Ottieni configurazione dal sistema
                from core.config import get_config_manager
                config_manager = get_config_manager()
                
                # Info lettore configurato
                card_cfg = config_manager.get_hardware_assignment("card_reader")
                device_key = card_cfg.get("device_key", "Non configurato")
                device_path = card_cfg.get("device_path", "Non configurato")
                integrated_test_state['log'].append(f"📟 Lettore configurato: {device_key}")
                integrated_test_state['log'].append(f"📂 Path dispositivo: {device_path}")
                
                # Info relay configurato
                relay_cfg = config_manager.get_hardware_assignment("relay_controller")
                relay_port = relay_cfg.get("device_key", "Non configurato")
                integrated_test_state['log'].append(f"🔌 Controller relè: {relay_port}")
                
                # Connetti USB-RLY08 per simulazione
                controller = USBRLY08Controller()
                if controller.connect():
                    integrated_test_state['log'].append("✅ USB-RLY08 connesso per simulazione")
                else:
                    integrated_test_state['log'].append("⚠️ USB-RLY08 non disponibile - simulazione senza hardware")
                    controller = None
                
                # Carica configurazione relè dal database
                relay_config = {}
                try:
                    conn = get_db_connection()
                    if conn:
                        cursor = conn.cursor()
                        cursor.execute("""
                            SELECT relay_number, description, valid_action, valid_duration, 
                                   invalid_action, invalid_duration 
                            FROM relay_config
                            ORDER BY relay_number
                        """)
                        for row in cursor.fetchall():
                            relay_num = row[0]
                            relay_config[relay_num] = {
                                'description': row[1],
                                'valid_action': row[2],
                                'valid_duration': row[3],
                                'invalid_action': row[4],
                                'invalid_duration': row[5]
                            }
                        conn.close()
                        integrated_test_state['log'].append(f"⚙️ Configurazione relè caricata: {len(relay_config)} relè configurati")
                except Exception as e:
                    integrated_test_state['log'].append(f"⚠️ Impossibile caricare config relè: {str(e)}")
                    # Configurazione di default
                    relay_config = {
                        1: {'description': 'Cancello', 'valid_action': 'PULSE', 'valid_duration': 3},
                        2: {'description': 'LED Rosso', 'valid_action': 'OFF', 'invalid_action': 'ON', 'invalid_duration': 2},
                        3: {'description': 'LED Verde', 'valid_action': 'ON', 'valid_duration': 2},
                        4: {'description': 'LED Giallo', 'valid_action': 'OFF', 'invalid_action': 'OFF'},
                        5: {'description': 'Buzzer', 'valid_action': 'PULSE', 'valid_duration': 0.2}
                    }
                
                integrated_test_state['log'].append("✅ Sistema principale resta operativo")
                integrated_test_state['log'].append("📊 Monitoraggio database attivo")
                time.sleep(0.5)
                
                # FASE 2: Attesa tessera tramite monitoraggio database
                integrated_test_state['phase'] = 'waiting_card'
                integrated_test_state['log'].append("\n💳 INSERIRE TESSERA SANITARIA NEL LETTORE...")
                integrated_test_state['log'].append("⏱️ Timeout: 60 secondi")
                integrated_test_state['log'].append("📊 Monitoraggio database per nuove letture...")
                
                # Ottieni ultimo ID dal database
                import sqlite3
                import sys
                sys.path.insert(0, '/opt/access_control/src')
                from core.db_config import CURRENT_DB_PATH
                db_path = CURRENT_DB_PATH
                last_access_id = 0
                try:
                    conn = sqlite3.connect(db_path)
                    cursor = conn.cursor()
                    cursor.execute("SELECT MAX(id) FROM log_accessi")
                    result = cursor.fetchone()
                    last_access_id = result[0] if result and result[0] else 0
                    conn.close()
                except:
                    pass
                
                # LED giallo lampeggiante (attesa) e monitoraggio database
                start_time = time.time()
                cf = None
                motivo_rifiuto = None
                nome_utente = None
                autorizzato = False
                
                while (time.time() - start_time) < integrated_test_state['timeout']:
                    # Lampeggio LED giallo se configurato e controller disponibile
                    if controller and 4 in relay_config:
                        # Trova relè configurato come LED Giallo (di solito relè 4)
                        for relay_num, config in relay_config.items():
                            if 'giallo' in config.get('description', '').lower():
                                try:
                                    controller._send_command(100 + relay_num)  # ON
                                    time.sleep(0.3)
                                    controller._send_command(110 + relay_num)  # OFF
                                    time.sleep(0.3)
                                except:
                                    pass
                                break
                    else:
                        time.sleep(0.6)  # Simulazione senza hardware
                    
                    # Monitora database per nuovi accessi
                    try:
                        conn = sqlite3.connect(db_path)
                        cursor = conn.cursor()
                        cursor.execute("""
                            SELECT id, codice_fiscale, autorizzato, motivo_rifiuto, nome_utente 
                            FROM log_accessi 
                            WHERE id > ? 
                            ORDER BY id DESC
                            LIMIT 1
                        """, (last_access_id,))
                        new_access = cursor.fetchone()
                        conn.close()
                        
                        if new_access:
                            cf = new_access[1]
                            autorizzato = bool(new_access[2])
                            motivo_rifiuto = new_access[3]
                            nome_utente = new_access[4]
                            break
                    except:
                        pass
                    
                    time.sleep(0.5)
                
                if not cf:
                    integrated_test_state['phase'] = 'timeout'
                    integrated_test_state['log'].append("\n⏱️ TIMEOUT - Nessuna tessera rilevata")
                    integrated_test_state['status'] = 'completed'
                    return
                
                # FASE 3: Tessera rilevata!
                integrated_test_state['phase'] = 'reading_card'
                integrated_test_state['log'].append(f"\n🎯 TESSERA RILEVATA!")
                integrated_test_state['log'].append(f"📄 Codice Fiscale: {cf}")
                integrated_test_state['cf'] = cf
                
                # Mostra nome utente se disponibile
                if nome_utente:
                    integrated_test_state['log'].append(f"👤 Utente: {nome_utente}")
                    integrated_test_state['user_name'] = nome_utente
                else:
                    integrated_test_state['user_name'] = "Sconosciuto"
                
                # Spegni LED giallo se controller disponibile
                if controller:
                    try:
                        # Spegni tutti i LED che potrebbero essere accesi
                        for relay_num in relay_config.keys():
                            controller._send_command(110 + relay_num)  # OFF
                    except:
                        pass
                
                # FASE 4: Mostra risultato autorizzazione (già letto dal database)
                integrated_test_state['log'].append("🔍 Risultato verifica autorizzazione:")
                time.sleep(0.5)
                
                integrated_test_state['authorized'] = autorizzato
                
                # FASE 5: Esegui azioni in base all'autorizzazione
                if autorizzato:
                    integrated_test_state['phase'] = 'access_granted'
                    integrated_test_state['log'].append(f"\n✅ ACCESSO AUTORIZZATO")
                    integrated_test_state['log'].append(f"👤 Utente: {integrated_test_state['user_name']}")
                    integrated_test_state['log'].append("🚪 Apertura cancello...")
                    
                    # Sequenza accesso autorizzato usando configurazione dinamica
                    if controller:
                        try:
                            # Applica configurazione per accesso VALIDO
                            for relay_num, config in relay_config.items():
                                action = config.get('valid_action', 'OFF')
                                duration = config.get('valid_duration', 0)
                                description = config.get('description', f'Relè {relay_num}')
                                
                                if action == 'ON':
                                    controller._send_command(100 + relay_num)  # ON
                                    integrated_test_state['log'].append(f"🟢 {description}: ON per {duration}s")
                                    if duration > 0:
                                        # Programma spegnimento dopo durata
                                        threading.Timer(duration, lambda r=relay_num: controller._send_command(110 + r)).start()
                                elif action == 'PULSE':
                                    controller._send_command(100 + relay_num)  # ON
                                    integrated_test_state['log'].append(f"⚡ {description}: PULSE {duration}s")
                                    time.sleep(duration)
                                    controller._send_command(110 + relay_num)  # OFF
                                elif action == 'OFF':
                                    controller._send_command(110 + relay_num)  # OFF
                            
                            # Attendi per simulazione completa
                            max_duration = max([cfg.get('valid_duration', 0) for cfg in relay_config.values()])
                            if max_duration > 0:
                                integrated_test_state['log'].append(f"⏱️ Attesa {max_duration} secondi...")
                                time.sleep(max_duration)
                            
                            # Spegni tutti i relè alla fine
                            for relay_num in relay_config.keys():
                                controller._send_command(110 + relay_num)  # OFF
                            
                        except Exception as e:
                            integrated_test_state['log'].append(f"⚠️ Errore simulazione: {str(e)}")
                    else:
                        integrated_test_state['log'].append("✅ Simulazione apertura cancello (8 secondi)")
                        time.sleep(3)  # Simulazione ridotta
                        integrated_test_state['log'].append("🔒 Simulazione chiusura cancello")
                    
                else:
                    integrated_test_state['phase'] = 'access_denied'
                    integrated_test_state['log'].append(f"\n❌ ACCESSO NEGATO")
                    integrated_test_state['log'].append(f"👤 Utente: {integrated_test_state['user_name']}")
                    
                    # Mostra motivazione del rifiuto
                    if motivo_rifiuto:
                        integrated_test_state['log'].append(f"📝 Motivo: {motivo_rifiuto}")
                    elif integrated_test_state['user_name'] == "Sconosciuto":
                        integrated_test_state['log'].append("🚫 Tessera non registrata nel sistema")
                    else:
                        integrated_test_state['log'].append("🚫 Utente non autorizzato")
                    
                    # Sequenza accesso negato usando configurazione dinamica
                    if controller:
                        try:
                            # Applica configurazione per accesso NEGATO/INVALIDO
                            for relay_num, config in relay_config.items():
                                action = config.get('invalid_action', 'OFF')
                                duration = config.get('invalid_duration', 0)
                                description = config.get('description', f'Relè {relay_num}')
                                
                                if action == 'ON':
                                    controller._send_command(100 + relay_num)  # ON
                                    integrated_test_state['log'].append(f"🔴 {description}: ON per {duration}s")
                                    if duration > 0:
                                        # Programma spegnimento dopo durata
                                        threading.Timer(duration, lambda r=relay_num: controller._send_command(110 + r)).start()
                                elif action == 'PULSE':
                                    # Per buzzer, fai 3 beep
                                    if 'buzzer' in description.lower():
                                        integrated_test_state['log'].append(f"🔊 {description}: 3 beep")
                                        for i in range(3):
                                            controller._send_command(100 + relay_num)  # ON
                                            time.sleep(0.1)
                                            controller._send_command(110 + relay_num)  # OFF
                                            time.sleep(0.2)
                                    else:
                                        controller._send_command(100 + relay_num)  # ON
                                        integrated_test_state['log'].append(f"⚡ {description}: PULSE {duration}s")
                                        time.sleep(duration)
                                        controller._send_command(110 + relay_num)  # OFF
                                elif action == 'OFF':
                                    controller._send_command(110 + relay_num)  # OFF
                            
                            # Attendi per simulazione completa
                            max_duration = max([cfg.get('invalid_duration', 0) for cfg in relay_config.values()])
                            if max_duration > 0:
                                integrated_test_state['log'].append(f"⏱️ Attesa {max_duration} secondi...")
                                time.sleep(max_duration)
                            
                            # Spegni tutti i relè alla fine
                            for relay_num in relay_config.keys():
                                controller._send_command(110 + relay_num)  # OFF
                                
                        except Exception as e:
                            integrated_test_state['log'].append(f"⚠️ Errore simulazione: {str(e)}")
                    else:
                        integrated_test_state['log'].append("🔴 Simulazione LED rosso e buzzer negato")
                        time.sleep(2)
                
                # FASE 6: Log risultato test
                integrated_test_state['phase'] = 'logging'
                integrated_test_state['log'].append("\n📝 Test completato - accesso già registrato dal sistema principale")
                
                # FASE 7: Completamento
                integrated_test_state['phase'] = 'completed'
                integrated_test_state['log'].append("\n━" * 50)
                integrated_test_state['log'].append("✅ TEST COMPLETATO")
                integrated_test_state['log'].append("💡 Puoi rimuovere la tessera")
                
            except Exception as e:
                integrated_test_state['log'].append(f"\n❌ ERRORE: {str(e)}")
                integrated_test_state['status'] = 'error'
                integrated_test_state['phase'] = 'error'
            finally:
                # Cleanup
                if controller:
                    try:
                        # Spegni tutti i LED
                        controller._send_command(110)  # All OFF
                        controller.disconnect()
                    except:
                        pass
                integrated_test_state['status'] = 'completed'
        
        # Avvia test in thread separato
        test_thread = threading.Thread(target=run_integrated_test)
        test_thread.daemon = True
        test_thread.start()
        
        return jsonify({'success': True, 'message': 'Test integrato avviato - inserire tessera'})
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

def test_reader():
    """Test del lettore CRT-285 - Verifica stato e funzionamento SENZA creare nuove istanze"""
    
    try:
        import subprocess
        import os
        
        results = {
            'tests': [],
            'success': False,
            'reader_info': {}
        }
        
        # 1. Verifica libreria CRT-285 (cerca nei path corretti)
        lib_paths = [
            '/opt/access_control/src/drivers/288K/linux_crt_288x/drivers/x64/crt_288x_ur.so',
            '/opt/access_control/src/drivers/288K/288K-linux-sample/288K/crt_288x_ur.so'
        ]
        lib_found = False
        for lib_path in lib_paths:
            if os.path.exists(lib_path):
                results['tests'].append(f'✅ Libreria CRT-285 presente: {os.path.basename(lib_path)}')
                lib_found = True
                break
        
        if not lib_found:
            results['tests'].append('❌ Libreria CRT-285 NON trovata')
            return jsonify({'success': False, 'message': 'Libreria CRT-285 mancante', 'details': results['tests']})
        
        # 2. Verifica dispositivo USB
        lsusb_result = subprocess.run(['lsusb'], capture_output=True, text=True, timeout=2)
        if '23d8:0285' in lsusb_result.stdout:
            results['tests'].append('✅ CRT-285 rilevato via USB (23d8:0285)')
        else:
            results['tests'].append('❌ CRT-285 NON rilevato via USB')
            return jsonify({'success': False, 'message': 'Lettore non collegato', 'details': results['tests']})
        
        # 3. Il lettore è integrato in web_api.py, NON c'è un main.py separato
        # Verifica che il servizio web sia attivo
        ps_result = subprocess.run(['pgrep', '-f', 'web_api.py'], capture_output=True, timeout=2)
        if ps_result.returncode == 0:
            results['tests'].append('✅ Servizio attivo con lettore integrato')
        else:
            results['tests'].append('⚠️ Servizio web_api.py non rilevato')
        
        # 4. Verifica che il database sia accessibile (il lettore scrive qui)
        try:
            import sqlite3
            conn = sqlite3.connect('/opt/access_control/data/access.db')
            cursor = conn.cursor()
            cursor.execute("SELECT COUNT(*) FROM log_accessi")
            total_reads = cursor.fetchone()[0]
            conn.close()
            results['tests'].append(f'✅ Database accessibile ({total_reads} accessi totali)')
        except Exception as e:
            results['tests'].append(f'⚠️ Database: {str(e)}')
        
        # 5. Info aggiuntive sul lettore (da quello che sappiamo del sistema)
        results['reader_info'] = {
            'tipo': 'CRT-285',
            'interfaccia': 'USB HID',
            'vendor_id': '23d8',
            'product_id': '0285',
            'modalità': 'Lettura continua tessere sanitarie',
            'output': 'Codice fiscale in database'
        }
        
        # Risultato finale
        all_ok = all('✅' in test for test in results['tests'])
        
        if all_ok:
            message = '✅ LETTORE CRT-285 OPERATIVO E PRONTO'
        else:
            message = '⚠️ Lettore CRT-285 con problemi'
        
        return jsonify({
            'success': all_ok,
            'message': message,
            'details': results['tests'],
            'info': results['reader_info']
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': f'Errore test lettore: {str(e)}'
        })

def OLD_test_reader_monitoring():
    """Codice vecchio - non usato"""
    pass

# Fine del file - tutto il codice vecchio sotto è stato rimosso

def get_integrated_test_status():
    """Restituisce stato test integrato"""
    global integrated_test_state
    return jsonify(integrated_test_state)

def get_hardware_status(test_id=None):
    """Restituisce stato test hardware"""
    with hardware_test_lock:
        if test_id and test_id in hardware_test_results:
            return jsonify({'success': True, 'test': hardware_test_results[test_id]})
        return jsonify({'success': True, 'tests': hardware_test_results})
