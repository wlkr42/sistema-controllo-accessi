# File: /opt/access_control/src/api/modules/configurazione_accessi.py

import os
import sqlite3
from datetime import datetime, time
from flask import Blueprint, jsonify, request
from ..utils import require_auth, require_permission, get_db_connection

configurazione_accessi_bp = Blueprint('configurazione_accessi', __name__)

def init_db():
    """Inizializza tabelle per configurazione accessi"""
    conn = get_db_connection()
    if not conn:
        return False
    
    try:
        cursor = conn.cursor()
        
        # Tabella orari settimanali
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS orari_accesso (
                giorno TEXT PRIMARY KEY,
                aperto BOOLEAN DEFAULT true,
                mattina_inizio TIME,
                mattina_fine TIME,
                pomeriggio_inizio TIME,
                pomeriggio_fine TIME,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_by TEXT
            )
        ''')
        
        # Tabella limiti accessi
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS limiti_accesso (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                max_ingressi_mensili INTEGER DEFAULT 3,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_by TEXT
            )
        ''')
        
        # Tabella log forzature
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS log_forzature (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                tipo TEXT NOT NULL,
                utente TEXT NOT NULL,
                timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                dettagli TEXT
            )
        ''')
        
        # Inserisci orari default se non esistono
        giorni = ['Domenica', 'Lunedi', 'Martedi', 'Mercoledi', 'Giovedi', 'Venerdi', 'Sabato']
        for giorno in giorni:
            cursor.execute('''
                INSERT OR IGNORE INTO orari_accesso 
                (giorno, aperto, mattina_inizio, mattina_fine, pomeriggio_inizio, pomeriggio_fine)
                VALUES (?, ?, ?, ?, ?, ?)
            ''', (giorno, True, '09:00', '12:00', '15:00', '17:00'))
        
        # Inserisci limite default se non esiste
        cursor.execute('INSERT OR IGNORE INTO limiti_accesso (max_ingressi_mensili) VALUES (?)', (3,))
        
        conn.commit()
        return True
        
    except Exception as e:
        print(f"Errore inizializzazione DB: {e}")
        return False
    finally:
        conn.close()

# Inizializza DB
init_db()

@configurazione_accessi_bp.route('/api/configurazione/orari', methods=['GET'])
@require_auth()
def get_orari():
    """Ottiene configurazione orari"""
    conn = get_db_connection()
    if not conn:
        return jsonify({'success': False, 'error': 'Database non disponibile'}), 500
    
    try:
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM orari_accesso ORDER BY CASE giorno ' + 
                      "WHEN 'Domenica' THEN 0 " +
                      "WHEN 'Lunedi' THEN 1 " +
                      "WHEN 'Martedi' THEN 2 " +
                      "WHEN 'Mercoledi' THEN 3 " +
                      "WHEN 'Giovedi' THEN 4 " +
                      "WHEN 'Venerdi' THEN 5 " +
                      "WHEN 'Sabato' THEN 6 END")
        
        orari = []
        for row in cursor.fetchall():
            orari.append({
                'giorno': row[0],
                'aperto': bool(row[1]),
                'mattina_inizio': str(row[2]),
                'mattina_fine': str(row[3]),
                'pomeriggio_inizio': str(row[4]),
                'pomeriggio_fine': str(row[5])
            })
        
        return jsonify({'success': True, 'orari': orari})
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500
    finally:
        conn.close()

@configurazione_accessi_bp.route('/api/configurazione/orari', methods=['POST'])
@require_auth()
@require_permission('all')
def save_orari():
    """Salva configurazione orari"""
    data = request.get_json()
    if not data or 'orari' not in data:
        return jsonify({'success': False, 'error': 'Dati mancanti'}), 400
    
    conn = get_db_connection()
    if not conn:
        return jsonify({'success': False, 'error': 'Database non disponibile'}), 500
    
    try:
        cursor = conn.cursor()
        for orario in data['orari']:
            cursor.execute('''
                UPDATE orari_accesso 
                SET aperto = ?,
                    mattina_inizio = ?,
                    mattina_fine = ?,
                    pomeriggio_inizio = ?,
                    pomeriggio_fine = ?,
                    updated_at = CURRENT_TIMESTAMP,
                    updated_by = ?
                WHERE giorno = ?
            ''', (
                orario['aperto'],
                orario['mattina_inizio'],
                orario['mattina_fine'], 
                orario['pomeriggio_inizio'],
                orario['pomeriggio_fine'],
                request.session.get('username'),
                orario['giorno']
            ))
        
        conn.commit()
        return jsonify({'success': True, 'message': 'Orari salvati'})
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500
    finally:
        conn.close()

@configurazione_accessi_bp.route('/api/configurazione/limiti', methods=['GET'])
@require_auth()
def get_limiti():
    """Ottiene limiti accessi"""
    conn = get_db_connection()
    if not conn:
        return jsonify({'success': False, 'error': 'Database non disponibile'}), 500
    
    try:
        cursor = conn.cursor()
        cursor.execute('SELECT max_ingressi_mensili FROM limiti_accesso ORDER BY id DESC LIMIT 1')
        row = cursor.fetchone()
        
        return jsonify({
            'success': True,
            'max_ingressi_mensili': row[0] if row else 3
        })
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500
    finally:
        conn.close()

@configurazione_accessi_bp.route('/api/configurazione/limiti', methods=['POST'])
@require_auth()
@require_permission('all')
def save_limiti():
    """Salva limiti accessi"""
    data = request.get_json()
    if not data or 'max_ingressi_mensili' not in data:
        return jsonify({'success': False, 'error': 'Dati mancanti'}), 400
    
    conn = get_db_connection()
    if not conn:
        return jsonify({'success': False, 'error': 'Database non disponibile'}), 500
    
    try:
        cursor = conn.cursor()
        cursor.execute('''
            INSERT INTO limiti_accesso (max_ingressi_mensili, updated_by)
            VALUES (?, ?)
        ''', (data['max_ingressi_mensili'], request.session.get('username')))
        
        conn.commit()
        return jsonify({'success': True, 'message': 'Limite salvato'})
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500
    finally:
        conn.close()

def verifica_orario() -> bool:
    """Verifica se l'orario attuale è valido per l'accesso"""
    conn = get_db_connection()
    if not conn:
        return False
    
    try:
        cursor = conn.cursor()
        
        # Ottieni giorno della settimana (0 = Domenica)
        giorni = ['Domenica', 'Lunedi', 'Martedi', 'Mercoledi', 'Giovedi', 'Venerdi', 'Sabato']
        giorno_attuale = giorni[datetime.now().weekday()]
        
        # Ottieni orari per il giorno
        cursor.execute('SELECT * FROM orari_accesso WHERE giorno = ?', (giorno_attuale,))
        orario = cursor.fetchone()
        
        if not orario or not orario[1]:  # not aperto
            return False
        
        ora_attuale = datetime.now().time()
        
        # Converti stringhe in oggetti time
        mattina_inizio = datetime.strptime(orario[2], '%H:%M').time()
        mattina_fine = datetime.strptime(orario[3], '%H:%M').time()
        pomeriggio_inizio = datetime.strptime(orario[4], '%H:%M').time()
        pomeriggio_fine = datetime.strptime(orario[5], '%H:%M').time()
        
        # Verifica se ora attuale è in uno dei range
        in_mattina = mattina_inizio <= ora_attuale <= mattina_fine
        in_pomeriggio = pomeriggio_inizio <= ora_attuale <= pomeriggio_fine
        
        return in_mattina or in_pomeriggio
        
    except Exception as e:
        print(f"Errore verifica orario: {e}")
        return False
    finally:
        conn.close()

def verifica_limite_mensile(codice_fiscale: str) -> bool:
    """Verifica se l'utente ha superato il limite mensile di accessi"""
    conn = get_db_connection()
    if not conn:
        return False
    
    try:
        cursor = conn.cursor()
        
        # Ottieni limite configurato
        cursor.execute('SELECT max_ingressi_mensili FROM limiti_accesso ORDER BY id DESC LIMIT 1')
        row = cursor.fetchone()
        limite = row[0] if row else 3
        
        # Conta accessi del mese corrente
        cursor.execute('''
            SELECT COUNT(*) FROM log_accessi 
            WHERE codice_fiscale = ? 
            AND strftime('%Y-%m', timestamp) = strftime('%Y-%m', 'now')
            AND autorizzato = 1
        ''', (codice_fiscale,))
        
        accessi = cursor.fetchone()[0]
        return accessi < limite
        
    except Exception as e:
        print(f"Errore verifica limite mensile: {e}")
        return False
    finally:
        conn.close()

def log_forzatura(tipo: str, utente: str, dettagli: str = None):
    """Registra una forzatura nel log"""
    conn = get_db_connection()
    if not conn:
        return
    
    try:
        cursor = conn.cursor()
        cursor.execute('''
            INSERT INTO log_forzature (tipo, utente, dettagli)
            VALUES (?, ?, ?)
        ''', (tipo, utente, dettagli))
        conn.commit()
    except Exception as e:
        print(f"Errore log forzatura: {e}")
    finally:
        conn.close()

@configurazione_accessi_bp.route('/api/configurazione/test/reset-contatore', methods=['POST'])
@require_auth()
@require_permission('all')
def reset_contatore():
    """Reset manuale contatore accessi mensili per un utente"""
    data = request.get_json()
    if not data or 'codice_fiscale' not in data:
        return jsonify({'success': False, 'error': 'Codice fiscale mancante'}), 400
    
    conn = get_db_connection()
    if not conn:
        return jsonify({'success': False, 'error': 'Database non disponibile'}), 500
    
    try:
        cursor = conn.cursor()
        
        # Elimina accessi del mese corrente
        cursor.execute('''
            DELETE FROM log_accessi 
            WHERE codice_fiscale = ? 
            AND strftime('%Y-%m', timestamp) = strftime('%Y-%m', 'now')
        ''', (data['codice_fiscale'],))
        
        # Log forzatura
        log_forzatura(
            'RESET_CONTATORE',
            request.session.get('username'),
            f"Reset contatore per CF: {data['codice_fiscale']}"
        )
        
        conn.commit()
        return jsonify({'success': True, 'message': 'Contatore resettato'})
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500
    finally:
        conn.close()

@configurazione_accessi_bp.route('/api/configurazione/test/apri-cancello', methods=['POST'])
@require_auth()
@require_permission('all')
def apri_cancello_forzato():
    """Apertura forzata cancello fuori orario"""
    from ..hardware.usb_rly08_controller import USBRLY08Controller
    
    if verifica_orario():
        return jsonify({'success': False, 'error': 'Cancello già apribile in orario normale'}), 400
    
    try:
        controller = USBRLY08Controller()
        if not controller.connect():
            return jsonify({'success': False, 'error': 'Impossibile connettersi al controller'}), 500
        
        # Apri cancello
        controller.open_gate(8.0)  # 8 secondi
        
        # Log forzatura
        log_forzatura(
            'APERTURA_FORZATA',
            request.session.get('username'),
            'Apertura cancello fuori orario'
        )
        
        return jsonify({'success': True, 'message': 'Cancello aperto'})
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500
    finally:
        if 'controller' in locals():
            controller.disconnect()

@configurazione_accessi_bp.route('/api/configurazione/log-forzature', methods=['GET'])
@require_auth()
@require_permission('all')
def get_log_forzature():
    """Ottiene log delle forzature"""
    conn = get_db_connection()
    if not conn:
        return jsonify({'success': False, 'error': 'Database non disponibile'}), 500
    
    try:
        cursor = conn.cursor()
        cursor.execute('''
            SELECT tipo, utente, timestamp, dettagli
            FROM log_forzature
            ORDER BY timestamp DESC
            LIMIT 100
        ''')
        
        log = []
        for row in cursor.fetchall():
            log.append({
                'tipo': row[0],
                'utente': row[1],
                'timestamp': row[2],
                'dettagli': row[3]
            })
        
        return jsonify({'success': True, 'log': log})
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500
    finally:
        conn.close()
