// Funzioni di utilità
function formatDateTime(timestamp) {
    const date = new Date(timestamp);
    return date.toLocaleString('it-IT', {
        year: 'numeric',
        month: '2-digit',
        day: '2-digit',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit'
    });
}

// Aggiorna stato sistema
function aggiornaStatoSistema() {
    // Aggiorna orario
    const now = new Date();
    document.getElementById('orario-attuale').textContent = now.toLocaleTimeString('it-IT');
    
    // Verifica stato cancello
    fetch('/api/configurazione/orari')
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                const giorni = ['Domenica', 'Lunedi', 'Martedi', 'Mercoledi', 'Giovedi', 'Venerdi', 'Sabato'];
                const giorno = giorni[now.getDay()];
                const orario = data.orari.find(o => o.giorno === giorno);
                
                if (orario && orario.aperto) {
                    const ora = now.getHours().toString().padStart(2, '0') + ':' + 
                              now.getMinutes().toString().padStart(2, '0');
                    
                    const inMattina = ora >= orario.mattina_inizio && ora <= orario.mattina_fine;
                    const inPomeriggio = ora >= orario.pomeriggio_inizio && ora <= orario.pomeriggio_fine;
                    
                    if (inMattina || inPomeriggio) {
                        document.getElementById('stato-cancello').textContent = 'APRIBILE';
                        document.getElementById('stato-cancello').classList.remove('text-danger');
                        document.getElementById('stato-cancello').classList.add('text-success');
                    } else {
                        document.getElementById('stato-cancello').textContent = 'CHIUSO';
                        document.getElementById('stato-cancello').classList.remove('text-success');
                        document.getElementById('stato-cancello').classList.add('text-danger');
                    }
                } else {
                    document.getElementById('stato-cancello').textContent = 'CHIUSO';
                    document.getElementById('stato-cancello').classList.remove('text-success');
                    document.getElementById('stato-cancello').classList.add('text-danger');
                }
            }
        });
    
    // Conta utenti disabilitati
    const primoDelMese = new Date(now.getFullYear(), now.getMonth(), 1);
    fetch('/api/configurazione/limiti')
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                const limite = data.max_ingressi_mensili;
                fetch('/api/stats')
                    .then(response => response.json())
                    .then(stats => {
                        if (stats.success) {
                            const utentiDisabilitati = stats.utenti_oltre_limite || 0;
                            document.getElementById('utenti-disabilitati').textContent = utentiDisabilitati;
                        }
                    });
            }
        });
}

// Reset contatore accessi
function resetContatore() {
    const cf = document.getElementById('reset-cf').value.toUpperCase();
    if (!cf) {
        alert('Inserire un codice fiscale');
        return;
    }
    
    fetch('/api/configurazione/test/reset-contatore', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ codice_fiscale: cf })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            alert('Contatore resettato con successo');
            document.getElementById('reset-cf').value = '';
            aggiornaLogForzature();
            aggiornaStatoSistema();
        } else {
            alert('Errore: ' + data.error);
        }
    })
    .catch(error => {
        alert('Errore di rete: ' + error);
    });
}

// Apertura forzata cancello
function apriCancello() {
    if (!confirm('Sei sicuro di voler aprire il cancello forzatamente?\nQuesta operazione verrà registrata nel log.')) {
        return;
    }
    
    fetch('/api/configurazione/test/apri-cancello', {
        method: 'POST'
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            alert('Cancello aperto con successo');
            aggiornaLogForzature();
        } else {
            alert('Errore: ' + data.error);
        }
    })
    .catch(error => {
        alert('Errore di rete: ' + error);
    });
}

// Aggiorna log forzature
function aggiornaLogForzature() {
    fetch('/api/configurazione/log-forzature')
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                const tbody = document.getElementById('log-forzature');
                tbody.innerHTML = '';
                
                if (data.log.length === 0) {
                    tbody.innerHTML = `
                        <tr>
                            <td colspan="4" class="text-center">
                                Nessuna forzatura registrata
                            </td>
                        </tr>
                    `;
                    return;
                }
                
                data.log.forEach(entry => {
                    const row = document.createElement('tr');
                    row.innerHTML = `
                        <td>${formatDateTime(entry.timestamp)}</td>
                        <td>
                            <span class="badge ${entry.tipo === 'APERTURA_FORZATA' ? 'bg-danger' : 'bg-warning'}">
                                ${entry.tipo}
                            </span>
                        </td>
                        <td>${entry.utente}</td>
                        <td>${entry.dettagli || '-'}</td>
                    `;
                    tbody.appendChild(row);
                });
            }
        });
}

// Inizializzazione
document.addEventListener('DOMContentLoaded', () => {
    // Aggiorna stato sistema ogni secondo
    aggiornaStatoSistema();
    setInterval(aggiornaStatoSistema, 1000);
    
    // Carica log iniziale
    aggiornaLogForzature();
    
    // Aggiorna log ogni 30 secondi
    setInterval(aggiornaLogForzature, 30000);
});
