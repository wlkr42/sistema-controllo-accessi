import pytest
import json
from flask import session
from src.api.web_api import app

# File: src/api/test_web_api.py



@pytest.fixture
def client():
    app.config['TESTING'] = True
    with app.test_client() as client:
        yield client

def login(client, username, password):
    return client.post('/login', data={
        'username': username,
        'password': password
    }, follow_redirects=True)

def test_login_success(client):
    rv = login(client, 'admin', 'admin123')
    assert b'Dashboard' in rv.data or rv.status_code == 200

def test_login_failure(client):
    rv = login(client, 'admin', 'wrongpass')
    assert b'Credenziali non valide' in rv.data

def test_api_users_count_requires_auth(client):
    rv = client.get('/api/users/count')
    assert rv.status_code == 302  # Redirect to login

def test_api_users_count_after_login(client):
    login(client, 'admin', 'admin123')
    rv = client.get('/api/users/count')
    assert rv.status_code == 200
    data = rv.get_json()
    assert 'count' in data or 'error' in data

def test_api_stats(client):
    login(client, 'admin', 'admin123')
    rv = client.get('/api/stats')
    assert rv.status_code == 200
    data = rv.get_json()
    assert 'accessi_oggi' in data or 'error' in data

def test_api_recent_accesses(client):
    login(client, 'admin', 'admin123')
    rv = client.get('/api/recent-accesses')
    assert rv.status_code == 200
    data = rv.get_json()
    assert 'accesses' in data or 'error' in data

def test_api_system_config_save_and_reset(client):
    login(client, 'admin', 'admin123')
    # Save config
    payload = {
        "sistema": {"nome_installazione": "Test"},
        "hardware": {"lettore_porta": "/dev/null"}
    }
    rv = client.post('/api/system/config/save', data=json.dumps(payload), content_type='application/json')
    assert rv.status_code == 200
    data = rv.get_json()
    assert data['success'] is True

    # Reset config
    rv = client.post('/api/system/config/reset')
    assert rv.status_code == 200
    data = rv.get_json()
    assert data['success'] is True

def test_api_save_reader_config(client, monkeypatch):
    login(client, 'admin', 'admin123')
    # Mock config_manager methods
    monkeypatch.setattr('src.api.web_api.config_manager.set_config_value', lambda *a, **kw: True)
    monkeypatch.setattr('src.api.web_api.config_manager.save_configuration', lambda: True)
    payload = {
        "tipo": "HID Omnikey 5427CK",
        "porta": "/dev/ttyACM0",
        "timeout": 30,
        "retry_tentativi": 3
    }
    rv = client.post('/api/devices/config/reader', data=json.dumps(payload), content_type='application/json')
    assert rv.status_code == 200
    data = rv.get_json()
    assert data['success'] is True

def test_api_save_relay_config(client, monkeypatch):
    login(client, 'admin', 'admin123')
    # Mock config_manager methods
    monkeypatch.setattr('src.api.web_api.config_manager.set_nested_value', lambda *a, **kw: True)
    monkeypatch.setattr('src.api.web_api.config_manager.save_to_database', lambda: True)
    monkeypatch.setattr('src.api.web_api.config_manager.save_configuration', lambda: True)
    payload = {
        "porta": "/dev/ttyUSB0",
        "baud_rate": 19200,
        "modulo_id": 8
    }
    rv = client.post('/api/devices/config/relay', data=json.dumps(payload), content_type='application/json')
    assert rv.status_code == 200
    data = rv.get_json()
    assert data['success'] is True