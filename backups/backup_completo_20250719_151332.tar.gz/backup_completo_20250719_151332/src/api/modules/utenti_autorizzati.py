# File: /opt/access_control/src/api/modules/utenti_autorizzati.py
from flask import Blueprint, render_template_string, request, jsonify, session
from functools import wraps
import sqlite3
import os
from datetime import datetime

# Import auth per i decoratori
from ..utils import require_auth, require_permission

utenti_autorizzati_bp = Blueprint('utenti_autorizzati', __name__)

# Database path
DB_PATH = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), 'access.db')

def get_db_connection():
    """Connessione al database"""
    try:
        conn = sqlite3.connect(DB_PATH)
        conn.row_factory = sqlite3.Row
        return conn
    except Exception as e:
        print(f"Errore connessione DB: {e}")
        return None

@utenti_autorizzati_bp.route('/utenti-autorizzati')
@require_auth()
def utenti_autorizzati_page():
    """Pagina gestione utenti autorizzati"""
    with open(os.path.join(os.path.dirname(os.path.dirname(__file__)), 
              'templates', 'utenti_autorizzati.html'), 'r') as f:
        template = f.read()
    return render_template_string(template, session=session)

@utenti_autorizzati_bp.route('/api/utenti-autorizzati/list')
@require_auth()
def api_list_utenti_autorizzati():
    """Lista utenti autorizzati con filtro"""
    search = request.args.get('search', '').strip().upper()
    
    conn = get_db_connection()
    if not conn:
        return jsonify({'success': False, 'error': 'Database non disponibile'}), 500
    
    try:
        cursor = conn.cursor()
        
        # Query base
        query = """
            SELECT codice_fiscale, nome, cognome, email, telefono,
                   reparto, ruolo, data_inserimento, data_scadenza,
                   attivo, note
            FROM utenti_autorizzati
            WHERE 1=1
        """
        params = []
        
        # Aggiungi filtro di ricerca se presente
        if search:
            query += """
                AND (
                    UPPER(codice_fiscale) LIKE ? OR
                    UPPER(nome) LIKE ? OR
                    UPPER(cognome) LIKE ?
                )
            """
            search_param = f"%{search}%"
            params.extend([search_param, search_param, search_param])
        
        # Ordina per cognome, nome
        query += " ORDER BY cognome, nome"
        
        cursor.execute(query, params)
        results = cursor.fetchall()
        
        utenti = []
        for row in results:
            utenti.append({
                'codice_fiscale': row['codice_fiscale'],
                'nome': row['nome'],
                'cognome': row['cognome'],
                'email': row['email'],
                'telefono': row['telefono'],
                'reparto': row['reparto'],
                'ruolo': row['ruolo'],
                'data_inserimento': row['data_inserimento'],
                'data_scadenza': row['data_scadenza'],
                'attivo': bool(row['attivo']),
                'note': row['note']
            })
        
        return jsonify({
            'success': True,
            'utenti': utenti,
            'total': len(utenti)
        })
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500
    finally:
        conn.close()

@utenti_autorizzati_bp.route('/api/utenti-autorizzati/toggle-active', methods=['POST'])
@require_auth()
@require_permission('all')
def api_toggle_active():
    """Attiva/disattiva utente autorizzato"""
    data = request.get_json()
    codice_fiscale = data.get('codice_fiscale', '').strip()
    
    if not codice_fiscale:
        return jsonify({'success': False, 'error': 'Codice fiscale mancante'}), 400
    
    conn = get_db_connection()
    if not conn:
        return jsonify({'success': False, 'error': 'Database non disponibile'}), 500
    
    try:
        cursor = conn.cursor()
        
        # Ottieni stato attuale
        cursor.execute("""
            SELECT attivo 
            FROM utenti_autorizzati 
            WHERE codice_fiscale = ?
        """, (codice_fiscale,))
        
        result = cursor.fetchone()
        if not result:
            return jsonify({'success': False, 'error': 'Utente non trovato'}), 404
        
        # Inverte lo stato
        new_state = not bool(result['attivo'])
        
        # Aggiorna
        cursor.execute("""
            UPDATE utenti_autorizzati 
            SET attivo = ?,
                data_aggiornamento = CURRENT_TIMESTAMP,
                modificato_da = ?
            WHERE codice_fiscale = ?
        """, (int(new_state), session.get('username'), codice_fiscale))
        
        conn.commit()
        
        status = "attivato" if new_state else "disattivato"
        return jsonify({
            'success': True,
            'message': f'Utente {status}',
            'new_state': new_state
        })
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500
    finally:
        conn.close()

@utenti_autorizzati_bp.route('/api/utenti-autorizzati/stats')
@require_auth()
def api_get_stats():
    """Statistiche utenti autorizzati"""
    conn = get_db_connection()
    if not conn:
        return jsonify({'success': False, 'error': 'Database non disponibile'}), 500
    
    try:
        cursor = conn.cursor()
        
        # Totale utenti
        cursor.execute("SELECT COUNT(*) as total FROM utenti_autorizzati")
        total = cursor.fetchone()['total']
        
        # Utenti attivi
        cursor.execute("SELECT COUNT(*) as active FROM utenti_autorizzati WHERE attivo = 1")
        active = cursor.fetchone()['active']
        
        
        # Ultimi inseriti
        cursor.execute("""
            SELECT COUNT(*) as recent
            FROM utenti_autorizzati
            WHERE data_inserimento >= date('now', '-30 days')
        """)
        recent = cursor.fetchone()['recent']
        
        return jsonify({
            'success': True,
            'stats': {
                'totale': total,
                'attivi': active,
                'nuovi_30gg': recent
            }
        })
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500
    finally:
        conn.close()
