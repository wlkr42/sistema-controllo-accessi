document.addEventListener('DOMContentLoaded', function() {
    // Carica menu utente
    loadUserMenu();

    // Event listener per click fuori dal menu
    document.addEventListener('click', function(e) {
        const menu = document.querySelector('.user-menu-dropdown');
        const trigger = document.querySelector('.user-menu-trigger');
        const overlay = document.querySelector('.user-menu-overlay');
        
        if (menu && trigger && overlay) {
            if (!menu.contains(e.target) && !trigger.contains(e.target)) {
                menu.classList.remove('active');
                overlay.classList.remove('active');
            }
        }
    });
});

function loadUserMenu() {
    fetch('/api/user-menu-html')
        .then(response => response.text())
        .then(html => {
            const menuContainer = document.getElementById('user-menu-container');
            if (menuContainer) {
                menuContainer.innerHTML = html;
                initializeUserMenu();
            }
        })
        .catch(error => console.error('Errore caricamento menu:', error));
}

function initializeUserMenu() {
    const trigger = document.querySelector('.user-menu-trigger');
    const menu = document.querySelector('.user-menu-dropdown');
    const overlay = document.querySelector('.user-menu-overlay');
    
    if (trigger && menu && overlay) {
        trigger.addEventListener('click', function(e) {
            e.preventDefault();
            menu.classList.toggle('active');
            overlay.classList.toggle('active');
        });

        // Gestione azioni menu
        const menuItems = menu.querySelectorAll('.user-menu-item');
        menuItems.forEach(item => {
            item.addEventListener('click', function(e) {
                const action = this.getAttribute('data-action');
                if (action === 'profile') {
                    e.preventDefault();
                    showProfile();
                } else if (action === 'change-password') {
                    e.preventDefault();
                    showChangePassword();
                }
            });
        });
    }
}

function showProfile() {
    // Implementare visualizzazione profilo
    console.log('Mostra profilo');
}

function showChangePassword() {
    // Implementare cambio password
    console.log('Mostra cambio password');
}
