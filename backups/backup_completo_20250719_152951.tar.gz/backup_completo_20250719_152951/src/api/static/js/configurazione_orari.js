class ScheduleManager {
    constructor() {
        this.daysOfWeek = [
            { id: 0, name: 'Domenica' },
            { id: 1, name: 'Lunedì' },
            { id: 2, name: 'Martedì' },
            { id: 3, name: 'Mercoledì' },
            { id: 4, name: 'Giovedì' },
            { id: 5, name: 'Venerdì' },
            { id: 6, name: 'Sabato' }
        ];
        
        // Orari predefiniti in stile Google Business
        this.timeSlots = [];
        for (let h = 0; h < 24; h++) {
            for (let m of ['00', '30']) {
                this.timeSlots.push(`${h.toString().padStart(2, '0')}:${m}`);
            }
        }
        
        this.init();
    }
    
    init() {
        this.generateDays();
        this.setupEventListeners();
        this.loadCurrentSchedule();
    }
    
    generateDays() {
        const container = document.getElementById('days-container');
        container.innerHTML = ''; // Pulisci il contenitore
        
        this.daysOfWeek.forEach(day => {
            const dayHtml = this.generateDayRow(day);
            container.insertAdjacentHTML('beforeend', dayHtml);
            
            // Setup switch event
            const switchEl = document.getElementById(`${day.id}-switch`);
            if (switchEl) {
                switchEl.addEventListener('change', (e) => {
                    this.toggleDaySchedule(day.id, e.target.checked);
                });
            }
        });
    }
    
    generateDayRow(day) {
        return `
            <div class="day-row">
                <div class="day-name">${day.name}</div>
                <div class="form-check form-switch me-3">
                    <input class="form-check-input" type="checkbox" id="${day.id}-switch" checked>
                    <label class="form-check-label" for="${day.id}-switch">Aperto</label>
                </div>
                <div class="time-slots" id="${day.id}-slots">
                    <div class="time-slot morning">
                        <span class="time-label">Mattina</span>
                        <select class="form-select time-select" name="${day.id}-morning-open">
                            ${this.generateTimeOptions('09:00')}
                        </select>
                        <span class="time-separator">-</span>
                        <select class="form-select time-select" name="${day.id}-morning-close">
                            ${this.generateTimeOptions('12:00')}
                        </select>
                    </div>
                    <div class="time-slot afternoon">
                        <span class="time-label">Pomeriggio</span>
                        <select class="form-select time-select" name="${day.id}-afternoon-open">
                            ${this.generateTimeOptions('15:00')}
                        </select>
                        <span class="time-separator">-</span>
                        <select class="form-select time-select" name="${day.id}-afternoon-close">
                            ${this.generateTimeOptions('17:00')}
                        </select>
                    </div>
                </div>
            </div>
        `;
    }
    
    generateTimeOptions(selected) {
        return this.timeSlots.map(time => 
            `<option value="${time}" ${time === selected ? 'selected' : ''}>${time}</option>`
        ).join('');
    }
    
    
    toggleDaySchedule(dayId, isOpen) {
        const slots = document.getElementById(`${dayId}-slots`);
        const selects = slots.querySelectorAll('select');
        
        if (isOpen) {
            slots.classList.remove('disabled');
            selects.forEach(select => select.disabled = false);
        } else {
            slots.classList.add('disabled');
            selects.forEach(select => select.disabled = true);
        }
    }
    
    setupEventListeners() {
        // Salva configurazione
        document.getElementById('save-schedule').addEventListener('click', () => {
            this.saveSchedule();
        });
        
        // Copia su tutti i giorni
        document.getElementById('copy-to-all').addEventListener('click', () => {
            this.copyToAllDays();
        });
        
        // Salva limite ingressi
        document.getElementById('save-limits').addEventListener('click', () => {
            this.saveLimits();
        });
    }
    
    async loadCurrentSchedule() {
        try {
            const response = await fetch('/api/configurazione/orari');
            const data = await response.json();
            
            if (data.success && data.orari) {
                data.orari.forEach(orario => {
                    const day = this.daysOfWeek.find(d => d.name === orario.giorno);
                    if (day) {
                        // Imposta switch
                        const switchEl = document.getElementById(`${day.id}-switch`);
                        if (switchEl) {
                            switchEl.checked = orario.aperto;
                            this.toggleDaySchedule(day.id, orario.aperto);
                        }
                        
                        // Imposta orari mattina
                        document.querySelector(`select[name="${day.id}-morning-open"]`).value = orario.mattina_inizio;
                        document.querySelector(`select[name="${day.id}-morning-close"]`).value = orario.mattina_fine;
                        
                        // Imposta orari pomeriggio
                        document.querySelector(`select[name="${day.id}-afternoon-open"]`).value = orario.pomeriggio_inizio;
                        document.querySelector(`select[name="${day.id}-afternoon-close"]`).value = orario.pomeriggio_fine;
                    }
                });
            }
            
            // Carica limite ingressi
            const limitsResponse = await fetch('/api/configurazione/limiti');
            const limitsData = await limitsResponse.json();
            
            if (limitsData.success) {
                document.getElementById('max-entries').value = limitsData.max_ingressi_mensili;
            }
            
        } catch (error) {
            console.error('Errore caricamento configurazione:', error);
            showAlert('Errore caricamento configurazione', 'danger');
        }
    }
    
    async saveSchedule() {
        const orari = this.daysOfWeek.map(day => {
            const isOpen = document.getElementById(`${day.id}-switch`).checked;
            
            return {
                giorno: day.name,
                aperto: isOpen,
                mattina_inizio: document.querySelector(`select[name="${day.id}-morning-open"]`).value,
                mattina_fine: document.querySelector(`select[name="${day.id}-morning-close"]`).value,
                pomeriggio_inizio: document.querySelector(`select[name="${day.id}-afternoon-open"]`).value,
                pomeriggio_fine: document.querySelector(`select[name="${day.id}-afternoon-close"]`).value
            };
        });
        
        try {
            const response = await fetch('/api/configurazione/orari', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ orari })
            });
            
            const data = await response.json();
            
            if (data.success) {
                showAlert('Configurazione orari salvata con successo', 'success');
            } else {
                showAlert(data.error || 'Errore salvataggio configurazione', 'danger');
            }
            
        } catch (error) {
            console.error('Errore salvataggio:', error);
            showAlert('Errore di connessione al server', 'danger');
        }
    }
    
    copyToAllDays() {
        // Prendi i valori dal lunedì
        const mondaySwitch = document.getElementById('1-switch');
        const mondayMorningOpen = document.querySelector('select[name="1-morning-open"]');
        const mondayMorningClose = document.querySelector('select[name="1-morning-close"]');
        const mondayAfternoonOpen = document.querySelector('select[name="1-afternoon-open"]');
        const mondayAfternoonClose = document.querySelector('select[name="1-afternoon-close"]');
        
        // Applica a tutti gli altri giorni
        this.daysOfWeek.forEach(day => {
            if (day.id !== 1) { // Salta lunedì
                const daySwitch = document.getElementById(`${day.id}-switch`);
                daySwitch.checked = mondaySwitch.checked;
                this.toggleDaySchedule(day.id, mondaySwitch.checked);
                
                document.querySelector(`select[name="${day.id}-morning-open"]`).value = mondayMorningOpen.value;
                document.querySelector(`select[name="${day.id}-morning-close"]`).value = mondayMorningClose.value;
                document.querySelector(`select[name="${day.id}-afternoon-open"]`).value = mondayAfternoonOpen.value;
                document.querySelector(`select[name="${day.id}-afternoon-close"]`).value = mondayAfternoonClose.value;
            }
        });
        
        showAlert('Orari copiati su tutti i giorni', 'success');
    }
    
    async saveLimits() {
        const maxEntries = document.getElementById('max-entries').value;
        
        if (!maxEntries || maxEntries < 1) {
            showAlert('Inserire un numero valido di ingressi mensili', 'danger');
            return;
        }
        
        try {
            const response = await fetch('/api/configurazione/limiti', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ max_ingressi_mensili: parseInt(maxEntries) })
            });
            
            const data = await response.json();
            
            if (data.success) {
                showAlert('Limite ingressi mensili salvato con successo', 'success');
            } else {
                showAlert(data.error || 'Errore salvataggio limite', 'danger');
            }
            
        } catch (error) {
            console.error('Errore salvataggio:', error);
            showAlert('Errore di connessione al server', 'danger');
        }
    }
}

// Funzione per mostrare alert
function showAlert(message, type) {
    const alertHtml = `
        <div class="alert alert-${type} alert-dismissible fade show" role="alert">
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    `;
    
    // Rimuovi alert esistenti
    document.querySelectorAll('.alert').forEach(alert => alert.remove());
    
    // Inserisci nuovo alert all'inizio del container
    document.querySelector('.container').insertAdjacentHTML('afterbegin', alertHtml);
    
    // Auto-chiudi dopo 5 secondi
    setTimeout(() => {
        const alert = document.querySelector('.alert');
        if (alert) {
            const bsAlert = new bootstrap.Alert(alert);
            bsAlert.close();
        }
    }, 5000);
}

// Funzioni per test e log forzature
async function updateStatoCancello() {
    try {
        const response = await fetch('/api/test/gate');
        const data = await response.json();
        
        const statoEl = document.getElementById('stato-cancello');
        if (data.success) {
            statoEl.textContent = data.open ? 'APERTO' : 'CHIUSO';
            statoEl.className = `h4 text-${data.open ? 'success' : 'danger'}`;
        } else {
            statoEl.textContent = 'ERRORE';
            statoEl.className = 'h4 text-danger';
        }
    } catch (error) {
        console.error('Errore controllo stato cancello:', error);
        document.getElementById('stato-cancello').textContent = 'ERRORE';
    }
}

async function apriCancello() {
    try {
        const response = await fetch('/api/test/gate/force', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' }
        });
        
        const data = await response.json();
        
        if (data.success) {
            showAlert('Cancello aperto con successo', 'success');
            updateStatoCancello();
            loadLogForzature();
        } else {
            showAlert(data.error || 'Errore apertura cancello', 'danger');
        }
    } catch (error) {
        console.error('Errore apertura cancello:', error);
        showAlert('Errore di connessione', 'danger');
    }
}

async function loadLogForzature() {
    try {
        const response = await fetch('/api/log/force');
        const data = await response.json();
        
        const tbody = document.getElementById('log-forzature');
        tbody.innerHTML = '';
        
        if (data.success && data.logs.length > 0) {
            data.logs.forEach(log => {
                tbody.innerHTML += `
                    <tr>
                        <td>${new Date(log.timestamp).toLocaleString('it-IT')}</td>
                        <td>${log.tipo}</td>
                        <td>${log.utente}</td>
                        <td>${log.dettagli}</td>
                    </tr>
                `;
            });
        } else {
            tbody.innerHTML = `
                <tr>
                    <td colspan="4" class="text-center">
                        Nessun log disponibile
                    </td>
                </tr>
            `;
        }
    } catch (error) {
        console.error('Errore caricamento log:', error);
        document.getElementById('log-forzature').innerHTML = `
            <tr>
                <td colspan="4" class="text-center text-danger">
                    Errore caricamento log
                </td>
            </tr>
        `;
    }
}

// Funzioni per gestione utenti bloccati
let utentiBloccati = [];

async function loadUtentiBloccati() {
    try {
        const response = await fetch('/api/users/blocked');
        const data = await response.json();
        
        if (data.success) {
            utentiBloccati = data.users;
            renderUtentiBloccati(utentiBloccati);
        } else {
            showAlert('Errore caricamento utenti bloccati', 'danger');
        }
    } catch (error) {
        console.error('Errore caricamento utenti:', error);
        showAlert('Errore di connessione', 'danger');
    }
}

function renderUtentiBloccati(utenti) {
    const tbody = document.getElementById('utenti-bloccati');
    tbody.innerHTML = '';
    
    if (utenti.length === 0) {
        tbody.innerHTML = `
            <tr>
                <td colspan="5" class="text-center">
                    Nessun utente bloccato
                </td>
            </tr>
        `;
        return;
    }
    
    utenti.forEach(utente => {
        tbody.innerHTML += `
            <tr>
                <td>${utente.codice_fiscale}</td>
                <td>${utente.nome}</td>
                <td>${utente.cognome}</td>
                <td>${utente.accessi_effettuati}</td>
                <td>
                    <button class="btn btn-warning btn-sm" 
                            onclick="showSbloccoModal('${utente.codice_fiscale}')">
                        <i class="fas fa-unlock me-1"></i>
                        Sblocca
                    </button>
                </td>
            </tr>
        `;
    });
}

function filterUtenti(search) {
    const filtered = utentiBloccati.filter(utente => 
        utente.codice_fiscale.toLowerCase().includes(search.toLowerCase())
    );
    renderUtentiBloccati(filtered);
}

function showSbloccoModal(cf) {
    document.getElementById('reset-cf').value = cf;
    document.getElementById('extra-accessi').value = '1';
    new bootstrap.Modal(document.getElementById('modal-sblocco')).show();
}

async function resetContatore() {
    const cf = document.getElementById('reset-cf').value;
    const extraAccessi = parseInt(document.getElementById('extra-accessi').value);
    
    if (!cf.match(/^[A-Z]{6}[0-9]{2}[A-Z][0-9]{2}[A-Z][0-9]{3}[A-Z]$/)) {
        showAlert('Codice fiscale non valido', 'danger');
        return;
    }
    
    if (isNaN(extraAccessi) || extraAccessi < 1) {
        showAlert('Inserire un numero valido di accessi extra', 'danger');
        return;
    }
    
    try {
        const response = await fetch('/api/users/reset-counter', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ 
                codice_fiscale: cf,
                accessi_extra: extraAccessi
            })
        });
        
        const data = await response.json();
        
        if (data.success) {
            showAlert('Accessi extra concessi con successo', 'success');
            bootstrap.Modal.getInstance(document.getElementById('modal-sblocco')).hide();
            loadUtentiBloccati(); // Ricarica la lista
            loadLogForzature(); // Aggiorna i log
        } else {
            showAlert(data.error || 'Errore concessione accessi', 'danger');
        }
    } catch (error) {
        console.error('Errore reset contatore:', error);
        showAlert('Errore di connessione', 'danger');
    }
}

// Inizializza quando il DOM è pronto
document.addEventListener('DOMContentLoaded', () => {
    new ScheduleManager();
    
    // Inizializza sezione test
    updateStatoCancello();
    loadLogForzature();
    loadUtentiBloccati();
    
    // Setup ricerca utenti bloccati
    document.getElementById('search-cf').addEventListener('input', (e) => {
        filterUtenti(e.target.value);
    });
    
    // Aggiorna stato cancello ogni 30 secondi
    setInterval(updateStatoCancello, 30000);
});
