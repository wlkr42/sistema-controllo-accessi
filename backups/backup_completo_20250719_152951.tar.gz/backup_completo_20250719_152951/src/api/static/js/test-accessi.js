// Aggiorna orario attuale
function updateOrarioAttuale() {
    const now = new Date();
    document.getElementById('orario-attuale').textContent = 
        now.toLocaleTimeString('it-IT', { hour: '2-digit', minute: '2-digit' });
}

// Aggiorna stato cancello
async function updateStatoCancello() {
    try {
        const response = await fetch('/api/test/gate');
        const data = await response.json();
        
        const statoEl = document.getElementById('stato-cancello');
        if (data.success) {
            statoEl.textContent = data.open ? 'Aperto' : 'Chiuso';
            statoEl.className = `stat-number text-${data.open ? 'success' : 'danger'}`;
        } else {
            statoEl.textContent = 'Errore';
            statoEl.className = 'stat-number text-danger';
        }
    } catch (error) {
        console.error('Errore controllo stato cancello:', error);
        document.getElementById('stato-cancello').textContent = 'Errore';
    }
}

// Aggiorna contatore utenti disabilitati
async function updateUtentiDisabilitati() {
    try {
        const response = await fetch('/api/users/disabled/count');
        const data = await response.json();
        
        if (data.success) {
            document.getElementById('utenti-disabilitati').textContent = data.count;
        } else {
            document.getElementById('utenti-disabilitati').textContent = 'Errore';
        }
    } catch (error) {
        console.error('Errore conteggio utenti disabilitati:', error);
        document.getElementById('utenti-disabilitati').textContent = 'Errore';
    }
}

// Reset contatore accessi
async function resetContatore() {
    const cf = document.getElementById('reset-cf').value.toUpperCase();
    
    if (!cf.match(/^[A-Z]{6}[0-9]{2}[A-Z][0-9]{2}[A-Z][0-9]{3}[A-Z]$/)) {
        showAlert('Codice fiscale non valido', 'danger');
        return;
    }
    
    try {
        const response = await fetch('/api/users/reset-counter', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ codice_fiscale: cf })
        });
        
        const data = await response.json();
        
        if (data.success) {
            showAlert('Contatore resettato con successo', 'success');
            document.getElementById('reset-cf').value = '';
            updateUtentiDisabilitati();
        } else {
            showAlert(data.error || 'Errore reset contatore', 'danger');
        }
    } catch (error) {
        console.error('Errore reset contatore:', error);
        showAlert('Errore di connessione', 'danger');
    }
}

// Apertura forzata cancello
async function apriCancello() {
    try {
        const response = await fetch('/api/test/gate/force', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' }
        });
        
        const data = await response.json();
        
        if (data.success) {
            showAlert('Cancello aperto con successo', 'success');
            updateStatoCancello();
            loadLogForzature();
        } else {
            showAlert(data.error || 'Errore apertura cancello', 'danger');
        }
    } catch (error) {
        console.error('Errore apertura cancello:', error);
        showAlert('Errore di connessione', 'danger');
    }
}

// Carica log forzature
async function loadLogForzature() {
    try {
        const response = await fetch('/api/log/force');
        const data = await response.json();
        
        const tbody = document.getElementById('log-forzature');
        tbody.innerHTML = '';
        
        if (data.success && data.logs.length > 0) {
            data.logs.forEach(log => {
                tbody.innerHTML += `
                    <tr>
                        <td>${new Date(log.timestamp).toLocaleString('it-IT')}</td>
                        <td>${log.tipo}</td>
                        <td>${log.utente}</td>
                        <td>${log.dettagli}</td>
                    </tr>
                `;
            });
        } else {
            tbody.innerHTML = `
                <tr>
                    <td colspan="4" class="text-center">
                        Nessun log disponibile
                    </td>
                </tr>
            `;
        }
    } catch (error) {
        console.error('Errore caricamento log:', error);
        document.getElementById('log-forzature').innerHTML = `
            <tr>
                <td colspan="4" class="text-center text-danger">
                    Errore caricamento log
                </td>
            </tr>
        `;
    }
}

// Mostra alert
function showAlert(message, type) {
    const alertHtml = `
        <div class="alert alert-${type} alert-dismissible fade show" role="alert">
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    `;
    
    // Rimuovi alert esistenti
    document.querySelectorAll('.alert:not(.alert-warning)').forEach(alert => alert.remove());
    
    // Inserisci nuovo alert all'inizio del container
    document.querySelector('.container-fluid').insertAdjacentHTML('afterbegin', alertHtml);
    
    // Auto-chiudi dopo 5 secondi
    setTimeout(() => {
        const alert = document.querySelector(`.alert-${type}`);
        if (alert) {
            const bsAlert = new bootstrap.Alert(alert);
            bsAlert.close();
        }
    }, 5000);
}

// Inizializzazione
document.addEventListener('DOMContentLoaded', () => {
    // Aggiorna orario ogni minuto
    updateOrarioAttuale();
    setInterval(updateOrarioAttuale, 60000);
    
    // Aggiorna stato cancello ogni 30 secondi
    updateStatoCancello();
    setInterval(updateStatoCancello, 30000);
    
    // Aggiorna contatore utenti disabilitati ogni minuto
    updateUtentiDisabilitati();
    setInterval(updateUtentiDisabilitati, 60000);
    
    // Carica log iniziale
    loadLogForzature();
});
